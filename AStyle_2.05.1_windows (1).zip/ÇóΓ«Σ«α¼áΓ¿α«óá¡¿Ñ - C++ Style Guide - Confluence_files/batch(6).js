;try {
/* module-key = 'confluence.web.resources:moment', location = '/includes/js/moment/moment.js' */
(function(){function R(a,b){return function(c){return k(a.call(this,c),b)}}function pa(a,b){return function(c){return this.lang().ordinal(a.call(this,c),b)}}function S(){}function B(a){T(a);m(this,a)}function C(a){var a=U(a),b=a.year||0,c=a.month||0,d=a.week||0,f=a.day||0;this._milliseconds=+(a.millisecond||0)+1E3*(a.second||0)+6E4*(a.minute||0)+36E5*(a.hour||0);this._days=+f+7*d;this._months=+c+12*b;this._data={};this._bubble()}function m(a,b){for(var c in b)b.hasOwnProperty(c)&&(a[c]=b[c]);b.hasOwnProperty("toString")&&
(a.toString=b.toString);b.hasOwnProperty("valueOf")&&(a.valueOf=b.valueOf);return a}function s(a){return 0>a?Math.ceil(a):Math.floor(a)}function k(a,b,c){for(var d=Math.abs(a)+"";d.length<b;)d="0"+d;return(0<=a?c?"+":"":"-")+d}function D(a,b,c,d){var f=b._milliseconds,i=b._days,b=b._months,g,h;f&&a._d.setTime(+a._d+f*c);if(i||b)g=a.minute(),h=a.hour();i&&a.date(a.date()+i*c);b&&a.month(a.month()+b*c);f&&!d&&e.updateOffset(a);if(i||b)a.minute(g),a.hour(h)}function E(a){return"[object Array]"===Object.prototype.toString.call(a)}
function V(a,b,c){var d=Math.min(a.length,b.length),f=Math.abs(a.length-b.length),e=0,g;for(g=0;g<d;g++)(c&&a[g]!==b[g]||!c&&h(a[g])!==h(b[g]))&&e++;return e+f}function l(a){if(a)var b=a.toLowerCase().replace(/(.)s$/,"$1"),a=qa[a]||ra[b]||b;return a}function U(a){var b={},c,d;for(d in a)a.hasOwnProperty(d)&&(c=l(d))&&(b[c]=a[d]);return b}function sa(a){var b,c;if(0===a.indexOf("week"))b=7,c="day";else if(0===a.indexOf("month"))b=12,c="month";else return;e[a]=function(d,f){var i,g,h=e.fn._lang[a],
j=[];"number"===typeof d&&(f=d,d=void 0);g=function(a){a=e().utc().set(c,a);return h.call(e.fn._lang,a,d||"")};if(null!=f)return g(f);for(i=0;i<b;i++)j.push(g(i));return j}}function h(a){var a=+a,b=0;0!==a&&isFinite(a)&&(b=0<=a?Math.floor(a):Math.ceil(a));return b}function F(a){return 0===a%4&&0!==a%100||0===a%400}function T(a){var b;if(a._a&&-2===a._pf.overflow){b=0>a._a[t]||11<a._a[t]?t:1>a._a[q]||a._a[q]>(new Date(Date.UTC(a._a[o],a._a[t]+1,0))).getUTCDate()?q:0>a._a[n]||23<a._a[n]?n:0>a._a[u]||
59<a._a[u]?u:0>a._a[x]||59<a._a[x]?x:0>a._a[y]||999<a._a[y]?y:-1;if(a._pf._overflowDayOfYear&&(b<o||b>q))b=q;a._pf.overflow=b}}function W(a){a._pf={empty:!1,unusedTokens:[],unusedInput:[],overflow:-2,charsLeftOver:0,nullInput:!1,invalidMonth:null,invalidFormat:!1,userInvalidated:!1,iso:!1}}function X(a){null==a._isValid&&(a._isValid=!isNaN(a._d.getTime())&&0>a._pf.overflow&&!a._pf.empty&&!a._pf.invalidMonth&&!a._pf.nullInput&&!a._pf.invalidFormat&&!a._pf.userInvalidated,a._strict&&(a._isValid=a._isValid&&
0===a._pf.charsLeftOver&&0===a._pf.unusedTokens.length));return a._isValid}function G(a){return a?a.toLowerCase().replace("_","-"):a}function H(a,b){return b._isUTC?e(a).zone(b._offset||0):e(a).local()}function p(a){var b=0,c,d,f,i,g=function(a){if(!v[a]&&Y)try{require("./lang/"+a)}catch(b){}return v[a]};if(!a)return e.fn._lang;if(!E(a)){if(d=g(a))return d;a=[a]}for(;b<a.length;){i=G(a[b]).split("-");c=i.length;for(f=(f=G(a[b+1]))?f.split("-"):null;0<c;){if(d=g(i.slice(0,c).join("-")))return d;if(f&&
f.length>=c&&V(i,f,!0)>=c-1)break;c--}b++}return e.fn._lang}function I(a,b){if(!a.isValid())return a.lang().invalidDate();b=Z(b,a.lang());if(!J[b]){var c=J,d=b,f=b,e=f.match($),g,h;g=0;for(h=e.length;g<h;g++)e[g]=r[e[g]]?r[e[g]]:e[g].match(/\[[\s\S]/)?e[g].replace(/^\[|\]$/g,""):e[g].replace(/\\/g,"");c[d]=function(a){var b="";for(g=0;g<h;g++)b+=e[g]instanceof Function?e[g].call(a,f):e[g];return b}}return J[b](a)}function Z(a,b){function c(a){return b.longDateFormat(a)||a}var d=5;for(z.lastIndex=
0;0<=d&&z.test(a);)a=a.replace(z,c),z.lastIndex=0,d-=1;return a}function ta(a,b){var c=b._strict;switch(a){case "DDDD":return aa;case "YYYY":case "GGGG":case "gggg":return c?ua:va;case "YYYYYY":case "YYYYY":case "GGGGG":case "ggggg":return c?wa:xa;case "S":if(c)return ba;case "SS":if(c)return ca;case "SSS":case "DDD":return c?aa:ya;case "MMM":case "MMMM":case "dd":case "ddd":case "dddd":return za;case "a":case "A":return p(b._l)._meridiemParse;case "X":return Aa;case "Z":case "ZZ":return K;case "T":return Ba;
case "SSSS":return Ca;case "MM":case "DD":case "YY":case "GG":case "gg":case "HH":case "hh":case "mm":case "ss":case "ww":case "WW":return c?ca:da;case "M":case "D":case "d":case "H":case "h":case "m":case "s":case "w":case "W":case "e":case "E":return c?ba:da;default:var c=RegExp,d;d=a.replace("\\","").replace(/\\(\[)|\\(\])|\[([^\]\[]*)\]|\\(.)/g,function(a,b,c,d,e){return b||c||d||e}).replace(/[-\/\\^$*+?.()|[\]{}]/g,"\\$&");return new c(d)}}function ea(a){var a=(a||"").match(K)||[],a=((a[a.length-
1]||[])+"").match(Da)||["-",0,0],b=+(60*a[1])+h(a[2]);return"+"===a[0]?-b:b}function L(a){var b,c=[],d,f,i,g,j;if(!a._d){d=new Date;d=a._useUTC?[d.getUTCFullYear(),d.getUTCMonth(),d.getUTCDate()]:[d.getFullYear(),d.getMonth(),d.getDate()];a._w&&(null==a._a[q]&&null==a._a[t])&&(b=function(b){var c=parseInt(b,10);return b?3>b.length?68<c?1900+c:2E3+c:c:null==a._a[o]?e().weekYear():a._a[o]},f=a._w,null!=f.GG||null!=f.W||null!=f.E?b=fa(b(f.GG),f.W||1,f.E,4,1):(i=p(a._l),g=null!=f.d?ga(f.d,i):null!=f.e?
parseInt(f.e,10)+i._week.dow:0,j=parseInt(f.w,10)||1,null!=f.d&&g<i._week.dow&&j++,b=fa(b(f.gg),j,g,i._week.doy,i._week.dow)),a._a[o]=b.year,a._dayOfYear=b.dayOfYear);if(a._dayOfYear){b=null==a._a[o]?d[o]:a._a[o];if(a._dayOfYear>(F(b)?366:365))a._pf._overflowDayOfYear=!0;b=ha(b,0,a._dayOfYear);a._a[t]=b.getUTCMonth();a._a[q]=b.getUTCDate()}for(b=0;3>b&&null==a._a[b];++b)a._a[b]=c[b]=d[b];for(;7>b;b++)a._a[b]=c[b]=null==a._a[b]?2===b?1:0:a._a[b];c[n]+=h((a._tzm||0)/60);c[u]+=h((a._tzm||0)%60);a._d=
(a._useUTC?ha:Ea).apply(null,c)}}function M(a){a._a=[];a._pf.empty=!0;var b=p(a._l),c=""+a._i,d,f,e,g,j=c.length,k=0;f=Z(a._f,b).match($)||[];for(b=0;b<f.length;b++){e=f[b];if(d=(c.match(ta(e,a))||[])[0])g=c.substr(0,c.indexOf(d)),0<g.length&&a._pf.unusedInput.push(g),c=c.slice(c.indexOf(d)+d.length),k+=d.length;if(r[e]){d?a._pf.empty=!1:a._pf.unusedTokens.push(e);g=a;var m=void 0,l=g._a;switch(e){case "M":case "MM":null!=d&&(l[t]=h(d)-1);break;case "MMM":case "MMMM":m=p(g._l).monthsParse(d);null!=
m?l[t]=m:g._pf.invalidMonth=d;break;case "D":case "DD":null!=d&&(l[q]=h(d));break;case "DDD":case "DDDD":null!=d&&(g._dayOfYear=h(d));break;case "YY":l[o]=h(d)+(68<h(d)?1900:2E3);break;case "YYYY":case "YYYYY":case "YYYYYY":l[o]=h(d);break;case "a":case "A":g._isPm=p(g._l).isPM(d);break;case "H":case "HH":case "h":case "hh":l[n]=h(d);break;case "m":case "mm":l[u]=h(d);break;case "s":case "ss":l[x]=h(d);break;case "S":case "SS":case "SSS":case "SSSS":l[y]=h(1E3*("0."+d));break;case "X":g._d=new Date(1E3*
parseFloat(d));break;case "Z":case "ZZ":g._useUTC=!0;g._tzm=ea(d);break;case "w":case "ww":case "W":case "WW":case "d":case "dd":case "ddd":case "dddd":case "e":case "E":e=e.substr(0,1);case "gg":case "gggg":case "GG":case "GGGG":case "GGGGG":e=e.substr(0,2),d&&(g._w=g._w||{},g._w[e]=d)}}else a._strict&&!d&&a._pf.unusedTokens.push(e)}a._pf.charsLeftOver=j-k;0<c.length&&a._pf.unusedInput.push(c);a._isPm&&12>a._a[n]&&(a._a[n]+=12);!1===a._isPm&&12===a._a[n]&&(a._a[n]=0);L(a);T(a)}function Ea(a,b,c,
d,f,e,g){b=new Date(a,b,c,d,f,e,g);1970>a&&b.setFullYear(a);return b}function ha(a){var b=new Date(Date.UTC.apply(null,arguments));1970>a&&b.setUTCFullYear(a);return b}function ga(a,b){if("string"===typeof a)if(isNaN(a)){if(a=b.weekdaysParse(a),"number"!==typeof a)return null}else a=parseInt(a,10);return a}function Fa(a,b,c,d,e){return e.relativeTime(b||1,!!c,a,d)}function A(a,b,c){b=c-b;c-=a.day();c>b&&(c-=7);c<b-7&&(c+=7);a=e(a).add("d",c);return{week:Math.ceil(a.dayOfYear()/7),year:a.year()}}function fa(a,
b,c,d,e){var i=(new Date(k(a,6,!0)+"-01-01")).getUTCDay(),b=7*(b-1)+((null!=c?c:e)-e)+(e-i+(i>d?7:0))+1;return{year:0<b?a:a-1,dayOfYear:0<b?b:(F(a-1)?366:365)+b}}function ia(a){var b=a._i,c=a._f;"undefined"===typeof a._pf&&W(a);if(null===b)return e.invalid({nullInput:!0});"string"===typeof b&&(a._i=b=p().preparse(b));if(e.isMoment(b))a=m({},b),a._d=new Date(+b._d);else if(c)if(E(c)){var b=a,d,f,i,g;if(0===b._f.length)b._pf.invalidFormat=!0,b._d=new Date(NaN);else{for(c=0;c<b._f.length;c++)if(g=0,
d=m({},b),W(d),d._f=b._f[c],M(d),X(d)&&(g+=d._pf.charsLeftOver,g+=10*d._pf.unusedTokens.length,d._pf.score=g,null==i||g<i))i=g,f=d;m(b,f||d)}}else M(a);else if(d=a,f=d._i,i=Ga.exec(f),void 0===f)d._d=new Date;else if(i)d._d=new Date(+i[1]);else if("string"===typeof f)if(i=d._i,b=Ha.exec(i)){d._pf.iso=!0;for(f=4;0<f;f--)if(b[f]){d._f=Ia[f-1]+(b[6]||" ");break}for(f=0;4>f;f++)if(ja[f][1].exec(i)){d._f+=ja[f][0];break}i.match(K)&&(d._f+="Z");M(d)}else d._d=new Date(i);else E(f)?(d._a=f.slice(0),L(d)):
"[object Date]"===Object.prototype.toString.call(f)||f instanceof Date?d._d=new Date(+f):"object"===typeof f?d._d||(f=U(d._i),d._a=[f.year,f.month,f.day,f.hour,f.minute,f.second,f.millisecond],L(d)):d._d=new Date(f);return new B(a)}function ka(a,b){e.fn[a]=e.fn[a+"s"]=function(a){var d=this._isUTC?"UTC":"";return null!=a?(this._d["set"+d+b](a),e.updateOffset(this),this):this._d["get"+d+b]()}}function Ja(a){e.duration.fn[a]=function(){return this._data[a]}}function la(a,b){e.duration.fn["as"+a]=function(){return+this/
b}}function N(a){var b=!1,c=e;"undefined"===typeof ender&&(a?(O.moment=function(){!b&&(console&&console.warn)&&(b=!0,console.warn("Accessing Moment through the global scope is deprecated, and will be removed in an upcoming release."));return c.apply(null,arguments)},m(O.moment,c)):O.moment=e)}for(var e,O=this,w=Math.round,j,o=0,t=1,q=2,n=3,u=4,x=5,y=6,v={},Y="undefined"!==typeof module&&module.exports&&"undefined"!==typeof require,Ga=/^\/?Date\((\-?\d+)/i,Ka=/(\-)?(?:(\d*)\.)?(\d+)\:(\d+)(?:\:(\d+)\.?(\d{3})?)?/,
La=/^(-)?P(?:(?:([0-9,.]*)Y)?(?:([0-9,.]*)M)?(?:([0-9,.]*)D)?(?:T(?:([0-9,.]*)H)?(?:([0-9,.]*)M)?(?:([0-9,.]*)S)?)?|([0-9,.]*)W)$/,$=/(\[[^\[]*\])|(\\)?(Mo|MM?M?M?|Do|DDDo|DD?D?D?|ddd?d?|do?|w[o|w]?|W[o|W]?|YYYYYY|YYYYY|YYYY|YY|gg(ggg?)?|GG(GGG?)?|e|E|a|A|hh?|HH?|mm?|ss?|S{1,4}|X|zz?|ZZ?|.)/g,z=/(\[[^\[]*\])|(\\)?(LT|LL?L?L?|l{1,4})/g,da=/\d\d?/,ya=/\d{1,3}/,va=/\d{1,4}/,xa=/[+\-]?\d{1,6}/,Ca=/\d+/,za=/[0-9]*['a-z\u00A0-\u05FF\u0700-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+|[\u0600-\u06FF\/]+(\s*?[\u0600-\u06FF]+){1,2}/i,
K=/Z|[\+\-]\d\d:?\d\d/gi,Ba=/T/i,Aa=/[\+\-]?\d+(\.\d{1,3})?/,ba=/\d/,ca=/\d\d/,aa=/\d{3}/,ua=/\d{4}/,wa=/[+\-]?\d{6}/,Ha=/^\s*\d{4}-(?:(\d\d-\d\d)|(W\d\d$)|(W\d\d-\d)|(\d\d\d))((T| )(\d\d(:\d\d(:\d\d(\.\d+)?)?)?)?([\+\-]\d\d(?::?\d\d)?|\s*Z)?)?$/,Ia=["YYYY-MM-DD","GGGG-[W]WW","GGGG-[W]WW-E","YYYY-DDD"],ja=[["HH:mm:ss.SSSS",/(T| )\d\d:\d\d:\d\d\.\d{1,3}/],["HH:mm:ss",/(T| )\d\d:\d\d:\d\d/],["HH:mm",/(T| )\d\d:\d\d/],["HH",/(T| )\d\d/]],Da=/([\+\-]|\d\d)/gi,P=["Date","Hours","Minutes","Seconds","Milliseconds"],
Q={Milliseconds:1,Seconds:1E3,Minutes:6E4,Hours:36E5,Days:864E5,Months:2592E6,Years:31536E6},qa={ms:"millisecond",s:"second",m:"minute",h:"hour",d:"day",D:"date",w:"week",W:"isoWeek",M:"month",y:"year",DDD:"dayOfYear",e:"weekday",E:"isoWeekday",gg:"weekYear",GG:"isoWeekYear"},ra={dayofyear:"dayOfYear",isoweekday:"isoWeekday",isoweek:"isoWeek",weekyear:"weekYear",isoweekyear:"isoWeekYear"},J={},ma="DDD w W M D d".split(" "),na="MDHhmswW".split(""),r={M:function(){return this.month()+1},MMM:function(a){return this.lang().monthsShort(this,
a)},MMMM:function(a){return this.lang().months(this,a)},D:function(){return this.date()},DDD:function(){return this.dayOfYear()},d:function(){return this.day()},dd:function(a){return this.lang().weekdaysMin(this,a)},ddd:function(a){return this.lang().weekdaysShort(this,a)},dddd:function(a){return this.lang().weekdays(this,a)},w:function(){return this.week()},W:function(){return this.isoWeek()},YY:function(){return k(this.year()%100,2)},YYYY:function(){return k(this.year(),4)},YYYYY:function(){return k(this.year(),
5)},YYYYYY:function(){var a=this.year();return(0<=a?"+":"-")+k(Math.abs(a),6)},gg:function(){return k(this.weekYear()%100,2)},gggg:function(){return this.weekYear()},ggggg:function(){return k(this.weekYear(),5)},GG:function(){return k(this.isoWeekYear()%100,2)},GGGG:function(){return this.isoWeekYear()},GGGGG:function(){return k(this.isoWeekYear(),5)},e:function(){return this.weekday()},E:function(){return this.isoWeekday()},a:function(){return this.lang().meridiem(this.hours(),this.minutes(),!0)},
A:function(){return this.lang().meridiem(this.hours(),this.minutes(),!1)},H:function(){return this.hours()},h:function(){return this.hours()%12||12},m:function(){return this.minutes()},s:function(){return this.seconds()},S:function(){return h(this.milliseconds()/100)},SS:function(){return k(h(this.milliseconds()/10),2)},SSS:function(){return k(this.milliseconds(),3)},SSSS:function(){return k(this.milliseconds(),3)},Z:function(){var a=-this.zone(),b="+";0>a&&(a=-a,b="-");return b+k(h(a/60),2)+":"+
k(h(a)%60,2)},ZZ:function(){var a=-this.zone(),b="+";0>a&&(a=-a,b="-");return b+k(h(a/60),2)+k(h(a)%60,2)},z:function(){return this.zoneAbbr()},zz:function(){return this.zoneName()},X:function(){return this.unix()},Q:function(){return this.quarter()}},oa=["months","monthsShort","weekdays","weekdaysShort","weekdaysMin"];ma.length;)j=ma.pop(),r[j+"o"]=pa(r[j],j);for(;na.length;)j=na.pop(),r[j+j]=R(r[j],2);r.DDDD=R(r.DDD,3);m(S.prototype,{set:function(a){var b,c;for(c in a)b=a[c],"function"===typeof b?
this[c]=b:this["_"+c]=b},_months:"January February March April May June July August September October November December".split(" "),months:function(a){return this._months[a.month()]},_monthsShort:"Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec".split(" "),monthsShort:function(a){return this._monthsShort[a.month()]},monthsParse:function(a){var b,c;this._monthsParse||(this._monthsParse=[]);for(b=0;12>b;b++)if(this._monthsParse[b]||(c=e.utc([2E3,b]),c="^"+this.months(c,"")+"|^"+this.monthsShort(c,""),
this._monthsParse[b]=RegExp(c.replace(".",""),"i")),this._monthsParse[b].test(a))return b},_weekdays:"Sunday Monday Tuesday Wednesday Thursday Friday Saturday".split(" "),weekdays:function(a){return this._weekdays[a.day()]},_weekdaysShort:"Sun Mon Tue Wed Thu Fri Sat".split(" "),weekdaysShort:function(a){return this._weekdaysShort[a.day()]},_weekdaysMin:"Su Mo Tu We Th Fr Sa".split(" "),weekdaysMin:function(a){return this._weekdaysMin[a.day()]},weekdaysParse:function(a){var b,c;this._weekdaysParse||
(this._weekdaysParse=[]);for(b=0;7>b;b++)if(this._weekdaysParse[b]||(c=e([2E3,1]).day(b),c="^"+this.weekdays(c,"")+"|^"+this.weekdaysShort(c,"")+"|^"+this.weekdaysMin(c,""),this._weekdaysParse[b]=RegExp(c.replace(".",""),"i")),this._weekdaysParse[b].test(a))return b},_longDateFormat:{LT:"h:mm A",L:"MM/DD/YYYY",LL:"MMMM D YYYY",LLL:"MMMM D YYYY LT",LLLL:"dddd, MMMM D YYYY LT"},longDateFormat:function(a){var b=this._longDateFormat[a];!b&&this._longDateFormat[a.toUpperCase()]&&(b=this._longDateFormat[a.toUpperCase()].replace(/MMMM|MM|DD|dddd/g,
function(a){return a.slice(1)}),this._longDateFormat[a]=b);return b},isPM:function(a){return"p"===(a+"").toLowerCase().charAt(0)},_meridiemParse:/[ap]\.?m?\.?/i,meridiem:function(a,b,c){return 11<a?c?"pm":"PM":c?"am":"AM"},_calendar:{sameDay:"[Today at] LT",nextDay:"[Tomorrow at] LT",nextWeek:"dddd [at] LT",lastDay:"[Yesterday at] LT",lastWeek:"[Last] dddd [at] LT",sameElse:"L"},calendar:function(a,b){var c=this._calendar[a];return"function"===typeof c?c.apply(b):c},_relativeTime:{future:"in %s",
past:"%s ago",s:"a few seconds",m:"a minute",mm:"%d minutes",h:"an hour",hh:"%d hours",d:"a day",dd:"%d days",M:"a month",MM:"%d months",y:"a year",yy:"%d years"},relativeTime:function(a,b,c,d){var e=this._relativeTime[c];return"function"===typeof e?e(a,b,c,d):e.replace(/%d/i,a)},pastFuture:function(a,b){var c=this._relativeTime[0<a?"future":"past"];return"function"===typeof c?c(b):c.replace(/%s/i,b)},ordinal:function(a){return this._ordinal.replace("%d",a)},_ordinal:"%d",preparse:function(a){return a},
postformat:function(a){return a},week:function(a){return A(a,this._week.dow,this._week.doy).week},_week:{dow:0,doy:6},_invalidDate:"Invalid date",invalidDate:function(){return this._invalidDate}});e=function(a,b,c,d){"boolean"===typeof c&&(d=c,c=void 0);return ia({_i:a,_f:b,_l:c,_strict:d,_isUTC:!1})};e.utc=function(a,b,c,d){"boolean"===typeof c&&(d=c,c=void 0);return ia({_useUTC:!0,_isUTC:!0,_l:c,_i:a,_f:b,_strict:d}).utc()};e.unix=function(a){return e(1E3*a)};e.duration=function(a,b){var c=a,d=
null,f;if(e.isDuration(a))c={ms:a._milliseconds,d:a._days,M:a._months};else if("number"===typeof a)c={},b?c[b]=a:c.milliseconds=a;else if(d=Ka.exec(a))f="-"===d[1]?-1:1,c={y:0,d:h(d[q])*f,h:h(d[n])*f,m:h(d[u])*f,s:h(d[x])*f,ms:h(d[y])*f};else if(d=La.exec(a))f="-"===d[1]?-1:1,c=function(a){a=a&&parseFloat(a.replace(",","."));return(isNaN(a)?0:a)*f},c={y:c(d[2]),M:c(d[3]),d:c(d[4]),h:c(d[5]),m:c(d[6]),s:c(d[7]),w:c(d[8])};d=new C(c);e.isDuration(a)&&a.hasOwnProperty("_lang")&&(d._lang=a._lang);return d};
e.version="2.5.0";e.defaultFormat="YYYY-MM-DDTHH:mm:ssZ";e.updateOffset=function(){};e.lang=function(a,b){if(!a)return e.fn._lang._abbr;if(b){var c=G(a);b.abbr=c;v[c]||(v[c]=new S);v[c].set(b)}else null===b?(delete v[a],a="en"):v[a]||p(a);return(e.duration.fn._lang=e.fn._lang=p(a))._abbr};e.langData=function(a){a&&(a._lang&&a._lang._abbr)&&(a=a._lang._abbr);return p(a)};e.isMoment=function(a){return a instanceof B};e.isDuration=function(a){return a instanceof C};for(j=oa.length-1;0<=j;--j)sa(oa[j]);
e.normalizeUnits=function(a){return l(a)};e.invalid=function(a){var b=e.utc(NaN);null!=a?m(b._pf,a):b._pf.userInvalidated=!0;return b};e.parseZone=function(a){return e(a).parseZone()};m(e.fn=B.prototype,{clone:function(){return e(this)},valueOf:function(){return+this._d+6E4*(this._offset||0)},unix:function(){return Math.floor(+this/1E3)},toString:function(){return this.clone().lang("en").format("ddd MMM DD YYYY HH:mm:ss [GMT]ZZ")},toDate:function(){return this._offset?new Date(+this):this._d},toISOString:function(){var a=
e(this).utc();return 0<a.year()&&9999>=a.year()?I(a,"YYYY-MM-DD[T]HH:mm:ss.SSS[Z]"):I(a,"YYYYYY-MM-DD[T]HH:mm:ss.SSS[Z]")},toArray:function(){return[this.year(),this.month(),this.date(),this.hours(),this.minutes(),this.seconds(),this.milliseconds()]},isValid:function(){return X(this)},isDSTShifted:function(){return this._a?this.isValid()&&0<V(this._a,(this._isUTC?e.utc(this._a):e(this._a)).toArray()):!1},parsingFlags:function(){return m({},this._pf)},invalidAt:function(){return this._pf.overflow},
utc:function(){return this.zone(0)},local:function(){this.zone(0);this._isUTC=!1;return this},format:function(a){a=I(this,a||e.defaultFormat);return this.lang().postformat(a)},add:function(a,b){var c;c="string"===typeof a?e.duration(+b,a):e.duration(a,b);D(this,c,1);return this},subtract:function(a,b){var c;c="string"===typeof a?e.duration(+b,a):e.duration(a,b);D(this,c,-1);return this},diff:function(a,b,c){var a=H(a,this),d=6E4*(this.zone()-a.zone()),f,b=l(b);"year"===b||"month"===b?(f=432E5*(this.daysInMonth()+
a.daysInMonth()),d=12*(this.year()-a.year())+(this.month()-a.month()),d+=(this-e(this).startOf("month")-(a-e(a).startOf("month")))/f,d-=6E4*(this.zone()-e(this).startOf("month").zone()-(a.zone()-e(a).startOf("month").zone()))/f,"year"===b&&(d/=12)):(f=this-a,d="second"===b?f/1E3:"minute"===b?f/6E4:"hour"===b?f/36E5:"day"===b?(f-d)/864E5:"week"===b?(f-d)/6048E5:f);return c?d:s(d)},from:function(a,b){return e.duration(this.diff(a)).lang(this.lang()._abbr).humanize(!b)},fromNow:function(a){return this.from(e(),
a)},calendar:function(){var a=H(e(),this).startOf("day"),a=this.diff(a,"days",!0);return this.format(this.lang().calendar(-6>a?"sameElse":-1>a?"lastWeek":0>a?"lastDay":1>a?"sameDay":2>a?"nextDay":7>a?"nextWeek":"sameElse",this))},isLeapYear:function(){return F(this.year())},isDST:function(){return this.zone()<this.clone().month(0).zone()||this.zone()<this.clone().month(5).zone()},day:function(a){var b=this._isUTC?this._d.getUTCDay():this._d.getDay();return null!=a?(a=ga(a,this.lang()),this.add({d:a-
b})):b},month:function(a){var b=this._isUTC?"UTC":"",c;if(null!=a){if("string"===typeof a&&(a=this.lang().monthsParse(a),"number"!==typeof a))return this;c=this.date();this.date(1);this._d["set"+b+"Month"](a);this.date(Math.min(c,this.daysInMonth()));e.updateOffset(this);return this}return this._d["get"+b+"Month"]()},startOf:function(a){a=l(a);switch(a){case "year":this.month(0);case "month":this.date(1);case "week":case "isoWeek":case "day":this.hours(0);case "hour":this.minutes(0);case "minute":this.seconds(0);
case "second":this.milliseconds(0)}"week"===a?this.weekday(0):"isoWeek"===a&&this.isoWeekday(1);return this},endOf:function(a){a=l(a);return this.startOf(a).add("isoWeek"===a?"week":a,1).subtract("ms",1)},isAfter:function(a,b){b="undefined"!==typeof b?b:"millisecond";return+this.clone().startOf(b)>+e(a).startOf(b)},isBefore:function(a,b){b="undefined"!==typeof b?b:"millisecond";return+this.clone().startOf(b)<+e(a).startOf(b)},isSame:function(a,b){b=b||"ms";return+this.clone().startOf(b)===+H(a,this).startOf(b)},
min:function(a){a=e.apply(null,arguments);return a<this?this:a},max:function(a){a=e.apply(null,arguments);return a>this?this:a},zone:function(a){var b=this._offset||0;if(null!=a)"string"===typeof a&&(a=ea(a)),16>Math.abs(a)&&(a*=60),this._offset=a,this._isUTC=!0,b!==a&&D(this,e.duration(b-a,"m"),1,!0);else return this._isUTC?b:this._d.getTimezoneOffset();return this},zoneAbbr:function(){return this._isUTC?"UTC":""},zoneName:function(){return this._isUTC?"Coordinated Universal Time":""},parseZone:function(){this._tzm?
this.zone(this._tzm):"string"===typeof this._i&&this.zone(this._i);return this},hasAlignedHourOffset:function(a){a=a?e(a).zone():0;return 0===(this.zone()-a)%60},daysInMonth:function(){var a=this.year(),b=this.month();return(new Date(Date.UTC(a,b+1,0))).getUTCDate()},dayOfYear:function(a){var b=w((e(this).startOf("day")-e(this).startOf("year"))/864E5)+1;return null==a?b:this.add("d",a-b)},quarter:function(){return Math.ceil((this.month()+1)/3)},weekYear:function(a){var b=A(this,this.lang()._week.dow,
this.lang()._week.doy).year;return null==a?b:this.add("y",a-b)},isoWeekYear:function(a){var b=A(this,1,4).year;return null==a?b:this.add("y",a-b)},week:function(a){var b=this.lang().week(this);return null==a?b:this.add("d",7*(a-b))},isoWeek:function(a){var b=A(this,1,4).week;return null==a?b:this.add("d",7*(a-b))},weekday:function(a){var b=(this.day()+7-this.lang()._week.dow)%7;return null==a?b:this.add("d",a-b)},isoWeekday:function(a){return null==a?this.day()||7:this.day(this.day()%7?a:a-7)},get:function(a){a=
l(a);return this[a]()},set:function(a,b){a=l(a);if("function"===typeof this[a])this[a](b);return this},lang:function(a){if(void 0===a)return this._lang;this._lang=p(a);return this}});for(j=0;j<P.length;j++)ka(P[j].toLowerCase().replace(/s$/,""),P[j]);ka("year","FullYear");e.fn.days=e.fn.day;e.fn.months=e.fn.month;e.fn.weeks=e.fn.week;e.fn.isoWeeks=e.fn.isoWeek;e.fn.toJSON=e.fn.toISOString;m(e.duration.fn=C.prototype,{_bubble:function(){var a=this._milliseconds,b=this._days,c=this._months,d=this._data;
d.milliseconds=a%1E3;a=s(a/1E3);d.seconds=a%60;a=s(a/60);d.minutes=a%60;a=s(a/60);d.hours=a%24;b+=s(a/24);d.days=b%30;c+=s(b/30);d.months=c%12;b=s(c/12);d.years=b},weeks:function(){return s(this.days()/7)},valueOf:function(){return this._milliseconds+864E5*this._days+2592E6*(this._months%12)+31536E6*h(this._months/12)},humanize:function(a){var b=+this,c;c=!a;var d=this.lang(),e=w(Math.abs(b)/1E3),i=w(e/60),g=w(i/60),h=w(g/24),j=w(h/365),e=45>e&&["s",e]||1===i&&["m"]||45>i&&["mm",i]||1===g&&["h"]||
22>g&&["hh",g]||1===h&&["d"]||25>=h&&["dd",h]||45>=h&&["M"]||345>h&&["MM",w(h/30)]||1===j&&["y"]||["yy",j];e[2]=c;e[3]=0<b;e[4]=d;c=Fa.apply({},e);a&&(c=this.lang().pastFuture(b,c));return this.lang().postformat(c)},add:function(a,b){var c=e.duration(a,b);this._milliseconds+=c._milliseconds;this._days+=c._days;this._months+=c._months;this._bubble();return this},subtract:function(a,b){var c=e.duration(a,b);this._milliseconds-=c._milliseconds;this._days-=c._days;this._months-=c._months;this._bubble();
return this},get:function(a){a=l(a);return this[a.toLowerCase()+"s"]()},as:function(a){a=l(a);return this["as"+a.charAt(0).toUpperCase()+a.slice(1)+"s"]()},lang:e.fn.lang,toIsoString:function(){var a=Math.abs(this.years()),b=Math.abs(this.months()),c=Math.abs(this.days()),d=Math.abs(this.hours()),e=Math.abs(this.minutes()),h=Math.abs(this.seconds()+this.milliseconds()/1E3);return!this.asSeconds()?"P0D":(0>this.asSeconds()?"-":"")+"P"+(a?a+"Y":"")+(b?b+"M":"")+(c?c+"D":"")+(d||e||h?"T":"")+(d?d+"H":
"")+(e?e+"M":"")+(h?h+"S":"")}});for(j in Q)Q.hasOwnProperty(j)&&(la(j,Q[j]),Ja(j.toLowerCase()));la("Weeks",6048E5);e.duration.fn.asMonths=function(){return(+this-31536E6*this.years())/2592E6+12*this.years()};e.lang("en",{ordinal:function(a){var b=a%10,b=1===h(a%100/10)?"th":1===b?"st":2===b?"nd":3===b?"rd":"th";return a+b}});Y?(module.exports=e,N(!0)):"function"===typeof define&&define.amd?define("moment",function(a,b,c){c.config&&(c.config()&&!0!==c.config().noGlobal)&&N(void 0===c.config().noGlobal);
return e}):N()}).call(this);
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'confluence.web.resources:date-time-formatting', location = '/includes/js/date-time-formatting/date-time-formatting.js' */
var AJS=AJS||{};
AJS.DateTimeFormatting={wholeMinutesBetween:function(a,b){return Math.floor((b.valueOf()-a.valueOf())/6E4)},roundedHoursBetween:function(a,b){return Math.round((b.valueOf()-a.valueOf())/36E5)},isYesterdayRelativeTo:function(a,b,d){a=new Date(a.valueOf()+d);b=new Date(b.valueOf()+d-864E5);return a.getUTCFullYear()==b.getUTCFullYear()&&a.getUTCMonth()==b.getUTCMonth()&&a.getUTCDate()==b.getUTCDate()},formatTime:function(a,b){return moment(a.valueOf()+b).utc().format("h:mm A")},formatDate:function(a,b){return moment(a.valueOf()+
b).utc().format("MMM DD, YYYY")},formatDateTime:function(a,b){return moment(a.valueOf()+b).utc().format("MMM DD, YYYY HH:mm")},friendlyFormatDateTime:function(a,b,d){var c=b.valueOf()-a.valueOf();return 0>c?AJS.DateTimeFormatting.formatDateTime(a,d):0==c?"right now":4E3>c?"just a moment ago":6E4>c?"less than a minute ago":12E4>c?"a minute ago":3E6>c?AJS.format("{0} minutes ago",AJS.DateTimeFormatting.wholeMinutesBetween(a,
b)):54E5>c?"about an hour ago":18E6<c&&AJS.DateTimeFormatting.isYesterdayRelativeTo(a,b,d)?AJS.format("yesterday at {0}",AJS.DateTimeFormatting.formatTime(a,d)):864E5>c?AJS.format("about {0} hours ago",AJS.DateTimeFormatting.roundedHoursBetween(a,b)):AJS.DateTimeFormatting.formatDate(a,d)}};
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-previews:fileviewer-core', location = '/bower_components/atlassian-fileviewer/dist/fileviewer-templates.js' */
// This file was automatically generated from main_view.i18n.soy.
// Please don't edit this file by hand.

/**
 * @fileoverview Templates in namespace FileViewer.Templates.
 */

if (typeof FileViewer == 'undefined') { var FileViewer = {}; }
if (typeof FileViewer.Templates == 'undefined') { FileViewer.Templates = {}; }


FileViewer.Templates.fileView = function(opt_data, opt_ignored) {
  return '<div id="cp-header" class="aui-group"></div><div id="cp-body" class="aui-group"></div><div id="cp-footer"></div>';
};
if (goog.DEBUG) {
  FileViewer.Templates.fileView.soyTemplateName = 'FileViewer.Templates.fileView';
}


FileViewer.Templates.titleContainer = function(opt_data, opt_ignored) {
  return '<span class="' + soy.$$escapeHtml(opt_data.iconClass) + ' size-24 cp-file-icon"></span>' + soy.$$escapeHtml(opt_data.title);
};
if (goog.DEBUG) {
  FileViewer.Templates.titleContainer.soyTemplateName = 'FileViewer.Templates.titleContainer';
}


FileViewer.Templates.controlDownloadButton = function(opt_data, opt_ignored) {
  return '<a id="cp-control-panel-download" href="' + soy.$$escapeHtml(opt_data.src) + '" title="' + soy.$$escapeHtml("Download") + '" class="cp-icon" target="_blank" download></a>';
};
if (goog.DEBUG) {
  FileViewer.Templates.controlDownloadButton.soyTemplateName = 'FileViewer.Templates.controlDownloadButton';
}


FileViewer.Templates.controlCloseButton = function(opt_data, opt_ignored) {
  return '<a id="cp-control-panel-close" href="#" title="' + soy.$$escapeHtml("Close") + '" class="cp-icon"></a>';
};
if (goog.DEBUG) {
  FileViewer.Templates.controlCloseButton.soyTemplateName = 'FileViewer.Templates.controlCloseButton';
}


FileViewer.Templates.moreButton = function(opt_data, opt_ignored) {
  return '<a href="cp-more-menu" id="cp-control-panel-more" aria-owns="cp-more-menu" aria-haspopup="true" class="cp-icon aui-dropdown2-trigger aui-dropdown2-trigger-arrowless" title="' + soy.$$escapeHtml("More") + '">' + soy.$$escapeHtml("More") + '</a><div id="cp-more-menu" class="aui-dropdown2 aui-style-default"><ul class="aui-list-truncate"></ul></div>';
};
if (goog.DEBUG) {
  FileViewer.Templates.moreButton.soyTemplateName = 'FileViewer.Templates.moreButton';
}


FileViewer.Templates.moreMenuItem = function(opt_data, opt_ignored) {
  return '<li><a href="#">' + soy.$$escapeHtml(opt_data.text) + '</a></li>';
};
if (goog.DEBUG) {
  FileViewer.Templates.moreMenuItem.soyTemplateName = 'FileViewer.Templates.moreMenuItem';
}


FileViewer.Templates.fileComments = function(opt_data, opt_ignored) {
  return '<div id="cp-comments"/>';
};
if (goog.DEBUG) {
  FileViewer.Templates.fileComments.soyTemplateName = 'FileViewer.Templates.fileComments';
}


FileViewer.Templates.fileBodySpinner = function(opt_data, opt_ignored) {
  return '<div class="cp-spinner"></div>';
};
if (goog.DEBUG) {
  FileViewer.Templates.fileBodySpinner.soyTemplateName = 'FileViewer.Templates.fileBodySpinner';
}


FileViewer.Templates.fileBodyArrows = function(opt_data, opt_ignored) {
  return '<a href="#" class="cp-nav" id="cp-nav-left" disabled-title="' + soy.$$escapeHtml("You\'re viewing the least recent file") + '">' + soy.$$escapeHtml("Go to the previous file") + '</a><a href="#" class="cp-nav" id="cp-nav-right" disabled-title="' + soy.$$escapeHtml("You\'re viewing the most recent file") + '">' + soy.$$escapeHtml("Go to the next file") + '</a>';
};
if (goog.DEBUG) {
  FileViewer.Templates.fileBodyArrows.soyTemplateName = 'FileViewer.Templates.fileBodyArrows';
}
// This file was automatically generated from unknown-file-type-view.i18n.soy.
// Please don't edit this file by hand.

/**
 * @fileoverview Templates in namespace FileViewer.Templates.
 */

if (typeof FileViewer == 'undefined') { var FileViewer = {}; }
if (typeof FileViewer.Templates == 'undefined') { FileViewer.Templates = {}; }


FileViewer.Templates.unknownFileTypeViewer = function(opt_data, opt_ignored) {
  return '<div id="cp-unknown-file-type-view"><span class="file-icon size-96 ' + soy.$$escapeHtml(opt_data.iconClass) + '"></span><p class="title">' + soy.$$escapeHtml("We can\'t preview this file.") + '<br>' + soy.$$escapeHtml("You\'ll have to download the file to view it.") + '</p><a class="aui-button download-button" href="' + soy.$$escapeHtml(opt_data.src) + '" target="_blank" download><span class="aui-icon aui-icon-small icon-download"></span>' + soy.$$escapeHtml("Download") + '</a></div><span class="cp-baseline-extension"></span>';
};
if (goog.DEBUG) {
  FileViewer.Templates.unknownFileTypeViewer.soyTemplateName = 'FileViewer.Templates.unknownFileTypeViewer';
}
// This file was automatically generated from layers.i18n.soy.
// Please don't edit this file by hand.

/**
 * @fileoverview Templates in namespace FileViewer.Templates.
 */

if (typeof FileViewer == 'undefined') { var FileViewer = {}; }
if (typeof FileViewer.Templates == 'undefined') { FileViewer.Templates = {}; }


FileViewer.Templates.displayError = function(opt_data, opt_ignored) {
  return '<div id="cp-error-message">' + ((opt_data.icon) ? '<span class="file-icon size-96 ' + soy.$$escapeHtml(opt_data.icon) + '"></span>' : '<span class="file-icon size-96 cp-unknown-file-type-icon"></span>') + '<p class="title">' + soy.$$escapeHtml(opt_data.title) + '</p><p class="message">' + soy.$$escapeHtml(opt_data.message) + '</p>' + ((opt_data.srcBrowser) ? '<a class="aui-button download-button" href="' + soy.$$escapeHtml(opt_data.srcBrowser) + '" target="_blank"><span class="aui-icon aui-icon-small icon-download"></span>' + soy.$$escapeHtml("Open in browser") + '</a>' : '') + ((opt_data.srcDownload) ? '<a class="aui-button download-button" href="' + soy.$$escapeHtml(opt_data.srcDownload) + '" target="_blank" download><span class="aui-icon aui-icon-small icon-download"></span>' + soy.$$escapeHtml("Download") + '</a>' : '') + '</div><span class="cp-baseline-extension"></span>';
};
if (goog.DEBUG) {
  FileViewer.Templates.displayError.soyTemplateName = 'FileViewer.Templates.displayError';
}


FileViewer.Templates.passwordLayer = function(opt_data, opt_ignored) {
  return '<div id="cp-preview-password"><span class="cp-password-lock-icon"></span><div class="cp-password-base"><p class="title">' + soy.$$escapeHtml(opt_data.prompt) + '</p><input type="password" name="password" class="cp-password-input" placeholder="' + soy.$$escapeHtml("Password") + '" autocomplete="off"><button class="aui-button cp-password-button">' + soy.$$escapeHtml("OK") + '</button></div><div class="cp-password-fullscreen"><p class="title">' + soy.$$escapeHtml("This file is password protected.") + '</p><p class="message">' + soy.$$escapeHtml("Due to technical reasons you have to leave presentation mode to enter the password.") + '</p></div></div><span class="cp-baseline-extension"></span>';
};
if (goog.DEBUG) {
  FileViewer.Templates.passwordLayer.soyTemplateName = 'FileViewer.Templates.passwordLayer';
}


FileViewer.Templates.waitingMessage = function(opt_data, opt_ignored) {
  return '<div id="cp-waiting-message"><span class="file-icon size-96 cp-waiting-message-spinner"></span><p class="title">' + soy.$$escapeHtml(opt_data.header) + '</p><p class="message">' + soy.$$escapeHtml(opt_data.message) + '</p><a class="aui-button download-button" href="' + soy.$$escapeHtml(opt_data.src) + '" target="_blank" download><span class="aui-icon aui-icon-small icon-download"></span>' + soy.$$escapeHtml("Download") + '</a></div><span class="cp-baseline-extension"></span>';
};
if (goog.DEBUG) {
  FileViewer.Templates.waitingMessage.soyTemplateName = 'FileViewer.Templates.waitingMessage';
}


FileViewer.Templates.toolbar = function(opt_data, opt_ignored) {
  var output = '<div class="cp-toolbar">';
  var actionList55 = opt_data.actions;
  var actionListLen55 = actionList55.length;
  for (var actionIndex55 = 0; actionIndex55 < actionListLen55; actionIndex55++) {
    var actionData55 = actionList55[actionIndex55];
    output += '<a href="#" class="' + soy.$$escapeHtml(actionData55.className) + ' cp-icon" title="' + soy.$$escapeHtml(actionData55.title) + '">' + soy.$$escapeHtml(actionData55.title) + '</a>';
  }
  output += '</div>';
  return output;
};
if (goog.DEBUG) {
  FileViewer.Templates.toolbar.soyTemplateName = 'FileViewer.Templates.toolbar';
}

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-previews:fileviewer-core', location = '/bower_components/atlassian-fileviewer/dist/fileviewer.js' */
(function () {
    'use strict';

// holds module definitions used for setup and dependency tracking
var _modules = {};

// defines a new module with the given dependencies and factory function
var define = function (name, dependencies, factoryFn) {
    _modules[name] = {
      deps: dependencies,
      factory: factoryFn,
      value: null
    };
};

// recursively require module and its dependencies
// caches the results so that every module is instantiated only once
var require = function (name, mocks) {
    var module = require._normalizeMocks(mocks)[name] || _modules[name];
    if (!module) { throw new Error('module not found ' + name); }
    if (!module.value) {
      module.value = module.factory.apply(null, module.deps.map(function (name) {
        return require(name, mocks);
      }));
    }
    return module.value;
};

require._normalizeMocks = function (mocks) {
  if (!mocks) { return {}; }
  var normalizedMocks = {};
  Object.keys(mocks).forEach(function (key) {
    normalizedMocks[key] = {
      deps: [],
      factory: function () { return mocks[key]; },
      value: null
    };
  });
  return normalizedMocks;
};

// define FileViewer dependencies
define('jquery',     [], function () { return jQuery;   });
define('underscore', [], function () { return _;        });
define('backbone',   [], function () { return Backbone; });
define('ajs',        [], function () { return AJS;      });

define('Analytics', ['underscore'], function (_) {
    'use strict';

    /**
     * Augments data and forwards them to a configured analytics backend.
     *
     * An analytics backend is just a function that accepts a key and a data
     * object. It is also responsible for filtering incoming data.
     *
     * For all data send, this module fetches current file and view state
     * and adds them to the data. The added keys are
     * - fileType
     * - fileId (hashed version of the file src)
     * - fileState (value of view state)
     *
     * @param analyticsBackend
     * @param fileViewer
     * @param hasher
     * @returns {Analytics}
     * @constructor
     */
    var Analytics = function (backend, fileViewer, hasher) {
        this._backend = backend;
        this._fileViewer = fileViewer;
        this._hasher = hasher;
    };

    /**
     * Forwards an analytics event to the configured backend.
     * @param {string} key
     * @param {Object} data
     */
    Analytics.prototype.send = function (key, data) {
        if (!this._backend) { return; }
        var file = this._fileViewer.getCurrentFile();
        var attributes = (file && file.attributes) || {};
        var augmentedData = _.extend({
            fileType: attributes.type,
            fileId: this._hasher(attributes.src || ''),
            fileState: this._fileViewer.getView().getViewState()
        }, data);
        this._backend(key, augmentedData)
    };

    /**
     * Returns a partially applied analytics function for use inside of
     * promise handlers.
     * @param {string} key
     * @param {object} data
     * @returns {function}
     */
    Analytics.prototype.fn = function (key, data) {
        return this.send.bind(this, key, data);
    };

    return Analytics;
});




define('ArrowLayer', [
    'backbone', 'template-store-singleton'
], function (
    Backbone, templateStore
) {
    'use strict';

    /**
     * Controls to switch between multiple files in a collection.
     * @constructor
     */
    var ArrowLayer = Backbone.View.extend({

        className: 'cp-arrow-layer',

        events: {
            'click #cp-nav-left:not(.disabled)': 'gotoPrevious',
            'click #cp-nav-right:not(.disabled)': 'gotoNext'
        },

        initialize: function (options) {
            this._fileViewer = options.fileViewer;
            this.listenTo(this._fileViewer._fileState.collection, 'add reset', this.checkAndHideNavigation);
            this._visibleArrows = false;
            this._updateElements();
        },

        render: function () {
            this.$el.html(templateStore.get('fileBodyArrows')()).hide();
            this._updateElements();
            this.checkAndHideNavigation();

            this.$el.on("click", "a[href='#']", function(e) {
                e.preventDefault();
            });

            return this;
        },

        /**
         * Show next file in collection.
         */
        gotoNext: function () {
            this._fileViewer.showFileNext().always(
                this._fileViewer.analytics.fn('files.fileviewer-web.next', {
                    actionType: 'button',
                    mode: this._fileViewer.getMode()
                })
            );
        },

        /**
         * Show previous file in collection.
         */
        gotoPrevious: function () {
            this._fileViewer.showFilePrev().always(
                this._fileViewer.analytics.fn('files.fileviewer-web.prev', {
                    actionType: 'button',
                    mode: this._fileViewer.getMode()
                })
            );
        },

        /**
         * Enable disabled navigation arrow again and remove tooltip
         */
        enableArrow: function ($arrow) {
            $arrow.removeClass('disabled');
            $arrow.removeAttr('original-title');
        },

        /**
         * Disable navigation arrow and add tooltip
         * @param  {Object} options
         * @param  {Object} options.arrow
         * @param  {String} options.tooltipText
         * @param  {String} options.tooltipGravity
         */
        disableArrow: function (options) {
            options.arrow.addClass('disabled');
            options.arrow.attr('original-title', options.tooltipText);
            options.arrow.tooltip({ gravity: options.tooltipGravity });
        },

        /**
         * Returns true if either the left or right navigation arrow is shown
         * @return {Boolean}
         */
        showsArrow: function () {
            return this._visibleArrows;
        },

        /**
         * Check if controls should appear.
         * If there's only a single file in the collection, we don't show them.
         */
        checkAndHideNavigation: function () {
            if (this._fileViewer._fileState.collection.length <= 1) {
                this._visibleArrows = false;
                return this.$arrows.hide();
            }
            this.$arrows.show();
            this._visibleArrows = true;
            if (this._fileViewer.getConfig().enableListLoop) {
                return;
            }
            if (this._fileViewer.isShowingLastFile()) {
                this.disableArrow({
                    arrow: this.$arrowRight,
                    tooltipText: "You\'re viewing the most recent file",
                    tooltipGravity: 'e'
                });
            } else if (this._fileViewer.isShowingFirstFile()) {
                this.disableArrow({
                    arrow: this.$arrowLeft,
                    tooltipText: "You\'re viewing the least recent file",
                    tooltipGravity: 'w'
                });
            }
        },

        _updateElements: function () {
            this.$arrows = this.$el.find('.cp-nav');
            this.$arrowLeft = this.$el.find('#cp-nav-left');
            this.$arrowRight = this.$el.find('#cp-nav-right');
        }

    });

    return ArrowLayer;
});

define('assert',
    [],
    function() {

        /**
         * Throws an error if given predicate is falsy.
         *
         * @param {*} predicate
         * @param {string} description Used for the error message.
         */
        var assert = function (predicate, description) {
            description = description || 'untruthy value';

            if (!predicate) {
                throw new Error('Assertion failed: ' + description);
            }
        };

        return assert;
    }
);
define('asset-module-backend', [], function () {
    'use strict';

    return function (fileViewer) {

        /**
         * Assumes that all modules are included as static assets and therefore
         * already loaded. Uses FileViewer.getConfig().assets for the
         * module configuration.
         *
         * @param {String} moduleName
         * @return {Promise}
         */

        return function (moduleName) {
            if (moduleName === 'pdf-config') {
                return fileViewer.getConfig().assets['pdf-config'] || {};
            }
        };
    };

});
define('baseMode', ['jquery', 'keys'], function ($, keys) {
    'use strict';

    var baseMode = {

        activateHook: function (mainView) {
            mainView.$el.on('click #cp-file-body', mainView._onClickToBackground.bind(mainView));
            var $arrowLayer = mainView.fileContentView.getLayerForName('arrows').$el;
            $arrowLayer.toggle(this.showsArrowLayer);
        },

        deactivateHook: function (mainView) {
            mainView.$el.off('click #cp-file-body');
        },

        setup: function (mainView, viewer) {
            viewer && viewer.$el.on("click.contentView", viewer._clickedBackgroundToClose.bind(viewer));
            $(document).on('keydown.modeKeys', this._handleKeys.bind(mainView));
        },

        teardown: function (mainView, viewer) {
            viewer && viewer.$el.off("click.contentView");
            $(document).off('keydown.modeKeys');
        },

        showsArrowLayer: true,

        _handleKeys: function (e) {
            var contentView, viewer;

            if (this.fileContentView.isLayerInitialized('content')) {
                contentView = this.fileContentView.getLayerForName('content');
                viewer = contentView.getAttachedViewer();
            }

            if (!viewer || !(e.ctrlKey || e.metaKey)) { return; }

            if (e.which === keys.PLUS || e.which === keys.PLUS_NUMPAD || e.which === keys.PLUS_FF) {
                if (viewer.zoomIn) {
                    this._fileViewer.analytics.send('files.fileviewer-web.file.zoomin', {
                        actionType: 'hotkey'
                    });
                    viewer.zoomIn();
                }
                e.preventDefault();
            }

            if (e.which === keys.MINUS || e.which === keys.MINUS_NUMPAD || e.which === keys.MINUS_FF) {
                if (viewer.zoomOut) {
                    this._fileViewer.analytics.send('files.fileviewer-web.file.zoomout', {
                        actionType: 'hotkey'
                    });
                    viewer.zoomOut();
                }
                e.preventDefault();
            }

        },

        toolbarActions: [
            {
                title: "Zoom out",
                className: 'cp-toolbar-minus',
                predicate: function () {
                    return this._viewer && this._viewer.zoomOut;
                },
                handler: function () {
                    if (this._viewer && this._viewer.zoomOut) {
                        this._fileViewer.analytics.send('files.fileviewer-web.file.zoomout', {
                            actionType: 'button'
                        });
                        this._viewer.zoomOut();
                    }
                }
            },
            {
                title: "Zoom in",
                className: 'cp-toolbar-plus',
                predicate: function () {
                    return this._viewer && this._viewer.zoomIn;
                },
                handler: function () {
                    if (this._viewer && this._viewer.zoomIn) {
                        this._fileViewer.analytics.send('files.fileviewer-web.file.zoomin', {
                            actionType: 'button'
                        });
                        this._viewer.zoomIn();
                    }
                }
            },
            {
                title: "Fit to page width",
                className: 'cp-toolbar-fit',
                predicate: function () {
                    return this._viewer && this._viewer.zoomFit;
                },
                handler: function () {
                    if (this._viewer && this._viewer.zoomFit) {
                        this._fileViewer.analytics.send('files.fileviewer-web.file.fittowidth');
                        this._viewer.zoomFit();
                    }
                }
            },
            {
                title: "Start Presentation",
                className: 'cp-toolbar-presentation',
                predicate: function () {
                    return this._viewer && this._fileViewer.getConfig().enablePresentationMode;
                },
                handler: function () {
                    this._fileViewer.analytics.send('files.fileviewer-web.presentation.enter');
                    this._fileViewer.changeMode('PRESENTATION');
                }
            }
        ]
    };

    return baseMode;
});

define('BaseViewer', [
    'jquery', 'underscore', 'backbone'
], function ($, _, Backbone) {
    'use strict';

    /**
     * Base class for viewers.
     * @constructor
     */
    var BaseViewer = Backbone.View.extend({

        // Event listeners specific to this view namespaced to prevent collisions with its children.

        contentViewEvents: {
            'click.contentView': '_clickedBackgroundToClose',
            'mousedown.contentView': '_mousedownContentView'
        },

        // Merge events with children's event object to bind all event handlers

        initialize: function (options) {
            this.events = _.extend(this.events || {}, this.contentViewEvents);

            this._fileViewer = options.fileViewer;
            this._previewSrc = options.previewSrc;
            this._mousedownBackground = null;
        },

        teardown: function () {},

        // Listen to clicks to the background and eventually close the fileViewer.
        //
        // A viewer can specify getBackground if their background element isn't their contents

        _mousedownContentView: function (e) {
            var $background = this.getBackground ? this.getBackground() : this.$el;
            this._mousedownBackground = $(e.target).is($background);
        },

        _clickedBackgroundToClose: function (e) {
            // @TODO: Remove after cleaning modes setup, hooks etc.
            var mode = this._fileViewer._view._modes[this._fileViewer._view._mode];
            if (mode.disableClickBackgroundCloses) {
                return;
            }
            var $background = this.getBackground ? this.getBackground() : this.$el;
            if (this._mousedownBackground && $(e.target).is($background)){
                this._fileViewer.analytics.send('files.fileviewer-web.closed', {
                    actionType: 'element'
                });
                this._fileViewer.close();
            }
        },

        // This function is called whenever the viewport of the viewer changes size,
        // e.g. when a panel is opened or closed. Overwrite this function if you want
        // custom behaviour.
        handleResize: function () {}

    });

    return BaseViewer;
});

define('CloseButton', [
    'backbone', 'template-store-singleton'
], function (Backbone, templateStore) {
    'use strict';

    var CloseButton = Backbone.View.extend({

        className: 'fv-close-button',

        events: {
            'click': '_close'
        },

        tagName: 'span',

        initialize: function (options) {
            this._fileViewer = options.fileViewer;
        },

        render: function () {
            this.$el.html(templateStore.get('controlCloseButton')());

            this.$('a').tooltip({ gravity: 'n' });

            return this;
        },

        _close: function (e) {
            e.preventDefault();
            this._fileViewer.analytics.send('files.fileviewer-web.closed', {
                actionType: 'button'
            });
            this._fileViewer.close();
        }
    });

    return CloseButton;
});
define('defaultConfig', [], function() {
    /**
     * Current configuration options:
     * 
     * - appendTo {DOMNode} [$('body')] - DOM Element to append to
     * - enableListLoop {Boolean} [true] - Allow to navigate from end to start of file list and v.v.
     * - enablePresentationMode {Boolean} [true] - Allow switching to presentation mode
     * - files {Array} - File objects
     * - commentService {Object} - Comments service
     * - templateBackend {Function} - Provides templates for a given name
     * - moduleBackend {Function} - Provides modules for a given name
     * - pdfTransportFactory {Function} - cb(currentFile):Promise<PDFTransport>
     *
     * @exports defaultConfig
     */
    return {
        enableListLoop: true,
        enablePresentationMode: true,
        preloadImagesAfterCurrent: 2,
        preloadImagesBeforeCurrent: 0,
        viewers: ['image', 'document', 'video']
    };
});

define('constants-dictionary', [
    'assert'
], function (
    assert
) {
    'use strict';

    /**
     * A constants dictionary is a dictionary where you can only define a
     * given name once.
     */
    var ConstantsDictionary = function () {
        this._valuesByName = {};
        this._names = [];
    };

    /**
     * Define a name with the given value.
     * @param {string} name The name that is being defined.
     * @param {*} value Any value, even undefined.
     * @throws Error if name is already defined.
     */
    ConstantsDictionary.prototype.define = function (name, value) {
        assert(!this.isDefined(name), 'name is unique');
        this._valuesByName[name] = value;
        this._names.push(name);
    };

    /**
     * Lookup a name with the given value.
     * @param {string} name The name to lookup.
     * @throws Error if name is not yet defined.
     */
    ConstantsDictionary.prototype.lookup = function (name) {
        assert(this.isDefined(name), 'name is defined');
        return this._valuesByName[name];
    };

    /**
     * Check if a name is defined.
     * @param {string} name The name to check.
     * @return {boolean}
     */
    ConstantsDictionary.prototype.isDefined = function (name) {
        return name in this._valuesByName;
    };

    /**
     * Lists all definitions in the order they were defined. Returns an array of objects
     * with name and value properties.
     * @return {Array}
     */
    ConstantsDictionary.prototype.list = function () {
        return this._names.map(function (name) {
            return {
                name: name,
                value: this._valuesByName[name]
            };
        }, this);
    };

    return ConstantsDictionary;
});
define('djb2', [], function () {

    var toCharCode = function (str) { return str.charCodeAt(0); };
    var updateHash = function (prev, curr) { return ((prev << 5) + prev) + curr; };

    /**
     * Create a djb2 hash from the given string.
     * Based on this module https://github.com/wearefractal/djb2.
     * @param {String} str
     * @returns {Number}
     */
    var djb2 = function (str) {
        return str.split('').map(toCharCode).reduce(updateHash, 5381);
    };

    return djb2;
});
define('DownloadButton', [
    'backbone', 'template-store-singleton'
], function (Backbone, templateStore) {
    'use strict';

    var DownloadButton = Backbone.View.extend({

        tagName: 'span',

        events: {
            'click': '_triggerAnalytics'
        },

        initialize: function (options) {
            this._fileViewer = options.fileViewer;
            this._model = this._fileViewer.getCurrentFile();
        },

        render: function () {
            this.$el.html(templateStore.get('controlDownloadButton')({
                src: this._model.get('srcDownload') || this._model.get('src')
            }));

            this.$('a').tooltip({ gravity: 'n' });

            return this;
        },

        _triggerAnalytics: function () {
            this._fileViewer.trigger('fv.download');
            this._fileViewer.analytics.send('files.fileviewer-web.file.download', {
                actionType: 'button'
            });
        }

    }, {
        isDownloadable: function (fileViewer) {
            var file = fileViewer.getCurrentFile();
            return file && file.get('downloadable');
        }
    });

    return DownloadButton;
});

define('ErrorLayer', [
    'ajs', 'backbone', 'template-store-singleton'
], function (AJS, Backbone, templateStore) {
    'use strict';

    var ErrorLayer = Backbone.View.extend({

        className: 'cp-error-layer',

        initialize: function () {
            this.$el.hide();
        },

        showErrorMessage: function (err, file) {
            var title, description, icon, srcDownload, srcBrowser;
            title = err.title || "File can not be displayed";
            description = err.description || err.toString();
            icon = err.icon || false;
            srcBrowser = err.browser ? file.get('src') : false;
            srcDownload = err.download ? file.get('src') : false;
            this.$el.show().html(templateStore.get('displayError')({
                title: title,
                message: description,
                icon: icon,
                srcBrowser: srcBrowser,
                srcDownload: srcDownload
            }));
        }

    });

    return ErrorLayer;
});

define("file-state",
    [
        "backbone"
    ],
    function(
        Backbone
        ) {
        "use strict";

        var FileState = Backbone.Model.extend({

            defaults: {
                currentFileIndex: -1,
                isNewFileUploaded: false
            },

            setCollection: function(collection) {
                this.collection = collection;
            },

            setNext: function() {
                var currentFileIndex = this.get("currentFileIndex");
                if (currentFileIndex < (this.collection.length - 1)) {
                    this.set({currentFileIndex: this.get("currentFileIndex") + 1});
                } else {
                    this.set({currentFileIndex: 0});
                }
            },

            setPrev: function() {
                var currentFileIndex = this.get("currentFileIndex");
                if (currentFileIndex > 0) {
                    this.set({currentFileIndex: this.get("currentFileIndex") - 1});
                } else {
                    this.set({currentFileIndex: this.collection.length - 1});
                }
            },

            setNoCurrent: function () {
                this.set({ currentFileIndex: -1 });
            },

            setCurrentFileIndex: function(index) {
                if ((index > -1) && (index < this.collection.length)) {
                    return this.set({currentFileIndex: index});
                }
            },

            setCurrentWithCID: function(cid) {
                return this.setCurrentFileIndex(this.collection.getIndexWithCID(cid));
            },

            getCurrent: function() {
                var current = this.collection.at(this.get("currentFileIndex"));
                return (!!current) ? current : null;
            },

            selectWhere: function (selector) {
                if (selector) {
                    var selected = this.collection.findWhere(selector);
                    if (selected) {
                        this.setCurrentWithCID(selected.cid);
                    }
                } else if (this.collection.length >= 1) {
                    this.setCurrentFileIndex(0);
                }
            },

            replaceCurrent: function(file) {
                var idx = this.get("currentFileIndex");
                this.collection.remove(this.collection.at(idx));
                this.collection.add(file, {at: idx});
            }
            // hasFile or how to deal with non existing file?
        });

        return FileState;
    });
define("file-types", [
    ],
    function(
        ) {
        "use strict";

        var browserSupportedImageTypes = [
          "image/gif",
          "image/jpeg",
          "image/png",
          "image/svg+xml",
          "image/web",
          "image/bmp"
        ];

        var fileTypes = {
            isPDF: function (type) {
                var lowerType = type && type.toLowerCase() || "";
                return lowerType === "application/pdf";
            },

            isText: function (type) {
                var lowerType = type && type.toLowerCase() || "";
                return lowerType === "text/plain";
            },

            isCode: function (type) {
                var lowerType = type && type.toLowerCase() || "";
                return lowerType === "text/java"
                  || lowerType === "text/css"
                  || lowerType === "text/html"
                  || lowerType === "text/javascript"
                  || lowerType === "text/xml";
            },

            isMultimedia: function (type) {
                var lowerType = type && type.toLowerCase() || "";
                return /^video\/.*/i.test(type)
                  || /^audio\/.*/i.test(type)
                  || lowerType === "application/x-shockwave-flash"
                  || lowerType === "application/vnd.rn-realmedia"
                  || lowerType === "application/x-oleobject";
            },

            isArchive: function (type) {
                var lowerType = type && type.toLowerCase() || "";
                return lowerType === "application/zip"
                  || lowerType === "application/java-archive";
            },

            isImage: function (type) {
                return /^image\/.*/i.test(type);
            },

            isVideo: function (type) {
                var lowerType = type && type.toLowerCase() || "";
                return /^video\/.*/i.test(type) || lowerType === "video";
            },

            isAudio: function (type) {
                var lowerType = type && type.toLowerCase() || "";
                return /^audio\/.*/i.test(type) || lowerType === "audio";
            },

            isImageBrowserSupported: function (type) {
                return browserSupportedImageTypes.indexOf(type.toLowerCase()) !== -1;
            },

            isWordProcessing: function(type) {
                var lowerType = type && type.toLowerCase() || "";
                return lowerType === "application/msword"
                  || /^application\/vnd.ms-word.*/i.test(type)
                  || /^application\/vnd.openxmlformats-officedocument.wordprocessingml.*/i.test(type);
            },

            isSpreadsheet: function(type) {
                var lowerType = type && type.toLowerCase() || "";
                return lowerType === "application/msexcel"
                  || /^application\/vnd.ms-excel.*/i.test(type)
                  || /^application\/vnd.openxmlformats-officedocument.spreadsheet.*/i.test(type);
            },

            isPresentation: function(type) {
                var lowerType = type && type.toLowerCase() || "";
                return lowerType === "application/mspowerpoint"
                  || /^application\/vnd.ms-powerpoint.*/i.test(type)
                  || /^application\/vnd.openxmlformats-officedocument.presentationml.*/i.test(type);
            },

            matchAll: function () { return true; }
        };

        return fileTypes;
    });
define('file-viewer', [
    'jquery',
    'underscore',
    'backbone',
    'assert',
    'constants-dictionary',
    'MainView',
    'file-state',
    'files',
    'file',
    'soy-template-backend',
    'asset-module-backend',
    'template-store-singleton',
    'module-store-singleton',
    'viewer-registry',
    'file-types',
    'defaultConfig',
    'image-view-provider',
    'pdf-view-provider',
    'video-view-provider',
    'unknown-file-type-view-provider',
    'Analytics',
    'djb2'
],
/**
 * FileViewer is a pluggable utility to view files in your app. This module
 * provides the central object you need to interact with.
 */
function (
    $,
    _,
    Backbone,
    assert,
    ConstantsDictionary,
    MainView,
    FileState,
    Files,
    File,
    soyTemplateBackend,
    assetModuleBackend,
    templateStore,
    moduleStore,
    ViewerRegistry,
    fileTypes,
    defaultConfig,
    imageViewProvider,
    pdfViewProvider,
    videoViewProvider,
    unknownFileTypeViewProvider,
    Analytics,
    djb2
) {
    'use strict';

    /**
     * Core API to integrate FileViewer into a project.
     * @class
     * @param {object} config
     * @throws Error if config is invalid
     */
    var FileViewer = function (config) {
        config = _.defaults(config || {}, defaultConfig);
        config.appendTo = config.appendTo || $('body');

        templateStore.useBackend(config.templateBackend || soyTemplateBackend(this));
        moduleStore.useBackend(config.moduleBackend || assetModuleBackend(this));

        this._config = config;
        this._properties = new Backbone.Model();

        this._fileState = new FileState();
        this._viewerRegistry = new ViewerRegistry();
        this._analytics = new Analytics(config.analyticsBackend, this, djb2);

        if (config.viewers.indexOf('image') !== -1) {
            this._viewerRegistry.register(fileTypes.isImageBrowserSupported, imageViewProvider, 0);
        }
        if (config.viewers.indexOf('document') !== -1) {
            this._viewerRegistry.register(fileTypes.isPDF, pdfViewProvider, 0);
        }
        if (config.viewers.indexOf('video') !== -1) {
            this._viewerRegistry.register(fileTypes.isMultimedia, videoViewProvider, 0);
        }

        // set fallback viewer
        this._viewerRegistry.register(fileTypes.matchAll, unknownFileTypeViewProvider, 100);

        this._files = new Files(config.files || [], {
            service: config.commentService
        });
        this._fileState.setCollection(this._files);

        this._view = new MainView({ fileViewer: this });

        this._isOpen = false;

        FileViewer._plugins.list()
            .map(function (definition) { return definition.value; })
            .forEach(function (plugin) { plugin(this); }, this);
    };

    // privately expose available modules for debugging purposes
    FileViewer._modules = _modules;

    /**
     * Define a new module for the use with FileViewer.require().
     * Be careful with the naming, because module names can be overwritten.
     * @method
     * @param {String} moduleName
     * @param {Array} dependencies
     * @param {Function} factory
     */
    FileViewer.define = define;

    /**
     * Require a previously defined module by name.
     * @method
     * @param {String} moduleName
     * @return {*}
     */
    FileViewer.require = require;

    // Keeps track of registered plugins
    FileViewer._plugins = new ConstantsDictionary();

    FileViewer.VERSION = 'v1.2.1';

    /**
     * Register a new plugin for use with FileViewer.
     * @param {string} name
     * @param {function} plugin
     * @throws Error if plugin is invalid or name already exists.
     */
    FileViewer.registerPlugin = function (name, plugin) {
        assert(this.isPlugin(plugin), 'is a plugin');
        this._plugins.define(name, plugin);
    };

    /**
     * Returns if a plugin is enabled for use with FileViewer.
     * @param {string} name
     */
    FileViewer.isPluginEnabled = function (name) {
        return this._plugins.isDefined(name);
    };

    /**
     * Gets a plugin registered for use with FileViewer.
     * @param {string} name
     * @throws Error if plugin is invalid or name does not already exists.
     */
    FileViewer.getPlugin = function (name) {
        return this._plugins.lookup(name);
    };

    /**
     * Checks if the given object is a valid plugin.
     * @param {*} potentialPlugin
     * @return {boolean}
     */
    FileViewer.isPlugin = function (potentialPlugin) {
        return _.isFunction(potentialPlugin);
    };

    /**
     * Open this instance of FileViewer by appending it to the configured element. This needs to be called
     * before showing a file.
     *
     * When a fileQuery object is passed in, this file is shown and a special analytics event is triggered.
     * When you want to record, where this interaction is comming from, pass in
     * an additional analyticsSource
     *
     * @param {object} [fileQuery]
     * @param {string} [analyticsSource]
     * @fires fv.open
     */
    FileViewer.prototype.open = function (fileQuery, analyticsSource) {
        this._view.render().show().$el.appendTo(this._config.appendTo);
        this._view.delegateEvents();

        this._isOpen = true;
        this.trigger('fv.open');

        if (fileQuery) {
            this.showFileWithQuery(fileQuery).always(
                this.analytics.fn('files.fileviewer-web.opened', {source: analyticsSource})
            );
        }
    };

    /**
     * Shut down this instance of FileViewer by removing it from the configured element. Reset current file.
     *
     * @fires fv.close
     */
    FileViewer.prototype.close = function () {
        this._view._currentFile = null;
        this._view.undelegateEvents();
        this._view
            .hide()
            .$el.remove();

        this._isOpen = false;
        this.trigger('fv.close');
    };

    /**
     * Check if FileViewer is currently open.
     * @returns {boolean}
     */
    FileViewer.prototype.isOpen = function () {
        return this._isOpen;
    };

    /**
     * Return the current mode.
     * @returns {string}
     */
    FileViewer.prototype.getMode = function () {
        return this._view.getMode();
    };

    /**
     * Check if FileViewer is in the given mode.
     * @param {string} mode either 'BASE' or 'PRESENTATION'
     * @returns {boolean}
     */
    FileViewer.prototype.isInMode = function (mode) {
        return this._view.isInMode(mode);
    };

    /**
     * Change current view mode to the given mode.
     * @param {string} mode either 'BASE' or 'PRESENTATION'
     * @fires fv.changeMode
     */
    FileViewer.prototype.changeMode = function (mode) {
        this._view.setupMode(mode);
        this.trigger('fv.changeMode', mode);
    };

    /**
     * Check if current file is the first one in the files collection.
     * @return {Boolean}
     */
    FileViewer.prototype.isShowingFirstFile = function () {
        return this._fileState.attributes.currentFileIndex === 0;
    };

    /**
     * Check if current file is the last one in the files collection.
     * @return {Boolean}
     */
    FileViewer.prototype.isShowingLastFile = function () {
        return this._fileState.collection.length ===
            this._fileState.attributes.currentFileIndex + 1;
    };

    /**
     * Show the given file.
     *
     * THIS METHOD WILL NOT CHANGE THE STATE OF THE CURRENT FILE AND SHOULD NOT
     * BE CALLED DIRECTLY ANYMORE. CONSIDER IT AS A PRIVATE METHOD.
     *
     * @param {File} file
     * @return {Promise<file>} given file if a proper viewer was created.
     * @fires fv.showFile(file) after the viewer is created
     * @deprecated
     */
    FileViewer.prototype.showFile = function (file) {
        assert(this._isOpen, 'FileViewer is open');
        var triggerEvent = function (event) {
            return function () {
                this.trigger(event, file);
            }.bind(this);
        }.bind(this);
        this.trigger('fv.changeFile', file);
        return this._view.showFile(file)
          .done(triggerEvent("fv.showFile"))
          .fail(triggerEvent("fv.showFileError"));
    };

    /**
     * Returns the file being shown in this viewer.
     * @return {File} the file being shown
     */
    FileViewer.prototype.getCurrentFile = function() {
        // this file may not be the same as in fileState, e.g., a different version of file
        return this._view.getCurrentFile();
    };

    /**
     * ShowFile utility method; Show the first file matching the given selector. If no selector
     * given, it shows the first file in the collection.
     */
    FileViewer.prototype.showFileWhere = function (selector) {
        this._fileState.selectWhere(selector);
        return this.showFile(this._fileState.getCurrent());
    };

    /**
     * ShowFile utility method; Show the file matching the given backbone object id.
     * @todo remove this method
     */
    FileViewer.prototype.showFileWithCID = function (cid) {
        this._fileState.setCurrentWithCID(cid);
        return this.showFile(this._fileState.getCurrent());
    };

    /**
     * ShowFile utility method; Show the file matching the given id.
     * @todo remove this method
     */
    FileViewer.prototype.showFileWithId = function (id, ownerId) {
        var fileQuery = { id: id };

        if (ownerId) { fileQuery.ownerId = ownerId; }

        return this.showFileWithQuery(fileQuery);
    };

    /**
     * ShowFile utility method.  Show file with matching URL.  Used for
     * showing files that don't have an id (e.g. web images).
     */
    FileViewer.prototype.showFileWithSrc = function (src) {
        var fileQuery = { src: src };

        return this.showFileWithQuery(fileQuery);
    };

    /**
     * Check if the FileViewer supports native rendering of a given content type.
     * @param {string} contentType the content type to check if supported
     * @return {boolean} if it's supported
     */
    FileViewer.prototype.supports = function (contentType) {
        var previewer = this._viewerRegistry.get(contentType);
        return previewer && previewer !== unknownFileTypeViewProvider;
    };

    /**
     * ShowFile utility method.  Show file that matches the given attribute query.
     */
    FileViewer.prototype.showFileWithQuery = function (query) {
        var file = this._fileState.collection.findWhere(query);

        if (file) {
            this._fileState.setCurrentWithCID(file.cid);
        } else {
            this._fileState.setNoCurrent();
        }

        return this.showFile(file);
    };

    /*
     * ShowFile utility method; Show the next file in the collection.
     */
    FileViewer.prototype.showFileNext = function () {
        if (this.isShowingLastFile() && !this.getConfig().enableListLoop) {
            return $.when();
        }
        this._fileState.setNext();
        return this.showFile(this._fileState.getCurrent());
    };

    /*
     * ShowFile utility method; Show the previous file in the collection.
     */
    FileViewer.prototype.showFilePrev = function () {
        if (this.isShowingFirstFile() && !this.getConfig().enableListLoop) {
            return $.when();
        }
        this._fileState.setPrev();
        return this.showFile(this._fileState.getCurrent());
    };

    /**
     * Set the files in the FileViewer collection.
     *
     * This doesn't re-render the current file. If the file being shown is not
     * in the collection anymore, it will still be shown.
     * @param {array} files
     * @fires fv.updateFiles
     */
    FileViewer.prototype.updateFiles = function (files, matcher) {
        if (!(matcher && _.isFunction(matcher))) {
                this._files.reset(files);
        } else {
            var newModels = _.chain(files)
                .map(function (file) {
                    var matchedModel = this._files.find(function (collectionModel) {
                        return matcher(collectionModel.toJSON()) === matcher(file);
                    });
                    if (matchedModel) {
                        matchedModel.set(file);
                    } else {
                        return new File(file);
                    }
                }.bind(this))
                .compact()
                .value();

            this._files.add(newModels, {silent: true});
            this._files.trigger('reset', this._files);
        }

        this.trigger('fv.updateFiles');

        return this._files.toJSON();
    };

    /**
     * Support .on(), .off() and .trigger().
     */
    _.extend(FileViewer.prototype, Backbone.Events);

    /**
     * Returns the central view of FileViewer.
     * @return {MainView}
     *
     * @too kind of confusing, someone might expect it to return various views by name
     */
    FileViewer.prototype.getView = function () {
        return this._view;
    };

    /**
     * Returns the specified config.
     * @return {object}
     */
    FileViewer.prototype.getConfig = function () {
        return this._config;
    };

    /**
     * Returns the current files collection.
     * @return {array}
     */
    FileViewer.prototype.getFiles = function () {
        return this._files.toJSON();
    };

    /**
     * Add a file action to the viewer. These actions can be registered
     * asynchronously, and are reset when the user navigates to a new file.
     * Commonly, a plugin will listen to the change file event and register a file action
     * conditionally for the displayed file. If a file action shares a key with a file
     * action that currently exists, addFileAction will replace the old action with the
     * new action.
     *
     * Current configuration options:
     * 'key' Unique identifier for the file action
     * 'text' {String} the text display in the menu item
     * 'callback' {function} a callback to be called when the menu item is selected
     *
     * @param {object} opts
     * @throws Error if config is invalid or if no file is currently being viewed
     */
    FileViewer.prototype.addFileAction = function (opts) {
        assert(opts.key, 'has key');
        assert(opts.text, 'has text');
        assert(opts.callback, 'has a callback');
        this._view.fileControlsView.getLayerForName('moreButton').addFileAction(opts);
    };

    /**
     * Remove a file action from the viewer based on the key sent in the parameter
     *
     * Current configuration options:
     * 'key' Unique identifier for the file action you want to remove
     *
     * @param {object} opts
     * @throws Error if no key is provided or if no file is currently being viewed
     */
    FileViewer.prototype.removeFileAction = function (opts) {
        assert(opts.key, 'has key');
        this._view.fileControlsView.getLayerForName('moreButton').removeFileAction(opts);
    };

    /**
     * Allows non-core code to get and set their own values on an instance of FileViewer.
     *
     * @param {String} key
     * @param {*} value
     */
    FileViewer.prototype.set = function (key, value) {
        this._properties.set(key, value);
    };

    /**
     * Access plugin level properties.
     *
     * @param {String} key
     * @return {*}
     */
    FileViewer.prototype.get = function (key) {
        return this._properties.get(key);
    };

    /**
     * Instance of the analytics module, use this to send analytics from
     * your plugins.
     */
    Object.defineProperty(FileViewer.prototype, 'analytics', {
        get: function () { return this._analytics; }
    });

    return FileViewer;
});

define("file",
    [
        "backbone"
    ],
    function(
        Backbone
        ) {
        "use strict";

    var File = Backbone.Model.extend({
        defaults: {
            src: '',
            type: '',
            thumbnail: '',
            poster: '',
            title: '',
            downloadable: true
        }
    });

    return File;
});

define("files",
    [
        "backbone",
        "underscore",
        "file"
    ],
    function(
        Backbone,
        _,
        File) {

        "use strict";

        var Files = Backbone.Collection.extend({
            model: File,

            comparator: 'rank',

            getIndexWithCID: function(cid) {
                return this.indexOf(this.get({cid: cid}));
            }
        });

        return Files;

});
define("icon-utils", [
      "file-types"
  ],
  function (fileTypes) {
      "use strict";

      var iconUtils = {
          getCssClass: function (type) {
              var iconClass = "cp-unknown-file-type-icon";
              if (fileTypes.isImage(type)) {
                  iconClass = "cp-image-icon";
              } else if (fileTypes.isPDF(type)) {
                  iconClass = "cp-pdf-icon";
              } else if (fileTypes.isWordProcessing(type)) {
                  iconClass = "cp-document-icon";
              } else if (fileTypes.isSpreadsheet(type)) {
                  iconClass = "cp-spreadsheet-icon";
              } else if (fileTypes.isPresentation(type)) {
                  iconClass = "cp-presentation-icon";
              } else if (fileTypes.isText(type)) {
                  iconClass = "cp-text-icon";
              } else if (fileTypes.isCode(type)) {
                  iconClass = "cp-code-icon";
              } else if (fileTypes.isMultimedia(type)) {
                  iconClass = "cp-multimedia-icon";
              } else if (fileTypes.isArchive(type)) {
                  iconClass = "cp-archive-icon";
              }
              return iconClass;
          }
      };
      return iconUtils;
  });
define('image-view-provider', [
    'jquery',
    'file'
], function (
    $,
    File
) {
    'use strict';

    /**
     * Returns an image viewer.
     * @returns {Promise}
     */
    var imageViewProvider = function () {
        return $.Deferred().resolve(require('image-view'));
    };

    return imageViewProvider;
});
define('instance-manager',
    ['jquery'],
    function ($) {
        'use strict';

        /**
         * Ensures that there's only a single instance at the same time.
         * Accepts a createFn that is invoked and whose return value is
         * used as the instance.
         * @constructor
         * @param {Function} createFn
         * @param {Function} destroyFn
         */
        var InstanceManager = function (createFn, destroyFn) {
            this._createFn = createFn;
            this._destroyFn = destroyFn;
            this._instance = null;
            this._destroyDeferred = null;
        };

        /**
         * Promise a new instance. Resolves as soon as the previous one
         * is destroyed.
         * @return {Promise<Object>}
         */
        InstanceManager.prototype.create = function () {
            var args = arguments;
            var d = new $.Deferred();
            var destroyPromise = (this._destroyDeferred && this._destroyDeferred.promise()) || $.when();

            destroyPromise.then(function () {
                this._destroyDeferred = new $.Deferred();
                this._instance = this._createFn.apply(this._createFn, args);
                d.resolve(this._instance);
            }.bind(this));

            return d.promise();
        };

        /**
         * Destroy the current instance and unlock instance creation.
         */
        InstanceManager.prototype.destroy = function () {
            if (!this._destroyDeferred) {
                return;
            }
            this._destroyFn(this._instance);
            this._destroyDeferred.resolve();
        };

        return InstanceManager;

    }
);

define('keys', [], function() {
    return {
        F: 70,
        G: 71,
        P: 80,
        RETURN: 13,
        ESCAPE: 27,
        ARROW_LEFT: 37,
        ARROW_UP: 38,
        ARROW_RIGHT: 39,
        ARROW_DOWN: 40,
        PLUS: 187,
        MINUS: 189,
        PLUS_NUMPAD: 107,
        MINUS_NUMPAD: 109,
        PLUS_FF: 61,
        MINUS_FF: 173,
        SPACE: 32,
        ENTER: 13
    };
});

define('layer-container-view', [
    'underscore',
    'backbone',
    'assert',
    'constants-dictionary'
], function (
    _,
    Backbone,
    assert,
    ConstantsDictionary
) {
    'use strict';

    // utility functions for working with layers

    var invoke = function (fn) {
        return fn();
    };

    var pick = function (property, obj) {
        return obj[property];
    };

    var pickBoundFn = function (property, obj) {
        return _.isFunction(obj[property]) && obj[property].bind(obj);
    };

    /**
     * This view manages a collection of views which can be registered with a
     * given name. This view manages the lifecycle of its subviews.
     *
     * Subviews are always the View objects themselves, not instances of them.
     *
     * Subviews have two different states: ADDED and INITIALIZED. Whenever a
     * view is registered, it starts in state ADDED and stays there until
     * #initializeLayers() is called. Then it moves to INITIALIZED and stays
     * there until #teardownLayers() is called.
     *
     * When #render() is called on the collection, only INITIALIZED subviews are
     * rendered. Subviews can provide a teardown method that will be called
     * once the view is removed.
     *
     * Optionally, you can register subviews with a predicate to tell which
     * filetypes they support. It is invoked whenever the subviews are
     * initialized.
     */
    var FileContentLayerView = Backbone.View.extend({

        /**
         * @constructor
         * @param {object} options
         */
        initialize: function (options) {
            this._layerViewsByName = new ConstantsDictionary();
            this._layerViewRegistrations = [];
            this._layers = null;
            this._fileViewer = options.fileViewer;
        },

        /**
         * Checks if a layer with the given name exists.
         * @param {string} name
         * @return {bool}
         */
        hasLayerView: function (name) {
            return this._layerViewsByName.isDefined(name);
        },

        /**
         * Adds a view as a layer with a certain, unique name. Accepts an
         * options object as third parameter.
         *
         * Keys in options:
         *  - {function} [predicate] invoked at construction
         *  - {int} [weight=0] sorts layers at construction
         *
         * @param {string} name
         * @param {Backbone.View} LayerView
         * @param {object} [options]
         * @throws Error if name is already used.
         */
        addLayerView: function (name, LayerView, options) {
            assert(!this.hasLayerView(name), 'name is unique');

            options = _.extend({
                predicate: function () { return true; },
                weight: 0
            }, options);

            this._layerViewsByName.define(name, LayerView);
            this._layerViewRegistrations.push({
                LayerView: LayerView,
                name: name,
                predicate: options.predicate,
                weight: options.weight
            });
        },

        /**
         * Checks wether layers are currently initialized.
         * @return {bool}
         */
        areLayersInitialized: function () {
            return this._layers !== null;
        },

        /**
         * Return the number of initialized layers (after applying the predicate)/
         * @return {Integer}
         */
        countInitializedLayers: function () {
            return (this._layers || []).length;
        },

        /**
         * Initializes all currently registered layers.
         * @fires initializeLayers
         * @throws Error if layers are already initialized
         */
        initializeLayers: function () {
            this.initializeLayerSubset(_.pluck(this._layerViewRegistrations, 'name'));
        },

        /**
         * Initializes the given registered layers.
         * @param {array} names
         * @fires initializeLayers
         * @throws Error if layers are already initialized
         */
        initializeLayerSubset: function (names) {
            assert(!this.areLayersInitialized(), 'layers are uninitialized');

            this._layers = this._layerViewRegistrations
                                .filter(function (registration) {
                                    var isInSubset = (names.indexOf(registration.name) !== -1);
                                    return isInSubset && registration.predicate(this._fileViewer);
                                }, this)
                                .map(function (registration) {
                                    var view = new registration.LayerView({
                                        contentLayerView: this,
                                        fileViewer: this._fileViewer
                                    });
                                    return {
                                        view: view,
                                        name: registration.name,
                                        weight: registration.weight
                                    };
                                }, this);

            // sort by weight using the stable _.sortBy function to keep
            // registration order for same weights
            this._layers = _.sortBy(this._layers, function (layer) {
                return layer.weight * -1;
            });

            this.trigger('initializeLayers');

            this.render();
        },

        /**
         * Tears initialized layers down and removes them.
         * Won't throw if layers are not initialized.
         * @fires teardownLayers
         */
        teardownLayers: function () {
            if (this.areLayersInitialized()) {
                this._layers.map(_.partial(pick, 'view'))
                            .map(_.partial(pickBoundFn, 'teardown'))
                            .filter(_.isFunction)
                            .forEach(invoke);

                this._layers.map(_.partial(pick, 'view'))
                            .map(_.partial(pickBoundFn, 'remove'))
                            .filter(_.isFunction)
                            .forEach(invoke);

                this._layers = null;
            }

            this.trigger('teardownLayers');

            this.render();
        },

        /**
         * Utitily method. Calls teardownLayers() followed by initializeLayers().
         */
        reinitializeLayers: function () {
            this.teardownLayers();
            this.initializeLayers();
        },

        /**
         * Checks wether a layer with the given name is currently initialized.
         * @param {string} name
         * @return {bool}
         */
        isLayerInitialized: function (name) {
            if (!this.areLayersInitialized()) { return false; }

            return _.find(this._layers, function (layer) {
                return layer.name === name;
            }) ? true : false;
        },

        /**
         * Returns the instanciated LayerView object for the given name.
         * @param {string} name Name of the registered LayerView.
         * @return {layerView}
         * @throws {Error} if layer is not initialized
         */
        getLayerForName: function (name) {
            assert(this.areLayersInitialized(), 'layers are initialized');
            assert(this.hasLayerView(name), 'layer is defined');

            var layer = _.find(this._layers, function (layer) {
                return layer.name === name;
            });

            assert(layer, 'layer is initialized');

            return layer.view;
        },

        /**
         * Renders initialized layers.
         * Won't throw if layers are not initialized.
         * @fires renderLayers
         */
        render: function () {
            this.$el.empty();

            if (this.areLayersInitialized()) {
                this._layers.map(_.partial(pick, 'view'))
                            .map(_.partial(pickBoundFn, 'render'))
                            .forEach(invoke);

                this._layers.map(_.partial(pick, 'view'))
                            .map(_.partial(pick, '$el'))
                            .forEach(function ($layer) {
                                this.$el.append($layer);
                            }, this);
            }

            this.trigger('renderLayers');

            return this;
        }

    });

    return FileContentLayerView;
});
define("MainView",
    [
        "ajs",
        "backbone",
        "underscore",
        "jquery",
        "files",
        "file",
        "TitleView",
        "DownloadButton",
        "CloseButton",
        "MoreButton",
        "ViewerLayer",
        "panel-container-view",
        "layer-container-view",
        "ErrorLayer",
        "WaitingLayer",
        "PasswordLayer",
        "ArrowLayer",
        "ToolbarLayer",
        "SpinnerLayer",
        "template-store-singleton",
        "keys",
        "baseMode",
        "presentationMode"
    ],
    function(
        AJS,
        Backbone,
        _,
        $,
        Files,
        File,
        TitleView,
        DownloadButton,
        CloseButton,
        MoreButton,
        ViewerLayer,
        PanelContainerView,
        LayerContainerView,
        ErrorLayer,
        WaitingLayer,
        PasswordLayer,
        ArrowLayer,
        ToolbarLayer,
        SpinnerLayer,
        templateStore,
        keys,
        baseMode,
        presentationMode
    ) {
        "use strict";

        var rejectWithError = function (msg) {
            return new $.Deferred().reject(
                new Error(msg)
            ).promise();
        };

        /**
         * Core view of FileViewer.
         * @constructor
         * @param {Object} params
         */
        var MainView = Backbone.View.extend({

            id: "cp-container",

            initialize: function (params) {
                var options = _.extend({}, params);

                this._fileViewer = options.fileViewer;
                this._currentFile = null;
                this._viewState = null;

                this.$el.attr({
                    "role": "dialog",
                    "aria-labelledby": "cp-title-container"
                });

                this.fileTitleView = new PanelContainerView({
                    fileViewer: this._fileViewer,
                    id: "cp-title-container",
                    className: "aui-item"
                });

                this.fileControlsView = new LayerContainerView({
                    fileViewer: this._fileViewer,
                    id: "cp-file-controls",
                    className: "aui-item"
                });

                this.fileMetaView = new LayerContainerView({
                    fileViewer: this._fileViewer,
                    id: "cp-meta"
                });

                this.fileSinkView = new PanelContainerView({
                    id: 'cp-sink',
                    collection: this._fileViewer._fileState.collection,
                    fileViewer: this._fileViewer
                });

                this.fileSidebarView = new PanelContainerView({
                    id: "cp-sidebar",
                    fileViewer: this._fileViewer,
                    collection: this._fileViewer._fileState.collection
                });

                this.fileContentView = new LayerContainerView({
                    id: 'cp-file-body',
                    fileViewer: this._fileViewer
                });

                this.fileTitleView.addPanelView('title', TitleView);
                this.fileControlsView.addLayerView('downloadButton', DownloadButton, {
                    weight: 10,
                    predicate: DownloadButton.isDownloadable
                });
                this.fileControlsView.addLayerView('moreButton', MoreButton);
                this.fileControlsView.addLayerView('closeButton', CloseButton);
                this.fileContentView.addLayerView('content', ViewerLayer);
                this.fileContentView.addLayerView('error', ErrorLayer);
                this.fileContentView.addLayerView('password', PasswordLayer);
                this.fileContentView.addLayerView('toolbar', ToolbarLayer);
                this.fileContentView.addLayerView('waiting', WaitingLayer);
                this.fileContentView.addLayerView('spinner', SpinnerLayer);
                this.fileContentView.addLayerView('arrows', ArrowLayer);

                this.listenTo(this.fileSidebarView, 'togglePanel', this._updateContentWidth);
                this.listenTo(this.fileSinkView, 'togglePanel', this._updateContentHeight);

                this._navigationKeyLockCount = 0;
                this._showFileChain = $.when();

                this._mode = 'BASE';
                this._modes = {
                    'BASE': baseMode,
                    'PRESENTATION': presentationMode
                };

                this._fixTooltipCleanup();
            },

            /**
             * Show.
             * @return {MainView} this
             */
            show: function() {
                this.$el.show();
                $("body").addClass("no-scroll");

                $(document).on('keydown.disableDefaultKeys', this._disableKeyboardShortcuts.bind(this));
                $(document).on('keydown.navKeys', this._handleNavigationKeys.bind(this));

                return this;
            },

            /**
             * Hide.
             * @return {MainView} this
             */
            hide: function() {
                this.$el.hide();
                $("body").removeClass("no-scroll");

                $(document).off('keydown.disableDefaultKeys');
                $(document).off('keydown.navKeys');
                $(document).off('keydown.modeKeys');

                this._deactivateModeHook();
                this._modes[this._mode].teardown(this);
                this._teardownAll();

                return this;
            },

            /**
             * Render.
             * @return {MainView} this
             */
            render: function () {
                this.$el.empty().append(templateStore.get('fileView')());

                this.$header = this.$('#cp-header');
                this.$body = this.$('#cp-body');
                this.$footer = this.$('#cp-footer');

                this.$title = this.fileTitleView.render().$el.appendTo(this.$header);
                this.$controls = this.fileControlsView.render().$el.appendTo(this.$header);

                this.$content = this.fileContentView.render().$el.appendTo(this.$body);
                this.$sidebar = this.fileSidebarView.render().$el.appendTo(this.$body);

                this.$meta = this.fileMetaView.render().$el.appendTo(this.$footer);
                this.$sink = this.fileSinkView.render().$el.appendTo(this.$footer);

                this.$el.on("click", "a[href='#']", function (e) {
                    e.preventDefault();
                });

                return this;
            },

            /**
             * Show the given file. If one of the following conditions is true
             *
             *   1. file is invalid
             *   2. no viewer for that fileType is registered
             *   3. the viewer code can't be loaded
             *   4. the viewer couldn't be created
             *
             * then the returned promise is rejected. In that case, fileView changes
             * state and displays the error internally.
             *
             * @param {File} file
             * @return {Promise<File>} the given file
             */
            showFile: function (file) {

                var contentView, toolbarView, spinnerView, waitingView, errorView;

                // allow people to shut down themselves
                this.trigger('cancelShow');

                var fileViewed = new $.Deferred();

                this._showFileChain.pipe(function () {
                    var fileHandled = new $.Deferred();
                    $.when().pipe(function validateFile () {

                        this._currentFile = file;
                        this._viewState = null;
                        var validationResult;

                        if (file) {
                            this.trigger("fv.fileChange", file);
                            this._reinitializeAllSubviews();
                            contentView = this.fileContentView.getLayerForName('content');
                            toolbarView = this.fileContentView.getLayerForName('toolbar');
                            spinnerView = this.fileContentView.getLayerForName('spinner');
                            waitingView = this.fileContentView.getLayerForName('waiting');
                        } else {
                            this._viewState = 'fileNotFound';
                            this._reinitializeCoreSubviews();
                            validationResult = rejectWithError("File does not exist");
                        }
                        errorView = this.fileContentView.getLayerForName('error');
                        this._deactivateModeHook();
                        this._activateModeHook();
                        return validationResult;
                    }.bind(this))
                    .pipe(function getConverted () {
                        var isPreviewGenerated = this._fileViewer.getConfig().isPreviewGenerated;
                        var generatePreview = this._fileViewer.getConfig().generatePreview;

                        spinnerView.startSpin();

                        if (this._fileViewer.supports(file.get("type"))) {
                            return $.when(file.get("src"), file.get("type"));
                        }

                        if (!(isPreviewGenerated && generatePreview)) {
                            return $.when(file.get("src"), file.get("type"));
                        }

                        return isPreviewGenerated(file).pipe(function (isGenerated, source, type) {
                            if (isGenerated) {
                                return $.when(source, type);
                            }

                            spinnerView.stopSpin();
                            waitingView.showMessage(
                                file,
                                "Your preview is on its way!",
                                "In a hurry? You can download the original right now"
                            );

                            return generatePreview(file).always(function () {
                                waitingView.clearMessage();
                                spinnerView.startSpin();
                            });
                        });

                    }.bind(this))
                    .pipe(function lookupViewer (previewSrc, previewType) {
                        var convertedFile = new File(file.toJSON());

                        convertedFile.set('type', previewType);
                        convertedFile.set('src', previewSrc);
                        file = convertedFile;

                        var loadViewer = this._fileViewer._viewerRegistry.get(previewType);

                        if (!loadViewer) {
                            return rejectWithError("Can not find a viewer for given file");
                        }
                        var dfd = $.Deferred();
                        loadViewer().then(function (Viewer) {
                            dfd.resolve(Viewer, previewSrc)
                        }).fail( function () {
                            dfd.fail(arguments);
                        });

                        return dfd.promise();
                    }.bind(this))
                    .pipe(function createViewer (Viewer, previewSrc) {

                        var readyDeferred = new $.Deferred();
                        var view = new Viewer({
                            previewSrc: previewSrc,
                            model: new File(file.toJSON()),
                            fileViewer: this._fileViewer
                        });

                        view.once('viewerReady', function () {
                            this._viewState = 'success';
                            toolbarView.setViewer(view);
                            this.setupMode(this._mode);
                            readyDeferred.resolve(file);
                        }.bind(this));
                        view.once('viewerFail', function (err) {
                            this._viewState = 'viewerError';
                            readyDeferred.reject(err);
                            this.setupMode(this._mode);
                        }.bind(this));

                        contentView.attachViewer(view);

                        view.render();

                        return readyDeferred.promise();

                    }.bind(this))
                    .always(function () {
                        spinnerView && spinnerView.stopSpin();
                        waitingView && waitingView.clearMessage();
                    }.bind(this))
                    .fail(function (err) {
                        fileViewed.reject(err);
                        if (err !== "cancelled") {
                            errorView.showErrorMessage(err, file);
                        }
                    }.bind(this))
                    .done(function() {
                        fileViewed.resolve(file);
                    })
                    .always(function () {
                        fileHandled.resolve();
                    }.bind(this));

                    return fileHandled.promise();
                }.bind(this));

                return fileViewed.promise();
            },

            /**
             * Return the currently shown file.
             * @returns {null|File} the file being shown
             */
            getCurrentFile: function () {
                return this._currentFile;
            },

            /**
             * Return the current view state.
             * Can be any of the following
             * loading, fileNotFound, viewerError, success
             * @returns {String}
             */
            getViewState: function () {
                return this._viewState || 'loading';
            },

            _reinitializeAllSubviews: function () {
                if (!this.fileTitleView.isAnyPanelInitialized()) {
                    this.fileTitleView.initializePanel();
                }
                this.fileTitleView.reinitializePanel();

                this.fileControlsView.reinitializeLayers();
                this.fileContentView.reinitializeLayers();
                this.fileSidebarView.reinitializePanel();
                this.fileMetaView.reinitializeLayers();
                this.fileSinkView.reinitializePanel();

                this._updateMetaBannerHeight();
            },

            _teardownAll: function () {
                this.fileTitleView.teardownPanel();
                this.fileSidebarView.teardownPanel();
                this.fileSinkView.teardownPanel();
                this.fileMetaView.teardownLayers();
                this.fileControlsView.teardownLayers();
                this.fileContentView.teardownLayers();
            },

            _reinitializeCoreSubviews: function () {
                this._teardownAll();

                this.fileControlsView.initializeLayerSubset(['closeButton']);
                this.fileContentView.initializeLayerSubset(['arrows', 'error']);
            },

            _handleNavigationKeys: function (e) {
                var numFiles = this._fileViewer._files.length;

                if (e.which === keys.ESCAPE && !this.isNavigationLocked()) {
                    this._fileViewer.analytics.send('files.fileviewer-web.closed', {
                        actionType: 'hotkey'
                    });
                    this._fileViewer.close();
                } else if (e.which === keys.ARROW_RIGHT && numFiles > 1  && !this.isNavigationLocked()) {
                    this._fileViewer.showFileNext().always(
                        this._fileViewer.analytics.fn('files.fileviewer-web.next', {
                            actionType: 'hotkey',
                            mode: this._fileViewer.getMode()
                        })
                    );
                } else if (e.which === keys.ARROW_LEFT && numFiles > 1  && !this.isNavigationLocked()) {
                    this._fileViewer.showFilePrev().always(
                        this._fileViewer.analytics.fn('files.fileviewer-web.prev', {
                            actionType: 'hotkey',
                            mode: this._fileViewer.getMode()
                        })
                    );
                }
            },

            /**
             * Lock navigation keys. Navigation keys will be disabled until all
             * locks are removed again with unlockNavigationKeys.
             */
            lockNavigationKeys: function () {
                this._navigationKeyLockCount += 1;
            },

            /**
             * Unlock navigation keys.
             */
            unlockNavigationKeys: function () {
                if (this._navigationKeyLockCount >= 1) {
                    this._navigationKeyLockCount -= 1;
                }
            },

            /**
             * Checks if the navigation is locked.
             */
            isNavigationLocked: function () {
                return this._navigationKeyLockCount !== 0;
            },

            _disableKeyboardShortcuts: function(e) {
                if (e.ctrlKey || e.metaKey) {
                    switch (e.which) {
                        case keys.F:
                        case keys.G:
                            // disable search keyboard shortcut
                            e.preventDefault();
                            break;
                        case keys.P:
                            // disable print keyboard shortcut
                            e.preventDefault();
                            break;
                    }
                }
            },

            _onClickToBackground: function (e) {
                // @TODO: Remove after cleaning modes setup, hooks etc.
                var mode = this._fileViewer._view._modes[this._fileViewer._view._mode];
                if (mode.disableClickBackgroundCloses) {
                    return;
                }
                var backgroundLayers = [
                    'cp-error-layer',
                    'cp-waiting-layer',
                    'cp-password-layer'
                ];
                if (backgroundLayers.indexOf(e.target.className) >= 0) {
                    this._fileViewer.analytics.send('files.fileviewer-web.closed', {
                        actionType: 'element'
                    });
                    this._fileViewer.close();
                }
            },

            _updateContentWidth: function (panelId, isExpanded) {
                this.$content && this.$content.toggleClass("narrow", isExpanded);
                this._resizeActiveViewer();
            },

            _updateContentHeight: function (panelId, isExpanded) {
                this.$content && this.$content.toggleClass('short', isExpanded);
                this.$sidebar && this.$sidebar.toggleClass('short', isExpanded);
                this._resizeActiveViewer();
            },

            _updateMetaBannerHeight: function () {
                var showsMetaView = this.fileMetaView.countInitializedLayers() > 0;
                this.fileContentView.$el.toggleClass("meta-banner", showsMetaView);
                this.fileSidebarView.$el.toggleClass("meta-banner", showsMetaView);
            },

            _resizeActiveViewer: function () {
                if (this.fileContentView.isLayerInitialized('content')) {
                    var contentView = this.fileContentView.getLayerForName('content');
                    var viewer = contentView.getAttachedViewer();
                    if (viewer) { viewer.handleResize(); }
                }
            },

            // aui tooltips (tipsy) are appended to body. A tooltip will thus stay alive
            // if the trigger element is removed. In here, we clean them up manually
            // whenever a file changes or the whole viewer is closed.
            _fixTooltipCleanup: function () {
                var removeAllTooltips = function () { $('.tipsy').remove(); };
                this._fileViewer.on('fv.changeFile', removeAllTooltips);
                this._fileViewer.on('fv.close', removeAllTooltips);
            },

            /**
             * Return the current mode.
             * @returns {string}
             */
            getMode: function () {
                return this._mode || '';
            },

            /**
             * Check if FileView is in the given mode.
             * @param {string} mode either 'BASE' or 'PRESENTATION'
             * @returns {boolean}
             */
            isInMode: function (mode) {
                return this._mode === mode;
            },

            /**
             * Change current view mode to the given mode.
             * @param {string} mode either 'BASE' or 'PRESENTATION'
             */
            setupMode: function (mode) {
                var toolbar = this.fileContentView.getLayerForName('toolbar');
                var viewer = toolbar._viewer;
                var $arrowLayer = this.fileContentView.getLayerForName('arrows').$el;

                var lastMode = this._mode;
                var isModeChanged = (lastMode !== mode);

                var modeObj = this._modes[mode];
                var lastModeObj = this._modes[lastMode];

                if (isModeChanged) {
                    this._deactivateModeHook();
                    this._mode = mode;
                    this._activateModeHook();
                } else {
                    this._mode = mode;
                }

                $(document).off('keydown.modeKeys');
                lastModeObj.teardown(this, viewer, isModeChanged);
                modeObj.setup(this, viewer);

                // update arrow layer
                $arrowLayer.toggle(modeObj.showsArrowLayer);

                // update toolbar actions
                toolbar.setActions(modeObj.toolbarActions);
                toolbar.render();

                // notify viewer
                if (viewer && viewer.setupMode) {
                    viewer.setupMode(mode, isModeChanged);
                }
            },

            _activateModeHook: function () {
                var mode = this._modes[this._mode];
                if (mode.activateHook) {
                    mode.activateHook(this);
                }
            },

            _deactivateModeHook: function () {
                var mode = this._modes[this._mode];
                if (mode.deactivateHook) {
                    mode.deactivateHook(this);
                }
            },

            updatePaginationButtons: function () {
                if (this.isInMode('PRESENTATION')) {
                    var toolbar = this.fileContentView.getLayerForName('toolbar');
                    if (!toolbar._viewer) {
                        return;
                    }

                    var $toolbarPrevPage = toolbar.$el.find('.cp-toolbar-prev-page');
                    var $toolbarNextPage = toolbar.$el.find('.cp-toolbar-next-page');

                    $toolbarPrevPage.toggleClass('inactive', false);
                    $toolbarNextPage.toggleClass('inactive', false);

                    if (!(toolbar._viewer.hasPreviousPage() || toolbar._viewer.hasNextPage())) {
                        $toolbarPrevPage.hide();
                        $toolbarNextPage.hide();
                    } else if (!toolbar._viewer.hasPreviousPage()) {
                        $toolbarPrevPage.toggleClass('inactive', true);
                    } else if (!toolbar._viewer.hasNextPage()) {
                        $toolbarNextPage.toggleClass('inactive', true);
                    }
                }
            }
        });

        return MainView;
});

define('module-store-singleton', [
    'module-store'
], function (
    ModuleStore
) {
    'use strict';

    /**
     * Global module store. This simplifies development until FileViewer core
     * stabilizes, the plugin interface is ready and the view hierarchy is
     * clear.
     *
     * @todo remove singleton
     */
    return new ModuleStore();
});
define('module-store', [
    'assert',
    'jquery',
    'underscore'
], function (
    assert,
    $,
    _
) {
    'use strict';

    /**
     * Provides modules by asking a previously configured backend.
     *
     * As modules can be loaded async, a promise is always returned.
     *
     * A backend is a function that accepts a module path and returns the
     * matched module. If no module is found, it returns undefined.
     *
     * @constructor
     */
    var ModuleStore = function () {
        this._backend = null;
    };

    /**
     * Checks if backend is a valid backend.
     * @param {*} backend
     * @return {bool}
     */
    ModuleStore.validBackend = function (backend) {
        return _.isFunction(backend);
    };

    /**
     * Asks its backend for the given modulePath and returns a promise.
     * @param {string} modulePath
     * @return {Promise}
     * @throws {Error} if backend is invalid
     */
    ModuleStore.prototype.get = function (modulePath) {
        assert(ModuleStore.validBackend(this._backend), 'backend is valid');
        return $.when(this._backend(modulePath));
    };

    /**
     * Sets a backend for this module store.
     * @param {function} backend
     * @throws {Error} if backend is invalid
     */
    ModuleStore.prototype.useBackend = function (backend) {
        assert(ModuleStore.validBackend(backend), 'backend is valid');
        this._backend = backend;
    };

    return ModuleStore;
});
define('MoreButton', [
    'jquery', 'underscore', 'backbone', 'template-store-singleton'
], function ($, _, Backbone, templateStore) {
    'use strict';

    var MoreButton = Backbone.View.extend({

        tagName: 'span',

        initialize: function (options) {
            this._fileViewer = options.fileViewer;
            this._fileActions = [];
        },

        render: function () {
            this.$el.html(templateStore.get('moreButton')());
            var $dropdown = this.$el.find('#cp-more-menu'),
                $menu = $dropdown.find('ul');

            // prevent the tooltip from showing when the menu is open
            $dropdown.on({
                'aui-dropdown2-show': function () {
                    this.$('a').tipsy('disable');
                }.bind(this),
                'aui-dropdown2-hide': function () {
                    this.$('a').tipsy('enable');
                }.bind(this)
            });

            var currentFile = this._fileViewer._fileState.getCurrent();

            this.$('a').tooltip({ gravity: 'n' });
            if (this._fileActions.length) {
                this._fileActions.forEach(function (item) {
                    var $item = $(templateStore.get('moreMenuItem')({text: item.text}));
                    $item.click(function (e) {
                        e.preventDefault();
                        item.callback(currentFile);
                    });
                    $menu.append($item);
                });
                this._show();
            } else {
                this._hide();
            }

            return this;
        },

        addFileAction: function (opts) {
            var match = _.findWhere(this._fileActions, {key: opts.key});

            if (match) {
                // overwrite the properties of the old action with the new ones
                _.extend(match, {
                    key: opts.key,
                    text: opts.text,
                    callback: opts.callback
                });
            } else {
                this._fileActions.push({
                    key: opts.key,
                    text: opts.text,
                    callback: opts.callback
                });
            }

            this.render();
        },

        removeFileAction: function (action) {
            var index = _.indexOf(this._fileActions, action);
            this._fileActions.splice(index, 1);

            this.render();
        },

        _show: function () {
            this.$el.css('display', 'inline');
        },

        _hide: function () {
            this.$el.css('display', 'none');
        }
    });

    return MoreButton;
});
define('panel-container-view', [
    'backbone',
    'assert',
    'constants-dictionary'
], function (
    Backbone,
    assert,
    ConstantsDictionary
) {
    'use strict';

    var PanelContainerView = Backbone.View.extend({

        className: 'panel-view',

        /**
         * @constructor
         * @param {object} options
         */
        initialize: function (options) {
            this._panelViewsByName = new ConstantsDictionary();
            this._currentPanel = null;
            this._currentPanelName = null;
            this._lastAddedPanelName = null;
            this._fileViewer = options.fileViewer;
        },

        /**
         * Checks if a panel with the given name exists.
         * @param {string} name
         * @return {bool}
         */
        hasPanelView: function (name) {
            return this._panelViewsByName.isDefined(name);
        },

        /**
         * Adds a View as a panel with a certain, unique name.
         * @param {string} name
         * @param {Backbone.View} PanelView
         * @throws Error if name is already used.
         */
        addPanelView: function (name, PanelView) {
            this._panelViewsByName.define(name, PanelView);
            this._lastAddedPanelName = name;
        },

        /**
         * Checks wether any panel is currently initialized.
         * @return {bool}
         */
        isAnyPanelInitialized: function () {
            return this.$el.is('.expanded');
        },

        /**
         * Checks wether a panel with the given name is currently initialized.
         * @param {string} name
         * @return {bool}
         */
        isPanelInitialized: function (name) {
            return this._currentPanelName === name;
        },

        /**
         * Initializes the panel with the given name. Then re-renders itself.
         * @param name {String} name of the panel to be initialized. If empty, then use the last added (using addPanelView) panel.
         * @fires initializePanel(panelName)
         * @fires togglePanel(panelName, isInitialized)
         * @throws Error if a panel is already initialized or the panel doesn't exist
         */
        initializePanel: function (name) {
            name = name || this._lastAddedPanelName;
            assert(this.isAnyPanelInitialized() === false, 'no panel is initialized');
            assert(this.hasPanelView(name) === true, 'panel exists');

            var PanelView = this._panelViewsByName.lookup(name);

            this._currentPanelName = name;
            this._currentPanel = new PanelView({
                collection: this.collection,
                fileViewer: this._fileViewer,
                panelView: this
            });

            this.$el.toggleClass('expanded', true);

            this.trigger('initializePanel', this._currentPanelName);
            this.trigger('togglePanel', this._currentPanelName, true);

            this.render();
        },

        /**
         * Tears the initialized panel down and removes it. Then re-renders itself.
         * Won't throw if there's no initialized panel.
         * @fires togglePanel(panelName, isInitialized)
         * @fires teardownPanel(panelName)
         */
        teardownPanel: function () {
            if (this._currentPanel) {
                if (this._currentPanel.teardown) {
                    this._currentPanel.teardown();
                }
                this._currentPanel.remove();
            }

            this.$el.toggleClass('expanded', false);

            this.trigger('togglePanel', this._currentPanelName, false);
            this.trigger('teardownPanel', this._currentPanelName);

            this._currentPanelName = null;
            this._currentPanel = null;

            this.render();
        },

        /**
         * Utility method. Recreates the current PanelView (if there is one).
         */
        reinitializePanel: function () {
            if (!this.isAnyPanelInitialized()) { return; }

            var previousPanel = this.getInitializedPanelName();
            this.teardownPanel();
            this.initializePanel(previousPanel);
        },

        /**
         * Returns the name of the instanciated PanelView.
         * @return {string} panelName
         * @throws {Error} if no panel is initialized
         */
        getInitializedPanelName: function () {
            assert(this.isAnyPanelInitialized(), 'a panel is initialized');
            return this._currentPanelName;
        },

        /**
         * Returns the instanciated PanelView.
         * @return {PanelView}
         * @throws {Error} if no panel is initialized
         */
        getInitializedPanel: function () {
            return this._currentPanel;
        },

        /**
         * Renders the initialized panel.
         * Won't throw if no panel is initialized.
         * @fires renderPanel(panelName)
         */
        render: function () {
            this.$el.empty();

            if (this.isAnyPanelInitialized()) {
                this._currentPanel.render();
                this._currentPanel.$el.appendTo(this.$el);
            }
            this.trigger('renderPanel', this._currentPanelName);

            return this;
        }

    });

    return PanelContainerView;
});
define('PasswordLayer', [
    'ajs',
    'backbone',
    'keys',
    'template-store-singleton'
], function (
    AJS,
    Backbone,
    keys,
    templateStore
) {
    'use strict';

    var pdfjsPasswordResponses = {
        NEED_PASSWORD: 1,
        INCORRECT_PASSWORD: 2
    };

    var fullscreenEvents = [
        'fullscreenchange',
        'webkitfullscreenchange',
        'mozfullscreenchange',
        'MSFullscreenChange'
    ].join(' ');

    var isFullscreen = function () {
        return (document.fullscreenElement ||
            document.mozFullScreen ||
            document.webkitIsFullScreen ||
            document.msFullscreenElement);
    };

    var PasswordLayer = Backbone.View.extend({

        className: 'cp-password-layer',

        events: {
            'keydown .cp-password-input': '_handleKeyDown',
            'click .cp-password-button': '_handleClick',
            'focus .cp-password-input': '_lockNavigation',
            'blur .cp-password-input': '_unlockNavigation'
        },

        initialize: function (options) {
            this._fileViewer = options.fileViewer;
            this.$el.hide();
        },

        teardown: function () {
            $(document).off(fullscreenEvents, this.updatePasswordLayer.bind(this));
        },

        /**
         * Show the password input layer
         * @param  {Number}   reason         Reason PDFJS why needs the password
         * @param  {Callback} updatePassword
         */
        showPasswordInput: function (reason, updatePassword) {
            $(document).on(fullscreenEvents, this.updatePasswordLayer.bind(this));
            this.updatePassword = updatePassword;
            this._fileViewer._view.fileContentView.getLayerForName('spinner').stopSpin();
            this.$el.show().html(templateStore.get('passwordLayer')({
                prompt: this._getPromptTitle(reason)
            }));
            this.updatePasswordLayer();
            this._showToolbar();
        },

        hidePasswordInput: function () {
            $(document).off(fullscreenEvents, this.updatePasswordLayer.bind(this));
            this.$el.empty();
            this.$el.hide();
        },

        /**
         * Update the passwordLayer depending on fullsccren/no fullscreen
         * Safari/Firefox can't handle keyboard inputs in fullscreen
         */
        updatePasswordLayer: function () {
            if (isFullscreen()) {
                this.$el.find('.cp-password-base').hide();
                this.$el.find('.cp-password-fullscreen').show();
            } else {
                this.$el.find('.cp-password-fullscreen').hide();
                this.$el.find('.cp-password-base').show();
            }
        },

        /**
         * Get i18n string for password prompt based on reason
         * @param  {Number} reason Reason PDFJS why needs the password
         * @return {String}
         */
        _getPromptTitle: function (reason) {
            var title = "Please enter the password to view this file.";
            if (reason === pdfjsPasswordResponses.INCORRECT_PASSWORD) {
                title = "Invalid password. Please try again.";
            }
            return title;
        },

        /**
         * Show passwordLayer and toolbar
         */
        _showToolbar: function () {
            var view    = this._fileViewer._view;
            var toolbar = view.fileContentView.getLayerForName('toolbar');
            var mode    = view._modes[view._mode];
            toolbar.setActions(mode.toolbarActions);
            toolbar.render();
        },

        /**
         * Check if password was given and call `updatePassword()`
         */
        _updatePassword: function () {
            var password = this.$el.find('.cp-password-input').val();
            if (password && password.length > 0) {
                this.hidePasswordInput();
                this.updatePassword(password);
            }
        },

        /**
         * Lock navigation keys
         */
        _lockNavigation: function () {
            this._fileViewer._view._navigationKeyLockCount++;
        },

        /**
         * Unlock navigation keys
         */
        _unlockNavigation: function () {
          this._fileViewer._view._navigationKeyLockCount--;
        },

        _handleClick: function (ev) {
            ev.preventDefault();
            this._updatePassword();
        },

        _handleKeyDown: function (ev) {
            if (ev.which === keys.RETURN) {
                ev.preventDefault();
                return this._updatePassword();
            }
            if (ev.which === keys.ESCAPE) {
                ev.preventDefault();
                return this._fileViewer.close();
            }
        }

    });

    return PasswordLayer;
});

define('pdf-view-provider', [
    'jquery',
    'file',
    'module-store-singleton'
], function (
    $,
    File,
    moduleStore
) {
    'use strict';

    var asyncViewerResource = null,
      asyncConfigResource = null;

    /**
     * Returns a pdf viewer.
     * @returns {Promise}
     */
    var pdfViewProvider = function () {
        if (!asyncViewerResource) {
            asyncViewerResource = moduleStore.get('pdf-viewer');
        }
        if (!asyncConfigResource) {
            asyncConfigResource = moduleStore.get('pdf-config');
        }

        var viewerInstance = $.Deferred();

        $.when(asyncViewerResource, asyncConfigResource).done(function (viewer, config) {
            var PDFViewer = require('pdf-view');

            PDFJS.workerSrc = config.workerSrc;
            PDFJS.cMapUrl = config.cMapUrl;

            viewerInstance.resolve(PDFViewer);
        });

        return viewerInstance.promise();
    };

    return pdfViewProvider;
});
define('presentationMode', ['jquery', 'keys'], function ($, keys) {
    'use strict';

    var requestFullscreen = function () {
        var fullscreenContainer = $('#cp-file-body')[0];

        if (fullscreenContainer.requestFullscreen) {
            fullscreenContainer.requestFullscreen();
        } else if (fullscreenContainer.mozRequestFullScreen) {
            fullscreenContainer.mozRequestFullScreen();
        } else if (fullscreenContainer.webkitRequestFullScreen) {
            fullscreenContainer.webkitRequestFullScreen();
        } else if (fullscreenContainer.msRequestFullscreen) {
            fullscreenContainer.msRequestFullscreen();
        }
    };

    var cancelFullscreen = function () {
        if (document.cancelFullscreen) {
            document.cancelFullscreen();
        } else if (document.mozCancelFullScreen) {
            document.mozCancelFullScreen();
        } else if (document.webkitCancelFullScreen) {
            document.webkitCancelFullScreen();
        } else if (document.msExitFullscreen) {
            document.msExitFullscreen();
        }
    };

    var isFullscreen = function () {
        return (document.fullscreenElement ||
            document.mozFullScreen ||
            document.webkitIsFullScreen ||
            document.msFullscreenElement);
    };

    var onFullscreenChange = function (e) {
        // if user click Esc to exit fullscreen instead of clicking "exit presentation" button
        // then change view mode to 'BASE'
        if (!isFullscreen() && !this.isInMode('BASE')) {
            this._fileViewer.analytics.send('files.fileviewer-web.presentation.exit', {
                actionType: 'hotkey'
            });
            this._fileViewer.changeMode('BASE');
        }
    };

    var presentationMode = {

        activateHook: function (mainView) {
            $(document).on('fullscreenchange webkitfullscreenchange mozfullscreenchange MSFullscreenChange',
                onFullscreenChange.bind(mainView));
            var $arrowLayer = mainView.fileContentView.getLayerForName('arrows').$el;
            $arrowLayer.toggle(this.showsArrowLayer);
        },

        deactivateHook: function (mainView) {
            $(document).off('fullscreenchange webkitfullscreenchange mozfullscreenchange MSFullscreenChange',
                onFullscreenChange.bind(mainView));
        },

        setup: function (mainView, viewer) {
            this._originalScrollTop = $('body').scrollTop();
            $('#cp-file-body').addClass('presentation');
            $(document).on('keydown.modeKeys', this._handleKeys.bind(mainView));

            if (!isFullscreen()) { requestFullscreen(); }
        },

        teardown: function (mainView, viewer, isModeChanged) {
            $('#cp-file-body').removeClass('presentation');
            $(document).off('keydown.modeKeys');

            if (isModeChanged && isFullscreen()) { cancelFullscreen(); }
            // this is to fix an issue on Chrome that
            // when entering and exiting fullscreen mode, the document body got scrolled up
            $('body').scrollTop(this._originalScrollTop);
        },

        disableClickBackgroundCloses: true,

        showsArrowLayer: false,

        _handleKeys: function(e) {
            e.preventDefault();
            var contentView, viewer;

            if (this.fileContentView.isLayerInitialized('content')) {
                contentView = this.fileContentView.getLayerForName('content');
                viewer = contentView.getAttachedViewer();
            }
            if (!viewer) { return; }
            if (e.ctrlKey || e.metaKey) {
                return;
            }

            switch (e.which) {
                case keys.ARROW_UP:
                    if (viewer.goToPreviousPage) {
                        this._fileViewer.analytics.send('files.fileviewer-web.presentation.pageprev', {
                            actionType: 'hotkey'
                        });
                        viewer.goToPreviousPage();
                        this.updatePaginationButtons();
                    }
                    return;
                case keys.ARROW_DOWN:
                    if (viewer.goToNextPage) {
                        this._fileViewer.analytics.send('files.fileviewer-web.presentation.pagenext', {
                            actionType: 'hotkey'
                        });
                        viewer.goToNextPage();
                        this.updatePaginationButtons();
                    }
                    return;
            }

        },

        toolbarActions: [
            {
                title: "Previous page",
                className: 'cp-toolbar-prev-page',
                predicate: function () { return this._viewer && this._viewer.goToPreviousPage; },
                handler: function () {
                    if (this._viewer && this._viewer.goToPreviousPage) {
                        this._fileViewer.analytics.send('files.fileviewer-web.presentation.pageprev', {
                            actionType: 'button'
                        });
                        this._viewer.goToPreviousPage();
                        this._fileViewer.getView().updatePaginationButtons();
                    }
                }
            },
            {
                title: "Exit Presentation",
                className: 'cp-toolbar-presentation-exit',
                handler: function () {
                    this._fileViewer.analytics.send('files.fileviewer-web.presentation.exit', {
                        actionType: 'button'
                    });
                    this._fileViewer.changeMode('BASE');
                }
            },
            {
                title: "Next page",
                className: 'cp-toolbar-next-page',
                predicate: function () { return this._viewer && this._viewer.goToNextPage; },
                handler: function () {
                    if (this._viewer && this._viewer.goToNextPage) {
                        this._fileViewer.analytics.send('files.fileviewer-web.presentation.pagenext', {
                            actionType: 'button'
                        });
                        this._viewer.goToNextPage();
                        this._fileViewer.getView().updatePaginationButtons();
                    }
                }
            }
        ]
    };

    return presentationMode;
});

define('soy-template-backend', [], function () {
    'use strict';

    // Returns a value from a nested object, example:
    // obj = { a: { b: { c: 'x' } } }
    // getNestedProperty(obj, 'a.b.c') -> 'x'
    var getNestedProperty = function (obj, prop) {
        var levels = prop.split('.');
        var i;
        for (i = 0; i < levels.length; i++) {
            obj = obj[levels[i]];
        }
        return obj;
    };

    return function (fileViewer) {
        /**
         * Picks the specified template url from the auto-generated template object.
         * @param {string} templateUrl
         * @return {function}
         */
        return function (templateUrl) {
            return getNestedProperty(FileViewer.Templates, templateUrl);
        };
    };
});
define('SpinnerLayer', [
    'backbone', 'template-store-singleton'
], function (Backbone, templateStore) {
    'use strict';

    // Spinner rendering
    var SPINNER_SIZE = 'large';
    var SPINNER_STYLE = {
        color: '#fff',
        zIndex: 'auto'
    };

    /**
     * Loading spinner in the middle of the file content.
     * @constructor
     */
    var SpinnerLayer = Backbone.View.extend({

        className: 'cp-spinner-layer',

        initialize: function () {
            this._updateElements();
        },

        render: function () {
            this.$el.html(templateStore.get('fileBodySpinner')());
            this._updateElements();
            return this;
        },

        /**
         * Instruct the spinner to start.
         */
        startSpin: function () {
            this.$spinner.spin(SPINNER_SIZE, SPINNER_STYLE);
        },

        /**
         * Instruct the spinner to stop.
         */
        stopSpin: function () {
            this.$spinner.spin(false);
        },

        _updateElements: function () {
            this.$spinner = this.$el.find('.cp-spinner');
        }

    });

    return SpinnerLayer;
});
define('template-store-singleton', [
    'template-store'
], function (
    TemplateStore
) {
    'use strict';

    /**
     * Global template store. This simplifies development until FileViewer core
     * stabilizes, the plugin interface is ready and the view hierarchy is
     * clear.
     *
     * @todo remove singleton
     */
    return new TemplateStore();
});
define('template-store', [
    'assert',
    'underscore'
], function (
    assert,
    _
) {
    'use strict';

    /**
     * Provides templates by asking a previously configured backend.
     *
     * A backend is a function that accepts a template path and returns the
     * matched template. If no template is found, it returns undefined.
     *
     * @constructor
     */
    var TemplateStore = function () {
        this._backend = null;
    };

    /**
     * Checks if backend is a valid backend.
     * @param {*} backend
     * @return {bool}
     */
    TemplateStore.validBackend = function (backend) {
        return _.isFunction(backend);
    };

    /**
     * Asks its backend for the given templateUrl.
     * @param {string} templateUrl
     * @return {*}
     * @throws {Error} if backend is invalid
     */
    TemplateStore.prototype.get = function (templateUrl) {
        assert(TemplateStore.validBackend(this._backend), 'backend is valid');
        return this._backend(templateUrl);
    };

    /**
     * Sets a backend for this template store.
     * @param {function} backend
     * @throws {Error} if backend is invalid
     */
    TemplateStore.prototype.useBackend = function (backend) {
        assert(TemplateStore.validBackend(backend), 'backend is valid');
        this._backend = backend;
    };

    return TemplateStore;
});
define('TitleView', [
    'backbone', 'icon-utils', 'template-store-singleton'
], function (Backbone, iconUtils, templateStore) {
    'use strict';

    var TitleView = Backbone.View.extend({

        initialize: function (options) {
            this._fileViewer = options.fileViewer;
        },

        render: function () {
            var model = this._fileViewer.getCurrentFile();
            if (!model) { return; }

            this.$el.html(templateStore.get('titleContainer')({
                title: model.get('title'),
                iconClass: iconUtils.getCssClass(model.get('type'))
            }));

            return this;
        }

    });

    return TitleView;
});
define('ToolbarLayer', [
    'jquery',
    'underscore',
    'backbone',
    'template-store-singleton'
], function (
    $,
    _,
    Backbone,
    templateStore
) {
    'use strict';

    // Amount of time to wait before hiding the controls when the mouse stops moving.
    var HIDE_CONTROLS_TIMEOUT = 500;

    // Amount of time between checking if the mouse is still moving.
    // Should be smaller than HIDE_CONTROLS_TIMEOUT to prevent flickering.
    var THROTTLE_MOUSEMOVE = HIDE_CONTROLS_TIMEOUT - 100;

    /**
     * Showing a toolbar in the lower part of the viewer.
     * @constructor
     */
    var ToolbarLayer = Backbone.View.extend({

        className: 'cp-toolbar-layer',

        initialize: function (options) {
            this._fileViewer = options.fileViewer;
            this._viewer = null;
            this._toggleControlsTimeout = null;
            this._controlsAreFadingOut = false;
            this._actions = [];

            $('#cp-file-body').on('mousemove.toolbarLayer', this._showControlsOnMove.bind(this));
        },

        teardown: function () {
            $(document).off('keydown.toolbarLayer');
            $('#cp-file-body').off('mousemove.toolbarLayer');
        },

        render: function () {
            this.$el.html(templateStore.get('toolbar')({
                actions: this._actions
            }));
            this.$el.find('a').tooltip({gravity: 's', aria: true});
            this.$toolbar = this.$('.cp-toolbar');

            var listeners = {};
            this._actions.forEach(function (action) {
                listeners['click .' + action.className] = action.handler;

                if (action.predicate && !action.predicate.call(this)) {
                    this.$toolbar.find('.' + action.className).hide();
                }
            }, this);
            this.delegateEvents(listeners);

            this.$toolbar.css('margin-left', -this.$toolbar.width() / 2);

            this.$toolbar.on('click', 'a[href=\'#\']', function(e) {
                e.preventDefault();
            });

            return this;
        },

        setActions: function (actions) {
            this._actions = actions;
        },

        setViewer: function (viewer) {
            this._viewer = viewer;
            this.render();
        },

        // Show / hide controls based on mouse movements:
        // - Show the controls when the mouse is moving over the content view.
        // - Hide the controls after a short delay when the mouse stops moving.
        // - Keep the controls open if the mouse is hovering over them.

        _showControlsOnMove : _.throttle(function () {
            if (!this.$toolbar) { return; }
            if (this._controlsAreFadingOut) { return; }

            this.$toolbar.show();
            clearTimeout(this._toggleControlsTimeout);
            this._toggleControlsTimeout = this._setHideTimer();

        }, THROTTLE_MOUSEMOVE),

        _setHideTimer: function () {

            return setTimeout(function () {
                if (this.$toolbar.is(':hover')) { return; }

                this.$toolbar.find('a').each(this._removeTooltipForElement);

                this._controlsAreFadingOut = true;
                setTimeout(function () {
                    this._controlsAreFadingOut = false;
                }.bind(this), HIDE_CONTROLS_TIMEOUT + 100);

                this.$toolbar.fadeOut();
            }.bind(this), HIDE_CONTROLS_TIMEOUT);
        },

        _removeTooltipForElement: function (pos, el) {
            var tipsyId = $(el).attr('aria-describedby');
            if (tipsyId) { $('#' + tipsyId).fadeOut(); }
        }

    });

    return ToolbarLayer;
});

define('unknown-file-type-view-provider', [
    'jquery',
    'unknown-file-type-view'
],
function (
    $,
    UnknownFileTypeView
) {
    'use strict';

    var unknownFileTypeViewProvider = function () {
        return $.Deferred().resolve(UnknownFileTypeView);
    };

    return unknownFileTypeViewProvider;
});
define('unknown-file-type-view', [
    'ajs',
    'BaseViewer',
    'template-store-singleton',
    "icon-utils"
],
function(
    AJS,
    BaseViewer,
    templateStore,
    iconUtils
) {
    'use strict';

    var UnknownFileTypeView = BaseViewer.extend({

        id: 'cp-unknown-file-type-view-wrapper',

        events: {
            'click .download-button': '_handleDownloadButton'
        },

        initialize: function() {
            BaseViewer.prototype.initialize.apply(this, arguments);
        },

        teardown: function() {
            this.off();
            this.remove();
        },

        render: function() {
            this.$el.html(templateStore.get('unknownFileTypeViewer')({
                iconClass: iconUtils.getCssClass(this.model.get('type')),
                src: this.model.get('srcDownload') || this.model.get('src')
            }));

            var fileView = this._fileViewer.getView();

            // kill sidebar view.
            if (fileView.fileSidebarView.isAnyPanelInitialized()) {
                fileView.fileSidebarView.teardownPanel();
            }

            this.trigger('viewerReady');

            return this;
        },

        setupMode: function(mode) {
            if (mode === 'BASE') {
                $('.cp-toolbar-layer').hide();
            }
        },

        _handleDownloadButton: function () {
            this._fileViewer.trigger('fv.download');
            this._triggerAnalytics();
        },

        _triggerAnalytics: function () {
            this._fileViewer.analytics.send('files.fileviewer-web.file.download', {
                actionType: 'cta'
            });
        }

    });

    return UnknownFileTypeView;
});

define('url', [], function() {
    'use strict';
    return {
        /**
         * Adds an objects keys and values as query parameters to an given URL.
         * @param {string} [url]
         * @param {object} [param]
         * @return {string}
         */
        addQueryParamToUrl: function (url, param) {
            param = param || {};
            url = url.split('?');
            var queryArray = url[1] && url[1].split('&');
            queryArray = queryArray || [];
            Object.keys(param).forEach(function (key, val) {
                queryArray.push(key + '=' + param[key]);
            });
            if (queryArray.length === 0) {
                return url[0];
            }
            return url[0] + '?' + queryArray.join('&');
        }
    };
});

define('video-view-provider', [
    'jquery',
    'file'
], function (
    $,
    File
) {
    'use strict';

    /**
     * Returns a video viewer.
     * @returns {Promise}
     */
    var videoViewProvider = function () {
        return $.Deferred().resolve(require('video-view'));
    };

    return videoViewProvider;
});
define('viewer-registry',
    [
        'underscore',
        'assert'
    ],
    function(
        _,
        assert
    ) {
        'use strict';

        var createMatchFn = function (expected) {
            return function (current) {
                return current === expected;
            };
        };

        /**
         * ViewerRegistry is responsible for mapping file types to content viewers.
         *
         * When FileViewer is asked to view a file, it uses the file's type and asks
         * its ViewerRegistry for the proper viewer. In addition, ViewerRegistry is
         * exposed to the outside world. Therefore viewers and plugins can register
         * themself without touching FileViwer core.
         *
         * A viewer is a backbone view and is registered via a function that wraps this
         * view into a promise.
         *
         * Multiple viewers for the same filetype are weighted and can thus be overriden.
         * The default weight is 10 with a lower weight meaning higher priority.
         */
        var ViewerRegistry = function () {
            this._handlers = [];
        };

        /**
         * Checks for a valid viewer (is a function).
         *
         * @param {*} previewer
         * @return {boolean}
         */
        ViewerRegistry.isValidPreviewer = function (previewer) {
            return _.isFunction(previewer);
        };

        /**
         * Checks for a valid weight (a number).
         *
         * @param {*} weight
         * @return {boolean}
         */
        ViewerRegistry.isValidWeight = function (weight) {
            return typeof weight === 'number' && !isNaN(weight);
        };

        /**
         * Register a new viewer for a given filetype with an optional weight.
         *
         * fileType can either be a string which is then directly matched or a
         * predicate function that get's handed the current file type and then
         * can return true / false.
         *
         * @param {string|function} fileType
         * @param {function} previewer
         * @param {integer} [weight=10]
         * @thors {Error}
         */
        ViewerRegistry.prototype.register = function (fileType, previewer, weight) {
            var matchesFileType = typeof fileType === 'function' ? fileType : createMatchFn(fileType);

            weight = weight || 10;

            assert(ViewerRegistry.isValidPreviewer(previewer), 'previewer is valid');
            assert(ViewerRegistry.isValidWeight(weight), 'weight is valid');

            this._handlers.push({
                matchesFileType: matchesFileType,
                previewer: previewer,
                weight: weight
            });

            this._updateWeighting();
        };

        /**
         * Get the viewer with the lowest weight for the given fileType.
         *
         * Returns undefined if no viewer is found.
         *
         * @param {string} fileType
         * @return {object} previewer
         */
        ViewerRegistry.prototype.get = function (fileType) {
            var handler = _.find(this._handlers, function (handler) {
                return handler.matchesFileType(fileType);
            });

            return handler && handler.previewer;
        };

        ViewerRegistry.prototype._updateWeighting = function () {
            // Sorts handlers by weight - needs to be called after a new handler is inserted.
            this._handlers = _.sortBy(this._handlers, function (handler) {
                return handler.weight;
            });
        };

        return ViewerRegistry;
    }
);

define('ViewerLayer', [
    'backbone',
], function (Backbone) {
    'use strict';

    var ViewerLayer = Backbone.View.extend({

        className: 'cp-viewer-layer',

        initialize: function (options) {
            this._viewer = null;
        },

        attachViewer: function (viewer) {
            this._viewer = viewer;
            this.$el.prepend(viewer.$el);
        },

        getAttachedViewer: function () {
            return this._viewer;
        },

        teardown: function () {
            if (this._viewer) {
                if (this._viewer.teardown) {
                    this._viewer.teardown();
                }
                this._viewer.$el.remove();
            }
        }
    });

    return ViewerLayer;
});
define('WaitingLayer', [
    'backbone', 'template-store-singleton'
], function (Backbone, templateStore) {
    'use strict';

    var WaitingLayer = Backbone.View.extend({

        className: 'cp-waiting-layer',

        initialize: function () {
            this.$el.hide();
        },

        showMessage: function (file, header, message) {
            this.$el.show().html(templateStore.get('waitingMessage')({
                src: file.get('srcDownload') || file.get('src'),
                header: header,
                message: message
            }));
            this.$el.find('.cp-waiting-message-spinner').spin('large', {
                color: '#fff',
                zIndex: 'auto'
            });
        },

        clearMessage: function () {
            this.$el.find('.cp-waiting-message-spinner').spin(false);
            this.$el.hide();
        }

    });

    return WaitingLayer;
});

    // assemble core module by injecting all dependencies
    var FileViewer = require('file-viewer');

    FileViewer.Templates = window.FileViewer.Templates;

    // export FileViewer using CommonJS, AMD and the window object
    if (typeof module !== "undefined" && module.exports) {
        module.exports = FileViewer;
    }

    if (window.define) {
        window.define(
            'FileViewer',
            ['jquery', 'underscore', 'backbone', 'ajs'],
            function () { return FileViewer; }
        );
    }

    window.FileViewer = FileViewer;

}());
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-previews:fileviewer-core', location = '/bower_components/atlassian-fileviewer/dist/fileviewer-image-templates.js' */
// This file was automatically generated from image-view.i18n.soy.
// Please don't edit this file by hand.

/**
 * @fileoverview Templates in namespace FileViewer.Templates.
 */

if (typeof FileViewer == 'undefined') { var FileViewer = {}; }
if (typeof FileViewer.Templates == 'undefined') { FileViewer.Templates = {}; }


FileViewer.Templates.previewBody = function(opt_data, opt_ignored) {
  return '<div class="cp-image-container" /><span class="cp-baseline-extension"></span>';
};
if (goog.DEBUG) {
  FileViewer.Templates.previewBody.soyTemplateName = 'FileViewer.Templates.previewBody';
}

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-previews:fileviewer-core', location = '/bower_components/atlassian-fileviewer/dist/fileviewer-image.js' */
(function (FileViewer) {
    'use strict';

    // use FileViewer's internal module system
    var define  = FileViewer.define;
    var require = FileViewer.require;

define("image-view",
    [
        "ajs",
        "backbone",
        "underscore",
        "jquery",
        "file",
        "BaseViewer",
        "template-store-singleton"
    ],
    function(
        AJS,
        Backbone,
        _,
        $,
        File,
        BaseViewer,
        templateStore
    ) {
        "use strict";

        var ImageView = BaseViewer.extend({

            id: "cp-image-preview",

            tagName: "div",

            initialize: function() {
                BaseViewer.prototype.initialize.apply(this, arguments);

                this.bindPanEvents();
                this.MIN_HEIGHT = 100;
                this.ZOOM_IN_FACTOR = 1.25;
                this.ZOOM_OUT_FACTOR = 0.80;
                this._isFitWidth = false;
                this._footerView = this._fileViewer.getView().fileSinkView;
            },

            renderAnnotations: function(PinsView) {
                var current = this._fileViewer.getCurrentFile();
                var annotations = current.get("annotations");
                if (current && PinsView) {
                    this.pinsView = new PinsView({
                        fileViewer: this._fileViewer,
                        container: this.$el.find(".cp-image-container"),
                        collection: annotations
                    });
                    this.pinsView.render();
                }

                annotations.on("selected", function (item) {
                    var $pin, positionTop, positionLeft;
                    if (!item) { return; }

                    $pin = this.$el.find("span.cp-active-annotation.selected");
                    if (!$pin.length) { return; }

                    positionTop = $pin.position().top - (this.$el.height() / 2);
                    positionLeft = $pin.position().left - (this.$el.width() / 2);

                    this.$el.animate({
                        'scrollTop': positionTop,
                        'scrollLeft': positionLeft
                    });

                }.bind(this));
            },

            bindPanEvents: function() {
                var previous = {x: 0, y: 0},
                    view = this;

                var scroll = function(e) {
                    var $el = view.$el;
                    $el.scrollLeft($el.scrollLeft() + previous.x - e.clientX);
                    $el.scrollTop($el.scrollTop() + previous.y - e.clientY);
                    previous = { x: e.clientX, y: e.clientY };
                    e.preventDefault();
                };

                var unpan = function(e) {
                    view.$el.off("mousemove", "#cp-img", scroll);
                    view.$image.removeClass("panning");
                    e.preventDefault();
                };

                var pan = function(e) {
                    $(window).one("mouseup", unpan);
                    view.$el.on("mousemove", "#cp-img", scroll);
                    view.$image.addClass("panning");
                    previous = { x: e.clientX, y: e.clientY };
                    e.preventDefault();
                };

                this.$el.on("mousedown", "#cp-img", pan);
            },

            zoomFit: function() {
                if(this._isFitWidth) {
                    this.scaleToFit();
                } else {
                    this._fitWidth();
                }
                this._fixContainerSize();
                this.makePannable();
            },

            _fitWidth: function() {
                this._stopFit();
                var $imageContainer = this.$el.find(".cp-image-container");
                $imageContainer.css("width", "100%");
                this.$image.css("width", "100%");
                this.$image.css("height", "auto");
                $imageContainer.addClass("cp-fit-width");
                this._isFitWidth = true;
            },

            _fitHeight: function() {
                this._stopFit();
                var $imageContainer = this.$el.find(".cp-image-container");
                $imageContainer.css("height", "100%");
                this.$image.css("width", "auto");
                this.$image.css("height", "100%");
                $imageContainer.addClass("cp-fit-height");
                $(window).on("resize.cp-repaint", _.throttle(this._forceRepaint.bind(this), 50));
                this.listenTo(this._footerView, "togglePanel" , this._forceRepaint.bind(this));
            },

            _forceRepaint: function () {
                var el = this.$image[0];
                el.style.display='none';
                el.offsetHeight; // referencing to force repaint
                el.style.display='';
            },

            _stopFit: function() {
                this._isFitWidth = false;
                var $imageContainer = this.$el.find(".cp-image-container");
                $imageContainer.removeClass("cp-fit-width cp-fit-height");
                $(window).off("resize.cp-repaint");
                this.stopListening(this._footerView, "togglePanel");
            },

            /**
             * Set size of the images container to the image size.
             * This is a workaround for `HC-11712 as` it's
             * original fix `e31eac8ac51` caused a new issue: `FIL-555`.
             */
            _fixContainerSize: function () {
                var $container = this.$el.find(".cp-image-container");
                var $image = this.$el.find("#cp-img");
                $container.width($image.width());
                $container.height($image.height());
            },

            scaleToFit: function() {
                this._stopFit();

                var viewportWidth = this.$el.width();
                var viewportHeight = this.$el.height();

                if ((this.imageWidth > viewportWidth) || (this.imageHeight > viewportHeight)) {
                    if (viewportWidth/this.imageWidth < viewportHeight/this.imageHeight) {
                        this._fitWidth();
                    } else {
                       this._fitHeight();
                    }
                } else {
                    this.$image.css("width", this.imageWidth);
                    this.$image.css("height", "auto");
                }
                this._fixContainerSize();
            },

            changeZoom: function(newHeight) {
                this._stopFit();

                var viewportWidth = this.$el.width();
                var viewportHeight = this.$el.height();

                var oldWidth = this.$image.width();
                var oldHeight = this.$image.height();
                var containerPosition = this.$el.find(".cp-image-container").position();

                //find the position of the pixel in the centre of the viewport
                var oldPixelCentreWidth = (viewportWidth/2) + Math.abs(containerPosition.left);
                var oldPixelCentreHeight = (viewportHeight/2) + Math.abs(containerPosition.top);

                this.$image.css("height", newHeight);
                this.$image.css("width", "auto");

                //calculate the new pixel centre after the image has been scaled
                var newPixelCentreWidth = (oldPixelCentreWidth/oldWidth) * this.$image.width();
                var newPixelCentreHeight = (oldPixelCentreHeight/oldHeight) * this.$image.height();

                //move the scrollbar to the new pixel and then center the viewport on it
                this.$el.scrollLeft(newPixelCentreWidth - (viewportWidth/2));
                this.$el.scrollTop(newPixelCentreHeight - (viewportHeight/2));
                this._fixContainerSize();
            },

            zoomIn: function() {
                this.changeZoom(this.$image.height() * this.ZOOM_IN_FACTOR);
                this.makePannable();
            },

            zoomOut: function() {
                var heightValue = this.$image.height();
                if (heightValue >= this.MIN_HEIGHT) {
                    this.changeZoom(heightValue * this.ZOOM_OUT_FACTOR);
                }
                this.makePannable();
            },

            makePannable: function() {
                if ((this.$el.width() < this.$image.width()) || (this.$el.height() < this.$image.height())) {
                    this.$image.addClass("pannable");
                } else {
                    this.$image.removeClass("pannable");
                }
            },

            teardown: function() {
                BaseViewer.prototype.teardown.apply(this);
                $(window).off("resize.cp-repaint");
                this.pinsView && this.pinsView.remove().off();
            },

            getBackground: function () {
                return this.$el.add(".cp-image-container");
            },

            render: function() {
                this.$el.html($(templateStore.get('previewBody')()));

                this.addImage();
                return this;
            },

            addImage: function() {
                // This extra work makes the image size the same as the viewport size.
                var $img = $("<img/>")
                    .attr("id", "cp-img")
                    .attr("src", this._previewSrc)
                    .attr("alt", this.model.get("title"));
                $img.off("load");
                $img.on("load", _.partial(this.scaleAndAppendImage, this));

                $img.on("load", function () { this.trigger('viewerReady') }.bind(this));
                $img.on('error', function () {
                    var err = new Error('Image failed loading');
                    err.title = "Ouch! We can\'t load the image.";
                    err.description = this.model.get('src');
                    err.icon = 'cp-image-icon';
                    this.trigger('viewerFail', err);
                }.bind(this));
            },

            scaleAndAppendImage: function(view) {
                var $image = $(this);

                view.imageHeight = this.height;
                view.imageWidth = this.width;
                view.$image = $image;

                $image.css("display", "none"); // For the fade in.

                var $imageContainer = view.$el.find(".cp-image-container");
                $imageContainer.append(view.$image);
                $imageContainer.addClass("cp-annotatable");

                // Ensure the whole image is displayed by fitting to the larger side.
                view.scaleToFit();
                view.$image.fadeIn(200);

                view.trigger("cp.imageAppended");
            },

            setupMode: function(mode, isModeChanged) {
                if (isModeChanged) {
                    this.scaleGraduallyToFit();
                }
            },

            scaleGraduallyToFit: function() {
                // When browser change to fullscreen mode, the screen size is changed many times.
                // Here we scale 10 times every 100ms to make the page scaling to full screen smoothly
                var times = 0;
                var fullScreenInProgress = setInterval(function() {
                    times++;
                    if (times === 11) {
                        clearInterval(fullScreenInProgress);
                    }
                    this.scaleToFit();
                }.bind(this), 100);
            }

        });

        return ImageView;
    });

}(function () {
  var FileViewer;

    if (typeof module !== "undefined" && ('exports' in module)) {
      FileViewer = require('./fileviewer.js');
    } else if (window.require) {
      FileViewer = window.FileViewer;
    } else {
      FileViewer = window.FileViewer;
    }

    return FileViewer;
}()));

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-previews:confluence-previews-resources', location = '/js/amd/confluence-amd.js' */
define("confluence",function(){return Confluence});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-previews:confluence-previews-resources', location = '/js/amd/dragndrop-support-amd.js' */
define("dragndrop-support",function(){return DragnDropSupport});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-previews:confluence-previews-resources', location = '/js/confluence/async-module-backend.js' */
define("cp/confluence/async-module-backend",["jquery","ajs"],function(f,b){var a={"pdf-viewer":"wr!com.atlassian.confluence.plugins.confluence-previews:confluence-previews-pdf"};var d="com.atlassian.confluence.plugins.confluence-previews:confluence-previews-pdf-worker";var c=function(h){var g=b.Meta.get("static-resource-url-prefix");return g+"/download/resources/"+d+"/"+h};function e(){var g=new f.Deferred();f.ajax({url:b.contextPath()+"/rest/webResources/1.0/resources",type:"POST",contentType:"application/json",dataType:"json",data:JSON.stringify({r:[d],c:[],xc:[],xr:[]})}).done(function(l){var h;for(var k in l.resources){var j=l.resources[k].url;if(j&&j.indexOf(d)!==-1){h=j;break}}if(h){var m=c("bcmaps/");g.resolve({workerSrc:h,cMapUrl:m})}else{g.reject()}}).fail(g.reject.bind(g));return g.promise()}return function(g){if(a[g]){return WRM.require(a[g])}else{if(g==="pdf-config"){return e()}}}});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-previews:confluence-previews-resources', location = '/js/confluence/conversion-poller-backend.js' */
define("cp/confluence/conversion-poller-backend",["jquery","underscore","confluence"],function(c,b,d){function a(e){this._type=e;if(this._type==="thumbnail"){this._bulkUrl=d.getContextPath()+"/rest/documentConversion/0.1/conversion/thumbnail/results";this._singleUrlBase=d.getContextPath()+"/rest/documentConversion/0.1/conversion/thumbnail/"}else{this._bulkUrl=d.getContextPath()+"/rest/documentConversion/0.1/conversion/convert/results";this._singleUrlBase=d.getContextPath()+"/rest/documentConversion/0.1/conversion/convert/"}this._pollers={};this._timerId=0;this._interval=a.INITIAL_INTERVAL;this._debouncedChange=b.debounce(this._change,100)}a.INITIAL_INTERVAL=1000;a.MAX_INTERVAL=10000;a.BACKOFF_PERCENT=1.5;a.prototype.add=function(g,f){if(g&&!this._pollers[g]){var e=c.Deferred();this._pollers[g]={_dfd:e,_version:f};this._debouncedChange()}return this._pollers[g]._dfd.promise()};a.prototype.remove=function(e){var f=this._pollers[e];if(f){f._dfd.reject("cancelled");delete this._pollers[e]}};a.prototype._doPoll=function(){if(this._pollType==="single"){this._pollSingle()}else{if(this._pollType==="multiple"){this._pollMultiple()}}};a.prototype._backoff=function(){var e=this._interval*a.BACKOFF_PERCENT;this._interval=e>a.MAX_INTERVAL?a.MAX_INTERVAL:e;this._timerId=setTimeout(this._change.bind(this),this._interval)};a.prototype._change=function(){var f=this._getAttachmentIds();var e=!(f.length===0);this._cancel();if(!e){delete this._pollType;this._interval=1000}else{this._changeType();this._doPoll()}};a.prototype._changeType=function(){var g=this._getAttachmentIds();var f=g.length===1;var e=g.length>1;if(f&&this._pollType!=="single"){this._pollType="single"}else{if(e&&this._pollType!=="multiple"){this._pollType="multiple"}}};a.prototype._cancel=function(){clearTimeout(this._timerId);this._xhr&&this._xhr.abort();delete this._xhr};a.prototype._getAttachmentIds=function(){return Object.keys(this._pollers)};a.prototype._getIdsAndVersions=function(){var e=this._pollers;return b.map(this._getAttachmentIds(),function(f){return{id:f,v:e[f]._version}})};a.prototype._pollSingle=function(){var f=this._getAttachmentIds()[0];var g=this._pollers[f];var e=g._version;this._xhr=this._getSingle(f,e).always(function(){delete this._xhr}.bind(this)).done(function(i,j,h){if(h.status===202){this._backoff();g._dfd.notify("converting")}else{g._dfd.resolve(this._singleUrlBase+f+"/"+e,h.getResponseHeader("Content-Type"));delete this._pollers[f];this._change()}}.bind(this)).fail(function(h,j,i){if(h.status==429){this._backoff();g._dfd.notify("busy");return}if(i==="abort"){return}g._dfd.reject();delete this._pollers[f];this._change()}.bind(this))};a.prototype._getSingle=function(f,e){return c.ajax(this._singleUrlBase+f+"/"+e,{type:"HEAD",dataType:"json"})};a.prototype._pollMultiple=function(){this._xhr=c.ajax(this._bulkUrl,{type:"POST",dataType:"json",contentType:"application/json; charset=utf-8",data:JSON.stringify(this._getIdsAndVersions())}).always(function(){delete this._xhr}.bind(this)).done(function(e){b(e).each(function(g,h){var i=this._pollers[h];if(!i){return}if(g==200){var f=i._version;if(this._type!=="thumbnail"){this._getSingle(h,f).done(function(k,l,j){i._dfd.resolve(this._singleUrlBase+h+"/"+f,j.getResponseHeader("Content-Type"));delete this._pollers[h]}.bind(this))}else{i._dfd.resolve(this._singleUrlBase+h+"/"+f,"image/jpg");delete this._pollers[h]}}else{if(g>=400&&g!=429){i._dfd.reject();delete this._pollers[h]}}}.bind(this));this._backoff()}.bind(this))};return a});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-previews:confluence-previews-resources', location = '/js/confluence/conversion-poller.js' */
define("cp/confluence/conversion-poller",["cp/confluence/conversion-poller-backend","jquery"],function(a,e){var b={};var c={};function d(k,g,i,f){if(!b[i]){b[i]=new a(i)}this.backend=b[i];this._attachmentId=k;this._version=g;var h=JSON.stringify({a:k,v:g,t:i});var j=c[h];if(j){this._promise=j.success?e.when(j.url,j.type):e.Deferred().reject(j.reason)}else{this._promise=this.backend.add(this._attachmentId,this._version);this._promise.then(function(l,m){c[h]={success:true,url:l,type:m}},function(l){if(l!=="cancelled"){c[h]={success:false,reason:l}}},f)}}d.prototype.stop=function(){this.backend.remove(this._attachmentId)};d.prototype.promise=function(){return this._promise};return d});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-previews:confluence-previews-resources', location = '/js/service/comments-service.js' */
define("cp/service/comments-service",["confluence","underscore","ajs","jquery"],function(g,h,e,c){function b(j,k){this.url=g.getContextPath()+"/rest/files/1.0/files/"+j+"/comments";this.version=k}var d=function(j,k){return function(l){return e.defaultIfUndefined(l,{rootObject:j,defaultValue:k})}};var a=function(j){var l=d(j,"");var m=d(j,undefined);var k=m("history.createdDate")||new Date();return{id:l("id"),author:{name:l("history.createdBy.displayName"),avatar:l("history.createdBy.profilePicture.path"),profile:g.getContextPath()+"/display/~"+l("history.createdBy.username")},comment:l("body.view.value"),editorFormat:l("body.editor.value"),date:k,hasDeletePermission:j.hasDeletePermission,hasEditPermission:j.hasEditPermission,hasReplyPermission:j.hasReplyPermission,hasResolvePermission:j.hasResolvePermission}};var f=function(j){var l=d(j,undefined);var k=d(j,false);return h.extend({pageNumber:l("anchor.page"),position:[l("anchor.x"),l("anchor.y")],resolved:k("resolved.value")},a(j))};var i=function(m,k){var l=m.changedAttributes();if(l.hasOwnProperty("resolved")&&k){return{resolved:m.get("resolved")}}var j={parentId:m.get("parentId"),commentBody:m.get("editorFormat")};if(m.get("position")||m.get("pageNumber")){j=h.extend({},j,{anchor:{x:m.get("position")[0],y:m.get("position")[1],page:m.get("pageNumber"),type:"pin"}})}return j};b.prototype._makeUrl=function(j){if(!j){j=""}return this.url+j+(this.version?("?attachmentVersion="+this.version):"")};b.prototype.getAnnotations=function(l){var j=c.Deferred();var k=h.extend({},l);c.ajax({url:this._makeUrl(),type:"GET",data:{limit:k.limit,start:k.start},dataType:"json"}).then(function(m){var n=h.map(m.results,f);j.resolve(n)}).fail(function(m,o,n){j.reject(m,o,n)});return j.promise()};b.prototype.getReplies=function(l){var j=c.Deferred();var k=h.extend({},l);c.ajax({url:this._makeUrl("/"+l.parentId),type:"GET",data:{limit:k.limit,start:k.start},dataType:"json"}).then(function(o){var p=d(o,[]);var m=p("children");var n=h.map(m,a);j.resolve(n)}).fail(function(m,o,n){j.reject(m,o,n)});return j.promise()};b.prototype.save=function(m){var j=c.Deferred();var l=m.get("id")?"PUT":"POST";var k=(l==="PUT")?this._makeUrl("/"+m.get("id")):this._makeUrl();c.ajax({url:k,type:l,data:JSON.stringify(i(m,(l==="PUT"))),dataType:"json",contentType:"application/json; charset=utf-8"}).then(function(n){j.resolve(a(n))}).fail(function(n,p,o){j.reject(n,p,o)});return j.promise()};b.prototype.remove=function(k){var j=c.Deferred();c.ajax({url:this._makeUrl("/"+k.get("id")),type:"DELETE",dataType:"json"}).then(function(){j.resolve()}).fail(function(l,n,m){j.reject(l,n,m)});return j.promise()};return b});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-previews:confluence-previews-resources', location = '/js/service/versions-service.js' */
define("cp/service/versions-service",["confluence","jquery","underscore"],function(g,f,b){var a=g.getContextPath();var e=function(h){if(h.id===-1){return{}}var j=h.previewContents.THUMBNAIL;var i=AJS.DarkFeatures.isEnabled("previews.conversion-service");var k=j&&i?j.downloadUrl:h.downloadUrl;return{src:a+h.downloadUrl,type:h.contentType,contentType:h.contentType,thumbnail:a+k,title:h.fileName,name:h.fileName,id:h.id,ownerId:h.containerId&&h.containerId.toString(),version:h.version,hasUploadAttachmentVersionPermission:h.hasUploadAttachmentVersionPermission}};var d=function(j,h,i){return f.ajax({url:a+"/rest/files/1.0/files/content/"+j+"/byAttachmentId",type:"GET",dataType:"json",contentType:"application/json; charset=utf-8",data:{attachmentId:h,attachmentVersion:i}}).pipe(function(k){return e(k)})};function c(){}c.prototype.getAllFileVersions=function(h){var i=a+"/rest/files/1.0/files/"+h+"/versions";return f.ajax(i).pipe(function(k){var j=k.results;return b.sortBy(b.map(j,function(l){return{id:l.id,version:l.version.number,message:l.version.message,countComments:l.countComments,ownerId:l.ownerId}}),function(l){return 0-l.version})})};c.prototype.getFileVersion=function(j,h,i){return d(j,h,i)};return c});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-previews:confluence-previews-resources', location = '/js/service/files-service.js' */
define("cp/service/files-service",["ajs","confluence","jquery","underscore"],function(a,g,f,c){var b=g.getContextPath();var e=function(h){if(h.id===-1){return{}}var j=h.previewContents.THUMBNAIL;var i=a.DarkFeatures.isEnabled("previews.conversion-service");var k=null;if(j&&i){k=b+j.downloadUrl}return{src:b+h.downloadUrl,srcDownload:b+h.downloadUrl+"&download=true",type:h.contentType,thumbnail:k,title:h.fileName,name:h.fileName,id:h.id.toString(),ownerId:h.containerId&&h.containerId.toString(),version:h.version,hasReplyPermission:h.hasReplyPermission,hasUploadAttachmentVersionPermission:h.hasUploadAttachmentVersionPermission}};function d(h){this.url=b+"/rest/files/1.0/files/content/"+h}d.prototype.getFiles=function(j){var h=f.Deferred();var i=c.extend({},j);f.ajax({url:this.url,type:"GET",data:{"max-results":i.limit,"start-index":i.start},dataType:"json"}).then(function(l){var k=c.map(l.results,e);h.resolve(k)}).fail(function(k,m,l){h.reject(k,m,l)});return h.promise()};d.prototype.getFilesWithId=function(i){var h=f.Deferred();f.ajax({url:this.url+"/byAttachmentIds",type:"POST",data:JSON.stringify({attachmentIds:i}),dataType:"json",contentType:"application/json; charset=utf-8"}).then(function(k){var j=c.map(k.results,e);h.resolve(j)}).fail(function(j,l,k){h.reject(j,l,k)});return h.promise()};d.prototype.getFileWithId=function(h){return this.getFilesWithId([h]).pipe(function(i){return i[0]})};d.prototype.getFilesWithoutId=function(i){var h=f.Deferred();f.ajax({url:this.url+"/minusAttachmentIds",type:"POST",data:JSON.stringify({attachmentIds:i}),dataType:"json",contentType:"application/json; charset=utf-8"}).then(function(k){var j=c.map(k.results,e);h.resolve(j)}).fail(function(j,l,k){h.reject(j,l,k)});return h.promise()};return d});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-previews:confluence-previews-resources', location = '/js/confluence/file-preview-loader.js' */
define("cp/confluence/file-preview-loader",["jquery","underscore","ajs","cp/confluence/preview-support","cp/confluence/async-module-backend","FileViewer","cp/confluence/conversion-poller","cp/service/files-service","cp/service/comments-service","cp/service/versions-service"],function(q,I,h,G,H,c,n,a,k,E){var v,e,A,b=false;var u=function(K,L){h.trigger("analyticsEvent",{name:K,data:L})};var r=c.require("file-types");function C(K){return K.attr("data-image-src")||K.attr("data-file-src")||K.attr("src")||K.attr("href")}function x(K){return K.attr("data-linked-resource-content-type")||K.attr("data-mime-type")||"image/web"}function o(L,N){var K=q(L);var M=C(K);var O=K.attr("data-linked-resource-default-alias");return{src:M,srcDownload:M+"&download=true",thumbnail:M,type:x(K),title:O||M,name:O,rank:N,id:K.attr("data-linked-resource-id"),version:K.attr("data-linked-resource-version"),ownerId:K.attr("data-linked-resource-container-id"),isRemoteLink:K.hasClass("confluence-external-resource")}}function s(L){var K=0;return I.map(L,function(M){return o(M,K++)})}function J(K){if(c.isPluginEnabled("annotation")){K.once("fv.showFile",function(){c.getPlugin("annotation").showAnnotationsPanel(K)})}}function w(P,N){var O=q(P);var S;if(v&&b&&e===N.viewMode){N.enablePermalinks=true;p(A,N);S=q.when()}else{v&&v.close();S=F(P,N);b=true}if(!P){return}var M=O.attr("data-linked-resource-id"),R=O.attr("data-linked-resource-container-id"),L=O.attr("data-image-src")||O.attr("data-file-src")||O.attr("src");var Q=(M&&R)?{id:M,ownerId:R}:{src:L};var K=v.getView();K.show=I.compose(K.show,function(T){h.trigger("remove-bindings.keyboardshortcuts");return T});K.hide=I.compose(K.hide,function(T){h.trigger("add-bindings.keyboardshortcuts");return T});v.open(Q,"main");if(N.autoShowAnnotationPanel){J(v)}}function f(K){if(K.id&&K.ownerId){return K.ownerId+"-"+K.id}return K.src}var m={showPreviewerForComment:function(R,Q,O){var P=q(R);var L=Q.find(G.getFileSelectorString());var M=I.uniq(L,function(U){return U.src||U.href});A=s(M);O.enablePermalinks=false;m.setupPreviewerForComment(O);var N=P.attr("data-linked-resource-id"),T=P.attr("data-linked-resource-container-id"),K=P.attr("data-image-src")||P.attr("data-file-src")||P.attr("src");var S=(N&&T)?{id:N,ownerId:T}:{src:K};v.open(S,"comments");if(O.autoShowAnnotationPanel){J(v)}},setupPreviewerForComment:function(L){var M=q.when();var K=h.Meta.get("page-id");if(K){M=y(K,true)}p(i(A),L);M.then(function(){v.updateFiles(i(A),f)});return M}};function D(L,K){var M=l(L,K);M.open({id:M.getFiles()[0].id},K&&K.source)}function l(L,K){var M=I.isArray(L)?L:s(q(L));K.enablePermalinks=false;p(M,K);return v}var g;var t=function(M){g&&g.stop();var N=M.get("id");var L=M.get("version");var K=q.Deferred();if(!N){return q.when(true,M.get("src"),M.get("type"))}g=new n(N,L,"conversion",function(O){if(O==="converting"||O==="busy"){K.resolve(false,M.get("src"),M.get("type"))}});g.promise().then(function(P,O){if(K.state()!=="pending"){return}K.resolve(true,P,O)}).fail(function(O){if(K.state()!=="pending"){return}if(O==="cancelled"){K.reject(O)}else{K.resolve(true,M.get("src"),M.get("type"))}});return K.promise()};var B=function(M){g&&g.stop();var N=M.get("id");var L=M.get("version");var K=q.Deferred();g=new n(N,L,"conversion");g.promise().done(function(P,O){K.resolve(P,O)}).fail(function(O){if(O!=="cancelled"){K.resolve(M.get("src"),M.get("type"))}else{K.reject(O)}});return K.promise()};var d=function(N){var P=N.get("type"),L=N.get("src"),M=N.get("id"),Q=N.get("isRemoteLink"),S=q.Deferred();if(!Q&&r.isImageBrowserSupported(P)){var K=L.replace("/attachments/","/thumbnails/");S.resolve(K,"image/jpeg")}else{if(M){var O=N.get("version");var R=new n(M,O,"thumbnail");R.promise().done(function(U,T){S.resolve(U,T)}).fail(function(){S.reject()})}else{S.resolve(L,P)}}return S.promise()};function j(L,K){e=K.viewMode;var M={appendTo:q("body"),files:L,filesService:a,commentService:k,versionsService:E,moduleBackend:H,enableAnnotations:h.DarkFeatures.isEnabled("file-annotations"),enablePermalinks:h.DarkFeatures.isEnabled("previews.sharing"),enableMiniMode:true,enableShareButton:true,enableVersionNavigation:true,viewers:["image","document"],analyticsBackend:u};if(K&&K.viewMode===G.VIEW_MODE.SIMPLE){M.enableAnnotations=false;M.enableMiniMode=false;M.enableShareButton=false;M.enableVersionNavigation=false}if(h.DarkFeatures.isEnabled("previews.conversion-service")){M.isPreviewGenerated=t;M.generatePreview=B;M.generateThumbnail=d}v=new c(M);return v}function p(L,K){if(!v||e!==K.viewMode){v&&v.close();j(L,K)}v.updateFiles(L);if(c.isPluginEnabled("permalink")){c.getPlugin("permalink").setRoutingEnabled(K.enablePermalinks)}}function F(N,M){var Q=function(){M.enablePermalinks=true;p(i(A),M);if(c.isPluginEnabled("permalink")){c.getPlugin("permalink").startRouting()}};var L=I.uniq(q(G.getFileSelectorString()),function(R){return q(R).attr("data-linked-resource-id")||R.src});A=s(L);var P=h.Meta.get("user-timezone-offset");if(!P){h.Meta.set("user-timezone-offset",0)}var O;var K=h.Meta.get("page-id");if(K){O=y(K)}else{O=q.when()}if(N){Q();O.then(function(){v.updateFiles(i(A),f)})}else{O.then(Q)}return O}function i(K){return I.uniq(K,f)}var z=function(L){var M=h.DarkFeatures.isEnabled("previews.trigger-all-file-types");var K=h.DarkFeatures.isEnabled("previews.conversion-service");if(!M&&!K){L=I.filter(L,function(N){return r.isImage(N.type)||(r.isPDF(N.type)&&G.isPDFSupported())})}A=i(L.concat(A))};function y(M,L){var O=I.filter(A,function(R){return !!R.id}),P=I.pluck(O,"id"),Q=M,K=new a(Q);var N=[];if(P.length){N.push(K.getFilesWithId(P));if(!L){N.push(K.getFilesWithoutId(P))}}else{N.push(K.getFiles())}return q.when.apply(q,N).done(function(){var R=I.reduce(arguments,function(T,S){return T.concat(S)});z(R)})}return{showPreviewer:w,showPreviewerForSingleFile:D,setupPreviewForSingleFile:l,showPreviewerForComment:m.showPreviewerForComment}});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.extra.officeconnector:file-viewer-plugin', location = 'javascript/edit-in-office-plugin.js' */
define("office-connector/edit-in-office-plugin",["jquery","ajs","office-connector/edit-in-office"],function(C,H,F){var I=function(J){J.on("fv.showFile fv.showFileError",function(K){if(K&&B(K.get("src"))&&D()){J.addFileAction({key:"edit-in-office",text:"Edit in Office",callback:G})
}})
};
var D=function(){return H.Meta.get("content-type")==="page"||H.Meta.get("content-type")==="blogpost"
};
var B=function(K){var L="";
if(K){var M=K.substring(0,K.lastIndexOf("?"));
L=F.getProgID(M)
}var J=(L!=="");
return J&&(A()||E())
};
var A=function(){var J,K=(window.ActiveXObject!==undefined);
if(K){try{J=new ActiveXObject("SharePoint.OpenDocuments.1")
}catch(L){}}return J
};
var E=function(){return window.URLLauncher||window.InstallTrigger
};
var G=function(J){var L=J.get("attachmentId")||J.get("id");
var K=H.contextPath();
C.getJSON(K+"/rest/office/1.0/metadata/"+L).done(function(O){var P=K+O.webDavUrl;
var N=O.usePathAuth;
var M=getProgID(P);
return F.doEditInOffice(K,P,M,N)
})
};
return I
});
var FileViewer=require("FileViewer");
var EditInOfficePlugin=require("office-connector/edit-in-office-plugin");
FileViewer.registerPlugin("editInOffice",EditInOfficePlugin);
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-previews:annotation-plugin', location = '/templates/annotation.soy' */
// This file was automatically generated from annotation.soy.
// Please don't edit this file by hand.

if (typeof FileViewer == 'undefined') { var FileViewer = {}; }
if (typeof FileViewer.Templates == 'undefined') { FileViewer.Templates = {}; }
if (typeof FileViewer.Templates.Annotation == 'undefined') { FileViewer.Templates.Annotation = {}; }


FileViewer.Templates.Annotation.controlAnnotationButton = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<a href="#" id="cp-control-panel-annotations" class="cp-icon" title="', soy.$$escapeHtml("Comments"), '">', soy.$$escapeHtml("Comments"), '.<div class="counter">0</div></a>');
  return opt_sb ? '' : output.toString();
};


FileViewer.Templates.Annotation.blankAnnotation = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<div id="cp-blank-annotation"><h5>', soy.$$escapeHtml("Review and collaborate on this file"), '</h5><p>', soy.$$escapeHtml("You can comment on any part of this file, just drag a pin to where you want to add the first comment."), '</p><p>', soy.$$escapeHtml("@Mention team members in your comment to get their attention."), '</p></div>');
  return opt_sb ? '' : output.toString();
};


FileViewer.Templates.Annotation.annotationHeader = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<div class="cp-error"/><a id="cp-annotation-next" title="', soy.$$escapeHtml("Next comment"), '" class="cp-small-icon" href="#">', soy.$$escapeHtml("Next comment"), '</a><a id="cp-annotation-previous" title="', soy.$$escapeHtml("Previous comment"), '" class="cp-small-icon" href="#">', soy.$$escapeHtml("Previous comment"), '</a>', (opt_data.current != 0) ? '<span id="cp-annotation-count">' + soy.$$escapeHtml(AJS.format("{0} of {1}",opt_data.current,opt_data.total)) + '</span>' : '');
  if (opt_data.canDelete && ! opt_data.resolved) {
    output.append('<a id="cp-annotation-more" href="#cp-annotations-more-menu" aria-owns="cp-annotations-more-menu" aria-haspopup="true" class="aui-dropdown2-trigger aui-dropdown2-trigger-arrowless">');
    aui.icons.icon({useIconFont: true, size: 'small', icon: 'more', accessibilityText: "More", extraClasses: 'cp-small-icon up'}, output);
    output.append('</a><div id="cp-annotations-more-menu" class="aui-dropdown2 aui-style-default"><ul class="aui-list-truncate"><li><a href="#" id="cp-annotation-delete">', soy.$$escapeHtml("Delete"), '</a></li></ul></div>');
  }
  return opt_sb ? '' : output.toString();
};


FileViewer.Templates.Annotation.annotationUserHeader = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<div class="', soy.$$escapeHtml(opt_data.small == true ? 'cp-annotation-user-small' : 'cp-annotation-user'), '"><img src="', soy.$$escapeHtml(opt_data.author.avatar), '"></img><a href="', soy.$$escapeHtml(opt_data.author.profile), '">', soy.$$escapeHtml(opt_data.author.name), '</a></div>');
  return opt_sb ? '' : output.toString();
};


FileViewer.Templates.Annotation.addAnnotation = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<div class="cp-error"/><div class="cp-annotation-adding">');
  FileViewer.Templates.Annotation.annotationUserHeader(opt_data, output);
  output.append('<div class="cp-add-annotation cp-editor"><form class="aui"><div class="loading-container" /></form></div></div>');
  return opt_sb ? '' : output.toString();
};


FileViewer.Templates.Annotation.annotationTextarea = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<div class="cp-add-annotation cp-editor"><form class="aui"><div class="loading-container" /></form></div>');
  return opt_sb ? '' : output.toString();
};


FileViewer.Templates.Annotation.topLevelAnnotation = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<div id="cp-top-level-annotation" data-commentId=', soy.$$escapeHtml(opt_data.id), '>');
  FileViewer.Templates.Annotation.annotationUserHeader(opt_data, output);
  output.append('<div id="cp-annotation-main-comment" class="cp-annotation-comment  wiki-content"><p>', opt_data.comment, '</p></div><ul class="cp-annotation-actions">', (opt_data.canEdit && ! opt_data.resolved) ? '<li><a class="cp-annotation-edit" href="#">' + soy.$$escapeHtml("Edit") + '</a></li>' : '', (opt_data.canResolve) ? '<li><a class="cp-annotation-resolve" href="#">' + ((opt_data.resolved) ? soy.$$escapeHtml("Unresolve") : soy.$$escapeHtml("Resolve")) + '</a></li>' : '', (! opt_data.resolved) ? '<span class="cp-annotation-comment-like"></span>' : '', '<li class="nobullet">', soy.$$escapeHtml(AJS.DateTimeFormatting.friendlyFormatDateTime(new Date(opt_data.date), new Date(), Number(AJS.Meta.get('user-timezone-offset')))), '</li></ul></id>');
  return opt_sb ? '' : output.toString();
};


FileViewer.Templates.Annotation.likes = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<li>', (opt_data.hasLiked) ? '<a class="cp-annotation-unlike" href="#">' + soy.$$escapeHtml("Unlike") + '</a>' : '<a class="cp-annotation-like" href="#">' + soy.$$escapeHtml("Like") + '</a>', '</li>', (opt_data.likes > 0) ? '<li><span class="cp-annotation-like-summary"><span class="cp-annotation-like-icon aui-icon aui-icon-small aui-iconfont-like-small"></span><span class="cp-annotation-count">' + soy.$$escapeHtml(opt_data.likes) + '</span></span></li>' : '');
  return opt_sb ? '' : output.toString();
};


FileViewer.Templates.Annotation.annotationReply = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  FileViewer.Templates.Annotation.annotationUserHeader({author: opt_data.author, small: true}, output);
  output.append('<div class="cp-annotation-comment wiki-content" data-commentId=', soy.$$escapeHtml(opt_data.id), '><p>', opt_data.comment, '</p></div><ul class="cp-annotation-actions">', (! opt_data.resolved) ? ((opt_data.canEdit) ? '<li><a class="cp-annotation-edit" href="#">' + soy.$$escapeHtml("Edit") + '</a></li>' : '') + ((opt_data.canDelete) ? '<li><a class="cp-annotation-delete" href="#">' + soy.$$escapeHtml("Delete") + '</a></li>' : '') + '<span class="cp-annotation-reply-like"></span>' : '', '<li class="nobullet">', soy.$$escapeHtml(AJS.DateTimeFormatting.friendlyFormatDateTime(new Date(opt_data.date), new Date(), Number(AJS.Meta.get('user-timezone-offset')))), '</li></ul>');
  return opt_sb ? '' : output.toString();
};


FileViewer.Templates.Annotation.annotationLike = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<a href="#">', (opt_data.liked) ? soy.$$escapeHtml("Unlike") : soy.$$escapeHtml("Like"), '</a>');
  return opt_sb ? '' : output.toString();
};


FileViewer.Templates.Annotation.annotationReplyInput = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<div id="cp-annotation-reply-input">');
  if (! opt_data.resolved && opt_data.canReply) {
    FileViewer.Templates.Annotation.annotationUserHeader({author: opt_data.author, small: true}, output);
    FileViewer.Templates.Annotation.replyInputBox(null, output);
  }
  output.append('</div>');
  return opt_sb ? '' : output.toString();
};


FileViewer.Templates.Annotation.replyInputBox = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<input placeholder="', soy.$$escapeHtml("Reply"), '"></input>');
  return opt_sb ? '' : output.toString();
};


FileViewer.Templates.Annotation.resolved = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<div id="cp-annotation-resolved"><p>', soy.$$escapeHtml("Resolved"), '</p><div class="cp-resolved-info">', soy.$$escapeHtml("Resolved feedback can be shown from the tools menu."), '</div></div>');
  return opt_sb ? '' : output.toString();
};


FileViewer.Templates.Annotation.editorLoader = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<form class="aui"><div class="loading-container" /></form>');
  return opt_sb ? '' : output.toString();
};


FileViewer.Templates.Annotation.fileControlAnnotate = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<a href="#" id=\'cp-file-control-annotate\' class=\'cp-icon\' title="', soy.$$escapeHtml("Drag this pin to add a comment"), '">', soy.$$escapeHtml("Drag this pin to add a comment"), '</a>');
  return opt_sb ? '' : output.toString();
};

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-previews:annotation-plugin', location = '/js/component/utils/editor-utils.js' */
define("cp/component/utils/editor-utils",["jquery","underscore","ajs","backbone","exports"],function(d,i,f,h,c){var g=["dateautocomplete","confluencemacrobrowser","propertypanel","jiraconnector","dfe"];var a=["autoresize"];function e(){return i.clone(g)}function b(){return i.clone(a)}function j(){var k=f.Rte&&f.Rte.getEditor();if(k&&k.getContent()!==""){k.setDirty(true)}if(k&&k.isDirty()&&!d(".quick-comment-body .editor-container").length){return window.confirm("You have an unsaved comment on this page. Are you sure you want to continue? You will lose any unsaved changes.")}return true}c.getUnsupportedRtePlugins=e;c.getSupportedRtePlugins=b;c.confirmProcess=j});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-previews:annotation-plugin', location = '/js/component/utils/editor.js' */
define("cp/component/utils/editor",["jquery","underscore","ajs","cp/component/utils/editor-utils","exports","FileViewer"],function(c,q,e,h,s,a){var b;var l;var k;var g;var f;function n(t,u){if(!e.Confluence.EditorLoader.resourcesLoaded()){this.$form.find(".loading-container").spin("small")}b=a.prototype.close;u.close=function(){if(h.confirmProcess()){r();return b.apply(this,arguments)}};l=a.prototype.showFileNext;u.showFileNext=function(){if(h.confirmProcess()){r();return l.apply(this,arguments)}};k=a.prototype.showFilePrev;u.showFilePrev=function(){if(h.confirmProcess()){r();return k.apply(this,arguments)}};g=a.prototype.showFileWithCID;u.showFileWithCID=function(){if(h.confirmProcess()){r();return g.apply(this,arguments)}};f=a.prototype.showFile;u.showFile=function(){if(h.confirmProcess()){r();return f.apply(this,arguments)}};t&&t()}function j(t){e.Meta.set("content-type","comment");e.Meta.set("min-editor-height",80);e.Meta.set("use-inline-tasks","false");t&&t()}function i(u,t){t.$form.find(".loading-container").hide();t.$form.find("#rte-button-preview").hide();t.$form.find("#rte-button-publish").text("Save").removeAttr("title");t.$form.find("#rte-spinner").parent().addClass("rte-button-spinner").appendTo("#rte-savebar .toolbar-split .toolbar-split-right");t.$form.find("#toolbar-hints-draft-status").hide();t.$form.find("#wysiwygTextarea_ifr").height(e.Meta.get("min-editor-height"));e.Meta.set("min-editor-height",undefined);if(this.hideCancelButton){t.$form.find("#rte-button-cancel").hide()}u&&u();e.Confluence.QuickEdit.QuickEditPage.disable()}function o(t,u){u.close=b;u.showFileNext=l;u.showFilePrev=k;u.showFileWithCID=g;u.showFile=f;t&&t()}function m(t){return e.Confluence.QuickEdit.activateEditor({preActivate:q.partial(n,t.preActivate,t._fileViewer),preInitialise:q.partial(j,t.preInitialise),postInitialise:q.partial(c.proxy(i,t),t.postInitialise),toolbar:false,$container:t.container,$form:t.form,saveHandler:t.saveHandler,cancelHandler:t.cancelHandler,fetchContent:t.fetchContent(),closeAnyExistingEditor:true,postDeactivate:q.partial(o,t.postDeactivate,t._fileViewer),plugins:h.getSupportedRtePlugins(),excludePlugins:h.getUnsupportedRtePlugins()})}function r(){if(e.Rte&&e.Rte.getEditor()){if(!c(".quick-comment-body .editor-container").length){return e.Confluence.QuickEdit.deactivateEditor()}}else{return c.Deferred().resolve()}}function p(){return e.Rte.Content.getHtml()}function d(t){c(".ic-sidebar .rte-button-spinner").toggleClass("aui-icon-wait",t)}s.init=m;s.remove=r;s.getContent=p;s.setEditorBusy=d});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-previews:annotation-plugin', location = '/js/component/utils/editor-view.js' */
define("cp/component/utils/editor-view",["backbone","underscore","jquery","cp/component/utils/editor","cp/component/utils/editor-utils"],function(f,c,d,a,e){var b=f.View.extend({initialize:function(g){this.editorSetup=g.editorSetup;this.preActivate=g.preActivate;this.preInitialise=g.preInitialise;this.postInitialise=g.postInitialise;this.container=g.container;this.saveHandler=g.saveHandler;this.cancelHandler=g.cancelHandler;this.postDeactivate=g.postDeactivate;this.content=g.content;this.errorCallback=g.error;this.restoreCallback=g.restoreCallback;this.successCallback=g.success;this._fileViewer=g.fileViewer;this.editorSetup&&this.editorSetup()},render:function(){a.init({preActivate:this.preActivate,preInitialise:this.preInitialise,postInitialise:this.postInitialise,container:this.container,form:this.container.find("form.aui"),saveHandler:this.saveHandler,cancelHandler:this.cancelHandler,fetchContent:function(){var g=new d.Deferred();g.resolve({editorContent:this.content});return g}.bind(this),closeAnyExistingEditor:true,postDeactivate:this.postDeactivate,_fileViewer:this._fileViewer}).fail(function(){this.errorCallback()}.bind(this));return this},getContent:function(){return a.getContent()},remove:function(){a.remove();return this},checkIfOpen:function(){return e.confirmProcess()}});return b});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-previews:annotation-plugin', location = '/js/component/annotation/annotation-button-view.js' */
define("cp/component/annotation/annotation-button-view",["jquery","backbone","FileViewer","cp/component/utils/editor-utils"],function(d,f,c,e){var a=c.require("template-store-singleton");var b=f.View.extend({events:{click:"_toggleAnnotations"},tagName:"span",initialize:function(g){this._fileViewer=g.fileViewer;this._model=this._fileViewer.getCurrentFile();this._annotations=this._model.get("annotations");this.listenTo(this._annotations,"add reset sync change:resolved remove filterUpdated",this._updateAnnotationCount)},render:function(){this.$el.html(a.get("Annotation.controlAnnotationButton")());this._updateAnnotationCount();if(d.fn.tooltip){this.$("a").tooltip({gravity:"n"})}return this},_toggleAnnotations:function(){if(this._fileViewer.getView().fileSidebarView.isAnyPanelInitialized()){if(e.confirmProcess()){this._fileViewer.trigger("cp.close-editor");this._fileViewer.getView().fileSidebarView.teardownPanel()}}else{this._annotations.getCurrentOrNext();this._fileViewer.getView().fileSidebarView.initializePanel("annotations")}},_updateAnnotationCount:function(){var g=this._annotations.getCount();this.$(".counter").text(g>9?"9+":g)}});return b});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-previews:annotation-plugin', location = '/js/component/annotation/comments.js' */
define("cp/component/annotation/comments",["backbone","underscore","cp/component/annotation/comment"],function(e,a,c){var b=function(f){return function(g){for(var h in f){if(f[h]!==g.get(h)){return false}}return true}};var d=e.Collection.extend({model:c,initialize:function(f,g){this._current=null;this.service=g&&g.service;this._currentFilter={resolved:false};if(g&&g.fileModel){this.fileModel=g.fileModel}this.listenTo(this,"remove",this.selectNextIfRemoved)},comparator:function(h){var f=h.get("position");var g=h.get("pageNumber");return[g,f[1],f[0]]},selectNextIfRemoved:function(f){if(this._current===f){this.next()}},fetchComments:function(){if(this.size()===0){return this.fetch()}else{return $.when()}},sync:function(i,h){if(!this.service){return}if(i==="read"){var g=h.service.getAnnotations(),f=this;g&&g.done(function(j){j=a.map(j,function(k){return new c(k,{service:f.service})});h.reset(j,{silent:true});h.trigger("sync",h)});return g}},currentIndexOfWhere:function(g,f){return f?this.where(f).indexOf(g):this.indexOf(g)},nextWhere:function(h){var g=this.indexOf(this._current);var f=this.chain().rest(g+1).filter(b(h)).first().value();f=f||this.chain().filter(b(h)).first().value();this.setSelected(f);return f},prevWhere:function(h){var g=this.indexOf(this._current);var f=this.chain().first(Math.max(g,0)).filter(b(h)).last().value();f=f||this.chain().filter(b(h)).last().value();this.setSelected(f);return f},currentIndexOf:function(f){return this.currentIndexOfWhere(f,this._currentFilter)},next:function(){return this.nextWhere(this._currentFilter)},prev:function(){return this.prevWhere(this._currentFilter)},getCurrent:function(){return this._current},getCurrentOrNext:function(){if(!this._current||!this.isFiltered(this._current)){this._current=this.next()}return this.getCurrent()},isFiltered:function(f){var g=b(this.getFilter());return g(f)},selectCommentWithId:function(g,f){var h=this.findWhere({id:g});if(h&&h.get("resolved")){this.setFilter()}if(f){h.replies.selectReplyWithId(f)}this.setSelected(h);this.trigger("pinSelected")},setSelected:function(g,f){this.invoke("set",{selected:false});this._current=null;if(g){g.set({selected:true});this._current=g;g.replies.fetch();!f&&this.trigger("selected",g)}else{!f&&this.trigger("unselected")}},setResolved:function(f){f.set({resolved:true})},getCountWhere:function(f){return f?this.where(f).length:this.size()},getCount:function(){return this.getCountWhere(this._currentFilter)},setFilter:function(f){this._currentFilter=f;this.trigger("filterUpdated");return this},getFilter:function(){return this._currentFilter}});return d});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-previews:annotation-plugin', location = '/js/component/annotation/comment.js' */
define("cp/component/annotation/comment",["cp/component/annotation/replies","cp/component/annotation/likes","ajs","backbone"],function(b,d,a,e){var c=e.Model.extend({defaults:{author:{name:"",avatar:"",profile:""},comment:"",date:new Date(),pageNumber:1,position:[0.5,0.5],resolved:false,selected:false,hasEditPermission:true,hasResolvePermission:true,hasDeletePermission:true,hasReplyPermission:true},initialize:function(f,g){this.service=g.service;if(this.service){this.replies=new b(undefined,{service:this.service,parentModel:this})}else{this.replies=new b()}this.likes=new d([],{contentId:this.get("id"),replies:this.replies.models});this.on("change:id",this.createLikes);this.listenTo(this.replies,"reset sync",this.createLikes);this.createLikes();this.set("fileModel",f.fileModel)},createLikes:function(){if(!this.replies.isSynced()){return}if(this.get("id")!==undefined){this.likes.setReplies(this.replies.models);this.likes.fetch()}},setResolved:function(f){this.save({resolved:f})},isNew:function(){return this.get("isNew")},sync:function(i,g,f){if(!this.service){return}if(i==="create"||i==="update"){var h=g.service.save(g);h.done(function(j){g.set(j);f.success()}).fail(function(){f.error()});return h}else{if(i==="delete"){var h=g.service.remove(g);h.done(function(){f.success()}).fail(function(){f.error()});return h}}}});return c});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-previews:annotation-plugin', location = '/js/component/annotation/replies.js' */
define("cp/component/annotation/replies",["backbone","underscore","cp/component/annotation/reply"],function(d,b,a){var c=d.Collection.extend({initialize:function(e,f){this.parentModel=f.parentModel;this.service=f&&f.service;this.synced=false;this._skipFetch=false},sync:function(j,h,e){var i=h.parentModel&&h.parentModel.get("id");if(e.force){this._skipFetch=false}if(!this.service||!i||this._skipFetch){return}if(j==="read"){this._skipFetch=true;var g=h.service.getReplies({parentId:i}),f=this;g.done(function(k){k=b.map(k,function(l){return new a(l,{service:f.service})});this.synced=true;h.reset(k)}.bind(this)).fail(function(){this.synced=false;this._skipFetch=false}.bind(this))}},addReply:function(g,e){var f=new a(g,{service:this.service});this.setSelected(f);this.add(f);f.save(null,{wait:true,error:e.error})},selectReplyWithId:function(e){if(!this.isSynced()){this.listenToOnce(this,"reset",function(){this.setSelected(this.findWhere({id:e}))})}else{this.setSelected(this.findWhere({id:e}))}},setSelected:function(e){this.invoke("set",{selected:false});if(e){e.set("selected",true)}},isSynced:function(){return this.synced}});return c});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-previews:annotation-plugin', location = '/js/component/annotation/reply.js' */
define("cp/component/annotation/reply",["backbone","cp/component/annotation/likes"],function(c,b){var a=c.Model.extend({defaults:{author:"",comment:"",date:new Date(),resolved:false,hasEditPermission:false,hasDeletePermission:false},initialize:function(d,e){this.service=e.service},sync:function(g,e,d){if(!this.service){return}if(g==="create"||g==="update"){var f=e.service.save(e);f.done(function(h){e.set(h);d.success()}).fail(function(){d.error()});return f}else{if(g==="delete"){var f=e.service.remove(e);f.done(function(h){d.success()}).fail(function(){d.error()});return f}}}});return a});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-previews:annotation-plugin', location = '/js/component/annotation/annotation-view.js' */
define("cp/component/annotation/annotation-view",["backbone","underscore","jquery","ajs","cp/component/annotation/annotation-header-view","cp/component/annotation/comment-view","confluence","cp/component/annotation/add-annotation-view","FileViewer"],function(g,i,d,f,j,a,h,e,b){var k=b.require("template-store-singleton");var c=g.View.extend({id:"cp-annotations",tagName:"div",initialize:function(l){this._fileViewer=l.fileViewer;this.fileSidebarView=l.panelView;this.model=this._fileViewer.getCurrentFile();this.annotations=this.model.get("annotations");this.listenTo(this.annotations,"reset sync selected unselected add remove",this.render);this.listenTo(this.annotations,"pinSelected",this.show);this.listenTo(this.annotations,"filterUpdated",this.updateWithFiltered);this.listenTo(this._fileViewer,"cp.close-editor",this._closeEditor);this.show();this.render()},teardown:function(){this.hide();this.commentView&&this.commentView.off().remove();this.addAnnotationView&&this.addAnnotationView.teardown()&&this.addAnnotationView.off().remove()},hide:function(){d("#cp-control-panel-annotations").removeClass("focused");this.annotations.setSelected();this._fileViewer._fileState.trigger("cp.hideAnnotations")},show:function(){d("#cp-control-panel-annotations").addClass("focused")},addAnnotation:function(m){if(!this.canOpenNewEditor()){d("#cp-file-control-annotate").draggable("option","disabled",false);return}this.show();this.annotations.setSelected();var l=this._fileViewer.getCurrentFile().createAnnotation({author:this.currentUser,position:[m.x,m.y],pageNumber:m.pageNumber,isNew:true});this.annotations.setSelected(l,true);this.addAnnotationView=new e({annotation:l,collection:this.annotations,fileViewer:this._fileViewer,annotationView:this});this.$el.html(this.addAnnotationView.$el);this.addAnnotationView.render();this.$el.find("textarea.cp-add-annotation").focus()},render:function(){if(this.annotations){var l=this.annotations.getCurrent();if(!l){this.$el.html(k.get("Annotation.blankAnnotation")())}else{this.headerView=new j({model:this.model,annotationView:this});this.commentView=new a({model:l,annotationView:this});this.$el.empty().append(this.headerView.render().$el).append(this.commentView.render().el)}}return this},_generateError:function(l){this.headerView._generateError(l)},canOpenNewEditor:function(){return !this._editorView||this._editorView.checkIfOpen()},isCommentVisible:function(l){return this.annotations.isFiltered(l)},clearErrorFlags:function(){this.headerView._clearError()},_closeEditor:function(){this._editorView&&this._editorView.remove()},updateWithFiltered:function(){this.annotations.getCurrentOrNext();this.render()}});return c});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-previews:annotation-plugin', location = '/js/component/annotation/pin-view.js' */
define("cp/component/annotation/pin-view",["backbone","jquery","cp/component/annotation/comment","cp/component/utils/editor-utils"],function(e,b,c,d){var a=e.View.extend({model:c,tagName:"span",className:"cp-icon cp-active-annotation",events:{click:"clickPin"},clickPin:function(){if(d.confirmProcess()){var f=this._fileViewer.getView().fileSidebarView;if(this.model.get("selected")&&f.isPanelInitialized("annotations")){this.closeSidebar()}else{this.showPin();this._fileViewer.trigger("cp.close-editor")}}},closeSidebar:function(){this.collection.setSelected();this._fileViewer.trigger("cp.close-editor");this._fileViewer.getView().fileSidebarView.teardownPanel()},showPin:function(){this.collection.setSelected(this.model);this.collection.trigger("pinSelected");this._fileViewer._fileState.trigger("cp.showAnnotations")},initialize:function(f){this._fileViewer=f.fileViewer;this.calculatePosition=f.calculatePosition;this.listenTo(this.model,"sync",this.render);this.listenTo(this.model,"change:resolved",this.setResolved);this.listenTo(this.model,"change:selected",this.setAnimate)},setResolved:function(){var f=this.model.get("resolved");this.$el.toggleClass("resolved",f)},setSelected:function(){var f=this.model.get("selected");this.$el.toggleClass("selected",f)},setAnimate:function(){var f=this.model.get("selected");this.setSelected();this.$el.toggleClass("animate",f)},setPosition:function(){var g;if(this.calculatePosition){g=this.calculatePosition(this.model.toJSON())}else{var h=this.model.get("position");var f=h[0]*100;var i=h[1]*100;g={x:f+"%",y:i+"%"}}this.$el.css("top",g.y);this.$el.css("left",g.x)},render:function(){this.$el.attr("data-comment-id",this.model.get("id"));this.setPosition();this.setResolved();this.setSelected();return this}});return a});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-previews:annotation-plugin', location = '/js/component/annotation/pins-view.js' */
define("cp/component/annotation/pins-view",["backbone","jquery","underscore","cp/component/annotation/comments","cp/component/annotation/pin-view"],function(g,d,b,f,a){var c=function(h){return function(i){for(var j in h){if(h[j]!==i.get(j)){return false}}return true}};var e=g.View.extend({collection:f,initialize:function(h){this.container=h.container;this.filter=h.filter;this.calculatePosition=h.calculatePosition;this.collection=h.collection;this.annotationPins=[];this._fileViewer=h.fileViewer;this.listenTo(this.collection,"reset sync add remove",this.markRetrieved);this.listenTo(this.collection,"reset sync add remove",this.render);this.listenTo(this.collection,"filterUpdated",this.render)},markRetrieved:function(){d(this.container).attr("data-pins-retrieved",true)},render:function(){this.unbindAnnotationPins();var i=this.filter?b.filter(this.collection.models,this.filter):this.collection.models,h=this;b.chain(i).filter(c(this.collection.getFilter())).each(function(j){var k=new a({calculatePosition:h.calculatePosition,model:j,collection:h.collection,fileViewer:this._fileViewer});h.annotationPins.push(k);d(k.render().el).prependTo(h.container)},this)},unbindAnnotationPins:function(){while(this.annotationPins.length>0){var h=this.annotationPins.pop();h.remove().off()}},off:function(i,j,h){this.unbindAnnotationPins();return g.Collection.prototype.off.call(this,i,j,h)}});return e});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-previews:annotation-plugin', location = '/js/component/annotation/reply-view.js' */
define("cp/component/annotation/reply-view",["backbone","underscore","jquery","cp/component/annotation/reply","cp/component/utils/editor-view","cp/component/annotation/likes-view","FileViewer"],function(f,g,d,b,i,a,c){var h=c.require("template-store-singleton");var e=f.View.extend({model:b,tagName:"div",className:"cp-annotation-reply",events:{"click .cp-annotation-edit":"editReply","click .cp-annotation-delete":"deleteReply"},initialize:function(j){this.listenTo(this.model,"change",this.render);this.listenTo(this.model,"remove",this.remove);this._annotationView=j.annotationView;this._parentView=j.commentView},render:function(){if(!this.model.get("id")){return this}this.$el.html(h.get("Annotation.annotationReply")({id:this.model.get("id"),canEdit:this.model.get("hasEditPermission"),canDelete:this.model.get("hasDeletePermission"),author:this.model.get("author"),comment:this.model.get("comment"),date:this.model.get("date"),resolved:this._parentView._isResolved()}));if(this.model.get("selected")){this.$el.addClass("selected")}else{this.$el.removeClass("selected")}this.showLikes();return this},showLikes:function(){var j=new a({el:this.$el.find(".cp-annotation-reply-like"),id:this.model.get("id"),collection:this._parentView.model.likes,_annotationView:this._annotationView});j.render()},editReply:function(){if(!this._annotationView.canOpenNewEditor()){return}var j=this.model.get("editorFormat");this.editorView=this._annotationView._editorView=new i({editorSetup:function(){var k=d(h.get("Annotation.editorLoader")());this.$el.find(".cp-annotation-comment").replaceWith(k);this.$el.find(".cp-annotation-actions").hide()}.bind(this),container:this.$el,saveHandler:g.bind(this.saveReply,this),cancelHandler:g.bind(this.restore,this),postDeactivate:g.bind(this.restore,this),content:j,errorCallback:g.bind(this._handleEditorError,this),restoreCallback:g.bind(this.restore,this),fileViewer:this._annotationView._fileViewer});this.editorView.render()},saveReply:function(j){j&&j.preventDefault();if(this.editorView.getContent()===""){this._generateError("You cannot save an empty comment.");return}this._annotationView.clearErrorFlags();this.model.set({editorFormat:this.editorView.getContent()},{silent:true});this.model.save(null,{wait:true,success:this.restore.bind(this),error:this._handleError.bind(this)});this.editorView&&this.editorView.remove()},restore:function(j){j&&j.preventDefault&&j.preventDefault();this.editorView&&this.editorView.remove();this.render()},deleteReply:function(){var j=window.confirm("Are you sure you want to delete the reply?");if(j){this.model.destroy({wait:true,error:this._handleError.bind(this)})}},_handleError:function(){this._generateError("Error: There was a problem saving your changes.")},_handleEditorError:function(){this._generateError("Error: Could not open the editor.")},_generateError:function(j){this._annotationView._generateError(j)}});return e});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-previews:annotation-plugin', location = '/js/component/annotation/comment-view.js' */
define("cp/component/annotation/comment-view",["backbone","underscore","jquery","ajs","confluence","cp/component/annotation/comment","cp/component/annotation/reply-view","FileViewer","cp/component/annotation/likes-view","cp/component/utils/editor-view"],function(h,j,e,g,i,d,f,c,a,l){var k=c.require("template-store-singleton");var b=h.View.extend({model:d,tagName:"div",className:"cp-comment-view cp-editor",events:{"click input":"convertToEditor","click #cp-top-level-annotation .cp-annotation-edit":"editComment","click .cp-annotation-resolve":"resolve"},initialize:function(m){this.listenTo(this.model.replies,"reset add",this.showReplies);this.listenTo(this.model,"change",this.render);this.listenTo(this.model,"likesReady",this.showLikes);this.currentUser={name:g.Meta.get("current-user-fullname"),avatar:i.getContextPath()+g.Meta.get("current-user-avatar-url"),profile:i.getContextPath()+"/display/~"+g.Meta.get("remote-user")};this._annotationView=m.annotationView},renderComment:function(){return k.get("Annotation.topLevelAnnotation")({id:this.model.get("id"),author:this.model.get("author"),comment:this.model.get("comment"),canEdit:this.model.get("hasEditPermission"),canResolve:this.model.get("hasResolvePermission"),resolved:this.model.get("resolved"),date:this.model.get("date")})},renderTopLevelAnnotation:function(){this.$el.find("#cp-top-level-annotation").replaceWith(this.renderComment());this.showLikes()},render:function(){if(!this.model.get("id")){return this}if(this._annotationView.isCommentVisible(this.model)){this.$el.html(this.renderComment());e(k.get("Annotation.annotationReplyInput")({author:this.currentUser,canReply:this.model.get("hasReplyPermission"),resolved:this.model.get("resolved")})).appendTo(this.$el);this.showReplies();this.showLikes()}else{if(this.model.get("resolved")){this.$el.html(k.get("Annotation.resolved")())}}return this},editComment:function(n){if(!this._annotationView.canOpenNewEditor()){return}var m=this.model.get("editorFormat");this.editorView=this._annotationView._editorView=new l({editorSetup:function(){var o=e(k.get("Annotation.editorLoader")());this.$el.find("#cp-annotation-main-comment").replaceWith(o);this.$el.find("#cp-top-level-annotation .cp-annotation-actions").hide()}.bind(this),container:this.$el.find("#cp-top-level-annotation"),form:this.$el.find("form.aui"),saveHandler:j.bind(this.saveEdit,this),cancelHandler:j.bind(this.completedHandler,this),content:m,postDeactivate:j.bind(this.restoreCommentOnly,this),errorCallback:j.bind(this._handleEditorError,this),restoreCallback:j.bind(this.completedHandler,this),fileViewer:this._annotationView._fileViewer});this.editorView.render()},saveEdit:function(m){m&&m.preventDefault();if(this.editorView.getContent()===""){this._generateError("You cannot save an empty comment.");return}this.model.set({editorFormat:this.editorView.getContent()},{silent:true});this.model.save(null,{wait:true,success:this.restoreActions.bind(this),error:this._handleError.bind(this)});this.editorView&&this.editorView.remove()},completedHandler:function(m){this.restoreActions();m.preventDefault()},restoreActions:function(){this.$el.find("#cp-top-level-annotation .cp-annotation-actions").show();this.editorView&&this.editorView.remove()},restoreCommentOnly:function(m){this.$el.find("#cp-top-level-annotation .cp-annotation-actions").show();this.renderTopLevelAnnotation()},showLikes:function(){var m=this.model.likes;var n=new a({el:this.$el.find(".cp-annotation-comment-like"),id:this.model.get("id"),collection:m,_annotationView:this._annotationView});n.render()},convertToInputBox:function(m){m&&m.preventDefault();var n=e(k.get("Annotation.replyInputBox")());this.$el.find("form.aui").replaceWith(n);this.editorView&&this.editorView.remove()},restoreAfterEditorDeactivate:function(m){var n=e(k.get("Annotation.replyInputBox")());this.$el.find("form.aui.fadeIn").replaceWith(n)},convertToEditor:function(){if(!this._annotationView.canOpenNewEditor()){return}this.editorView=this._annotationView._editorView=new l({editorSetup:function(){var m=e(k.get("Annotation.editorLoader")());this.$el.find("input").replaceWith(m)}.bind(this),container:this.$el,saveHandler:j.bind(this.saveReply,this),cancelHandler:j.bind(this.convertToInputBox,this),content:"",postDeactivate:j.bind(this.restoreAfterEditorDeactivate,this),errorCallback:j.bind(this._handleEditorError,this),restoreCallback:function(){e("input").blur()},fileViewer:this._annotationView._fileViewer});this.editorView.render()},resolve:function(){if(this.model.get("resolved")){g.trigger("analyticsEvent",{name:"confluence-spaces.previews.annotation.unresolve",data:{fileType:this._annotationView._fileViewer.getCurrentFile().get("type"),commentId:this.model.get("id"),replyCount:this.model.replies.length}});this.model.setResolved(false)}else{if(!this._annotationView.canOpenNewEditor()){return}g.trigger("analyticsEvent",{name:"confluence-spaces.previews.annotation.resolve",data:{fileType:this._annotationView._fileViewer.getCurrentFile().get("type"),commentId:this.model.get("id"),replyCount:this.model.replies.length}});this.model.setResolved(true);this._annotationView._closeEditor()}},saveReply:function(n){n&&n.preventDefault();var m=this.model.replies;if(this.editorView.getContent()===""){this._generateError("You cannot save an empty comment.");return}this._annotationView.clearErrorFlags();m.addReply({author:this.currentUser,editorFormat:this.editorView.getContent(),parentId:this.model.get("id")},{error:this._handleError.bind(this)});g.trigger("analyticsEvent",{name:"confluence-spaces.previews.annotation.reply",data:{commentId:this.model.get("id")}});this.convertToInputBox()},showReplies:function(){this.$el.find(".cp-annotation-reply").remove();var n=this.model.replies,m=this;j.each(n.models,function(p){var o=new f({model:p,annotationView:m._annotationView,commentView:m});m.$el.find("#cp-annotation-reply-input").before(o.render().el)})},_handleError:function(){this._generateError("Error: There was a problem saving your changes.")},_handleEditorError:function(){this._generateError("Error: Could not open the editor.")},_generateError:function(m){this._annotationView._generateError(m)},_isResolved:function(){return this.model.get("resolved")}});return b});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-previews:annotation-plugin', location = '/js/component/annotation/annotation-header-view.js' */
define("cp/component/annotation/annotation-header-view",["backbone","underscore","jquery","ajs","confluence","FileViewer"],function(h,b,f,a,g,d){var c=d.require("template-store-singleton");var e=h.View.extend({tagName:"div",className:"cp-annotation-header",events:{"click #cp-annotation-next":"next","click #cp-annotation-previous":"previous"},initialize:function(i){this.annotations=this.model.get("annotations");this.current=this.annotations.getCurrent();this._annotationView=i.annotationView;this.listenTo(this.annotations,"filterUpdated",this.render)},next:function(){this.annotations.next()},previous:function(){this.annotations.prev()},render:function(){this.$el.html(c.get("Annotation.annotationHeader")({current:this.annotations.currentIndexOf(this.current)+1,total:this.annotations.getCount(),canDelete:this.current.get("hasDeletePermission"),resolved:this.current.get("resolved")}));f(".tipsy").remove()&&f.fn.tooltip&&this.$el.find("a").tooltip();var i=b.bind(this.deleteComment,this);this.$el.find("#cp-annotations-more-menu").on({"aui-dropdown2-show":function(){f("body").on("click","#cp-annotation-delete",i)},"aui-dropdown2-hide":function(){f("body").off("click","#cp-annotation-delete",i)}});return this},deleteComment:function(i){i.preventDefault();var j=window.confirm("Are you sure you want to delete the comment?");if(j){this._annotationView._closeEditor();this.annotations.getCurrent().destroy({wait:true,error:this._handleError.bind(this)})}},_handleError:function(){this._generateError("Error: There was a problem saving your changes.")},_generateError:function(i){this._clearError();a.messages.warning(".cp-error",{body:i})},_clearError:function(){f(".cp-error").empty()}});return e});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-previews:annotation-plugin', location = '/js/component/annotation/add-annotation-view.js' */
define("cp/component/annotation/add-annotation-view",["backbone","underscore","jquery","confluence","ajs","cp/component/utils/editor-view","cp/component/utils/editor-utils","FileViewer"],function(g,i,b,h,f,k,c,a){var j=a.require("template-store-singleton");var e=a.prototype.changeMode;var d=g.View.extend({tagName:"div",id:"cp-add-annotation",events:{},initialize:function(l){this._fileViewer=l.fileViewer;this._annotationView=l.annotationView;this.currentUser={name:f.Meta.get("current-user-fullname"),avatar:h.getContextPath()+f.Meta.get("current-user-avatar-url"),profile:h.getContextPath()+"/display/~"+f.Meta.get("remote-user")};this._annotation=l.annotation;this.listenTo(this._fileViewer._fileState,"cp.hideAnnotations",this.clearAnnotation);this.listenTo(l.fileViewer,"fv.close",this.clearAnnotation);this.listenTo(this.collection,"pinSelected",this.teardown)},render:function(){this.editorView=this._annotationView._editorView=new k({editorSetup:function(){this.$el.html(j.get("Annotation.addAnnotation")({author:this.currentUser}))}.bind(this),container:this.$el,saveHandler:i.bind(this.saveAnnotation,this),cancelHandler:i.bind(this.cancelAnnotation,this),content:"",restoreCallback:i.bind(this.cancelAnnotation,this),fileViewer:this._fileViewer});this.editorView.render();var l=this;this._fileViewer.changeMode=function(){if(c.confirmProcess()){l.cancelAnnotation();return e.apply(this,arguments)}};return this},cancelAnnotation:function(l){l&&l.preventDefault();this.removeNewAnnotation();this.collection.setSelected(this.collection.getCurrentOrNext())},removeNewAnnotation:function(){this.clearAnnotation();this._annotation.destroy();this.editorView&&this.editorView.remove();this._fileViewer.changeMode=e},clearAnnotation:function(){this._fileViewer.getView().$el.find("#cp-file-control-annotate").draggable("option","disabled",false)},saveAnnotation:function(l){l&&l.preventDefault();if(this.editorView.getContent()===""){this._generateError("You cannot save an empty comment.");return}this._annotation.set("editorFormat",this.editorView.getContent(),{silent:true});this._annotation.set("isNew",false);this._annotation.save();this.editorView&&this.editorView.remove();this.clearAnnotation();f.trigger("analyticsEvent",{name:"confluence-spaces.previews.annotation.comment",data:{fileType:this._fileViewer.getCurrentFile().get("type"),attachmentId:this._fileViewer.getCurrentFile().get("id")}});this.collection.setSelected(this._annotation);this._fileViewer.changeMode=e},teardown:function(){if(this._annotation.isNew()){this.removeNewAnnotation()}else{this.clearAnnotation()}return this},_generateError:function(l){b(".cp-error").empty();f.messages.warning(".cp-error",{body:l})}});return d});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-previews:annotation-plugin', location = '/js/component/annotation/likes.js' */
define("cp/component/annotation/likes",["backbone","underscore","jquery","cp/component/annotation/like","confluence"],function(f,b,c,a,e){var d=f.Collection.extend({model:a,initialize:function(h,g){this.contentId=g.contentId;this.replies=g.replies?g.replies:[];this._skipFetch=false},addLike:function(h,g){var i=b.find(this.models,function(j){return j.get("content_id")===h});if(!i){i=new a();this.add(i)}i.save(null,{id:h,wait:true,error:g.error})},removeLike:function(h,g){var i=b.find(this.models,function(j){return j.get("content_id")===h});i.id="";i.destroy({id:h,wait:true})},sync:function(k,j,h){if(h.force){this._skipFetch=false}if(this._skipFetch||!j.contentId){return}if(k==="read"){this._skipFetch=true;var i=this._getCommentIds();var g=c.Deferred();c.ajax({url:e.getContextPath()+"/rest/likes/1.0/content/likes",type:"POST",data:JSON.stringify(i),contentType:"application/json"}).then(function(m){var l=b.map(m,function(n){return new a(n)});j.reset(l);g.resolve(l)}).fail(function(l,n,m){this._skipFetch=false;g.reject(l,n,m)}.bind(this))}},setReplies:function(g){this.replies=g},_getCommentIds:function(){var g=[];g.push(this.contentId);if(this.replies){b.each(this.replies,function(h){g.push(h.get("id"))})}return{ids:g}}});return d});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-previews:annotation-plugin', location = '/js/component/annotation/like.js' */
define("cp/component/annotation/like",["backbone","jquery","confluence"],function(d,b,c){var a=d.Model.extend({defaults:{content_id:"",content_type:"",likes:[],summary:""},sync:function(g,f,e){if(g==="create"||g==="update"){b.ajax({url:c.getContextPath()+"/rest/likes/1.0/content/"+e.id+"/likes",type:"POST",contentType:"application/json"}).done(function(h){f.set(h);f.trigger("sync",f,h,e)}).error(function(){e.error&&e.error()})}else{if(g==="delete"){b.ajax({url:c.getContextPath()+"/rest/likes/1.0/content/"+e.id+"/likes",type:"DELETE",contentType:"application/json"}).done(function(h){f.set(h);f.trigger("sync",f,h,e)}).error(function(){e.error&&e.error()})}}}});return a});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-previews:annotation-plugin', location = '/js/component/annotation/likes-view.js' */
define("cp/component/annotation/likes-view",["backbone","jquery","underscore","ajs","cp/component/annotation/comments","FileViewer","cp/component/annotation/likes"],function(g,e,h,f,d,c,b){var i=c.require("template-store-singleton");var a=g.View.extend({collection:b,tagName:"span",className:"cp-annotation-like",events:{"click .cp-annotation-like":"like","click .cp-annotation-unlike":"unlike"},initialize:function(j){this.collection=j.collection;this.commentId=j.id;this._annotationView=j._annotationView;this.collection&&this.listenTo(this.collection,"reset add remove sync",this.render)},render:function(){this.$el.empty();if(this.collection===undefined){return}var k=h.find(this.collection.models,function(m){return m.attributes.content_id===this.commentId}.bind(this));var l=!!k&&h.some(k.get("likes"),function(m){return m.user.name===f.Meta.get("remote-user")});var j=k?k.get("likes").length:0;this.$el.html(i.get("Annotation.likes")({likes:j,hasLiked:l}));return this},like:function(){f.trigger("analyticsEvent",{name:"confluence-spaces.previews.annotation.like",data:{fileType:this._annotationView._fileViewer.getCurrentFile().get("type"),commentId:this.commentId}});this.collection.addLike(this.commentId,{error:this._handleError.bind(this)})},unlike:function(){this.collection.removeLike(this.commentId)},_handleError:function(){this._annotationView._generateError("Error: Unable to save your like.")}});return a});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-previews:annotation-plugin', location = '/js/component/annotation/content-view.js' */
define("cp/component/annotation/content-view",["FileViewer","backbone","underscore","jquery"],function(a,g,h,d){var c=500;var b=c-100;var i={PLUS:187,MINUS:189,PLUS_NUMPAD:107,MINUS_NUMPAD:109,PLUS_FF:61,MINUS_FF:173};var e=a.require("BaseViewer");var f={annotationEvents:{"mousemove.contentView.show":"_showControlsOnMove","mousemove.contentView.hide":"_hideControlsOnMove"},initialize:function(){this.events=h.extend(this.events||{},this.annotationEvents);this._toggleControlsTimeout=null;this._autoToggleControls=true;d(document).on("keydown.viewerZoom",this._handleKeyboardZoom.bind(this))},_showControlsOnMove:h.throttle(function(){if(!this._autoToggleControls){return}this.showControls()},b),_hideControlsOnMove:h.throttle(function(){if(!this._autoToggleControls){return}this.hideControls()},b),showControls:function(){if(!this.getControlsElement){return}clearTimeout(this._toggleControlsTimeout);this.getControlsElement().show()},hideControls:function(){if(!this.getControlsElement){return}this._toggleControlsTimeout=this._setHideTimer()},_setHideTimer:function(){return setTimeout(function(){if(this.getControlsElement().is(":hover")){return}this.getControlsElement().fadeOut()}.bind(this),c)},autoToggleControls:function(j){this._autoToggleControls=j;if(!this._autoToggleControls){clearTimeout(this._toggleControlsTimeout)}},_handleKeyboardZoom:function(j){var k=(j.ctrlKey||j.metaKey);if(this.zoomIn&&k&&(j.which===i.PLUS||j.which===i.PLUS_NUMPAD||j.which===i.PLUS_FF)){this.zoomIn();j.preventDefault()}if(this.zoomOut&&k&&(j.which===i.MINUS||j.which===i.MINUS_NUMPAD||j.which===i.MINUS_FF)){this.zoomOut();j.preventDefault()}}};Object.keys(f).forEach(function(j){e[j]=f[j]});return e});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-previews:annotation-plugin', location = '/js/component/annotation/annotation-plugin.js' */
define("cp/component/annotation/annotation-plugin",["FileViewer","cp/component/annotation/annotation-view","cp/component/annotation/annotation-button-view","cp/component/annotation/pins-view","cp/component/annotation/comments","cp/component/annotation/comment","cp/component/annotation/content-view","underscore","jquery"],function(b,e,l,f,d,c,g,j,h){var k=b.require("template-store-singleton");var i=b.require("unknown-file-type-view");var a=function(s){var r=s.getConfig();if(!r.enableAnnotations||!r.commentService){return}var z=r.commentService;g.prototype.annotationOptions={dropTarget:".cp-annotatable"};s.getView().fileSidebarView.addPanelView("annotations",e);var A=s.getView().fileControlsView;var o=s.getView().fileSidebarView;var w=function(){var B=s.getCurrentFile();return !B.get("isRemoteLink")};A.addLayerView("annotationButton",l,{predicate:w,weight:5});var q=a.showAnnotationsPanel;s._fileState.on("cp.showAnnotations",j.partial(q,s));var p=function(B){if(B.createAnnotation){return}B.set("annotations",new d([],{service:new z(B.get("id"),B.get("version")),fileModel:B}));if(b.isPluginEnabled("permalink")){var C=b.getPlugin("permalink");B.get("annotations").on("selected",function(D){if(D.get("id")){C.setRouteForPin(B,D)}else{D.on("change:id",function(){C.setRouteForPin(B,D)})}})}B.on("change:id",function(){this.get("annotations").service=new z(B.get("id"),B.get("version"))});B.createAnnotation=function(G){var F=j.extend(G,{fileModel:this});var H=this.get("annotations");var E=new z(B.get("id"),B.get("version"));var D=new c(F,{service:E});H.add(D);return D}.bind(B)};s.getView().on("fv.fileChange",p);var y=function(C){var B=s.getCurrentFile();if(B.get("annotations").where({resolved:true}).length>0){C.addFileAction({key:"resolved.toggle",text:"Show resolved comments",callback:function(){B.get("annotations").setFilter();x(C)}.bind(this)})}};var x=function(C){var B=s.getCurrentFile();C.addFileAction({key:"resolved.toggle",text:"Hide resolved comments",callback:function(){B.get("annotations").setFilter({resolved:false});y(C)}.bind(this)})};var v=function(B,D){var C=D.getFilter();if(j.isEqual(C,{resolved:false})){y(B)}else{x(B)}};var u;s.close=j.wrap(s.close,function(B){if(u){return}B.apply(s,Array.prototype.slice.call(arguments,1))});s.showFile=j.wrap(s.showFile,function(B){if(u){return}return B.apply(s,Array.prototype.slice.call(arguments,1))});var n=false;var m=function(T){var G=s.getView().fileContentView.getLayerForName("content")._viewer;if(!w()||G instanceof i){if(G instanceof i){A.getLayerForName("annotationButton").$el.hide()}o.teardownPanel();return}var M=h(".cp-toolbar");var N=M.find("#cp-file-control-annotate");if(N.length===0&&(T.get("hasReplyPermission")||T.get("hasReplyPermission")===undefined)){N=h(k.get("Annotation.fileControlAnnotate")());h.fn.tooltip&&N.tooltip({gravity:"s"});N.appendTo(M);M.css("margin-left",-M.width()/2)}T.trigger("cp.control-added",{plugin:"annotation"});G=j.extend(G,g);if(!n&&!h(".cp-annotatable .cp-active-annotation").length){G.renderAnnotations&&G.renderAnnotations(f);n=true}var S=A.getLayerForName("moreButton");var B=T.get("annotations");v(S,B);B.on("sync change:resolved filterUpdated",j.partial(v,S,B));B.fetchComments().done(function(){if(s.getView().fileSidebarView.isPanelInitialized("annotations")){B.getCurrentOrNext()}});var O=G.annotationOptions.dropTarget;var F=G.annotationOptions.annotationCreated;var D=function(Y,ab){ab.helper.addClass("active");var Z=h(this);var X=Z.offset();var ae=Y.pageX-X.left;var ac=Y.pageY-X.top;var ad=ae/Z.width();var aa=ac/Z.height();var V;if(F){V=F(this,Y)}V=j.extend({},V,{x:ad,y:aa});var W=(V.x*100)+"%";var U=(V.y*100)+"%";Z.closest(O).append(ab.helper.detach());ab.helper.css({left:W,top:U});s._fileState.trigger("cp.showAnnotations");s.getView().$el.find("#cp-file-control-annotate,#cp-control-panel-annotations").draggable("option","disabled",true);o.getInitializedPanel("annotations").addAnnotation(V)};var L=s.getView().$el.find("#cp-file-control-annotate");var I=L.draggable({appendTo:s.getView().el,helper:function(){return h("<div class='annotation-pin'></div>")},cursor:"-webkit-grabbing",cursorAt:{left:0,top:0},scroll:false,stack:"img",revert:"invalid",start:function(){u=true;G.autoToggleControls(false);G.hideControls();h(O).droppable({tolerance:"pointer",drop:D})},stop:function(){u=false;G.showControls();G.autoToggleControls(true);h(O).droppable("destroy")}});var J=I.data("draggable");if(J&&J._mouseUp&&J._mouseMove&&J._trigger&&J._clear){var E;var H=function(U){if(!u&&!J.options.disabled){J._mouseStart.call(J,U);u=true;E=U;C()}};var R=function(U){if(h(U.target).is(N)){return}if(u&&!J.options.disabled){J._mouseDownEvent=E;J._mouseUp.call(J,U);u=false;K()}};var Q=function(U){if(u&&!J.options.disabled){J._mouseStarted=true;J._mouseMove.call(J,U)}};var P=function(U){if(u&&!J.options.disabled&&U.keyCode===27){J._trigger("stop",U);J._clear()}};var C=function(){h(document).on("mousemove",Q);h(O).on("click",R);h(document).on("click",R);h(document).on("keyup",P)};var K=function(){h(document).off("mousemove",Q);h(O).off("click",R);h(document).off("click",R);h(document).off("keyup",P)};N.click(H)}};var t=function(C){var D=h(".cp-toolbar");var F=D.find("#cp-file-control-annotate");var E=h(".annotationLayer");var B=h(".cp-active-annotation");if(s.isInMode("PRESENTATION")){F.hide();E.hide();B.hide()}else{m(C);F.show();E.show();B.show()}};s.on("fv.showFile",function(B){n=false;t(B)});s.on("fv.changeMode",function(){t(s.getCurrentFile())})};a.showAnnotationsPanel=function(n){var m=n.getView().fileSidebarView;if(!m.isPanelInitialized("annotations")){if(m.isAnyPanelInitialized()){m.teardownPanel()}m.initializePanel("annotations")}};return a});(function(){var b=require("FileViewer");var a=require("cp/component/annotation/annotation-plugin");b.registerPlugin("annotation",a)}());
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-previews:upload-plugin', location = '/js/amd/plupload-amd.js' */
define("plupload",function(){return plupload});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-previews:upload-plugin', location = '/js/service/upload-service.js' */
define("cp/service/upload-service",["ajs","dragndrop-support","confluence","jquery","plupload","cp/service/files-service"],function(k,i,m,e,h,a){var b="application/x-upload-data";var c=m.getContextPath();var g=k.Meta.get("drag-and-drop-entity-id"),l=k.Meta.get("atl-token"),j=k.Meta.get("global-settings-attachment-max-size");function d(n){this.previewingAttachment=n;this.filesService=new a(n.get("ownerId"))}d.prototype.getMetaMaxSize=function(){return j};d.prototype.getUploadUrl=function(){return c+"/plugins/drag-and-drop/upload.action"};d.prototype.buildUploadParams=function(n){var o={},p=n.name.split(".").pop();o.pageId=this.previewingAttachment.get("ownerId");o.filename=this.previewingAttachment.get("title");o.size=n.size;if(g){o.dragAndDropEntityId=g}o.mimeType=h.mimeTypes[p.toLowerCase()]||b;o.atl_token=l;o.withEditorPlaceholder=false;return o};d.prototype.parseResponse=function(n){return e.parseJSON(n).data};d.prototype.handleError=function(p){var q="";if(p.response){try{var o=e.parseJSON(p.response);q=o.actionErrors[0]}catch(r){q=p.message}}else{q=p.message;if(p.code===h.FILE_SIZE_ERROR){var s=p.file.name;var n=k.DragAndDropUtils.niceSize(j).toString();q=k.format("{0} is too big to upload. Files must be less than {1}.",s,n)}else{if(p.code===h.FILE_EXTENSION_ERROR){q="You can only upload a file of the same type"}}}return q};d.prototype.promiseFileModel=function(o){var n=(this.previewingAttachment.getLatestVersion?this.previewingAttachment.getLatestVersion():this.previewingAttachment).get("id");return this.filesService.getFileWithId(n)};d.prototype.addVersionChangeComment=function(t,r,n,p){var s=r.get("id");var o=c+"/rest/api/content/"+r.get("ownerId")+"/child/attachment/"+s;var q={id:s,version:{number:r.get("version")+1},metadata:{comment:t}};e.ajax({url:o,type:"PUT",data:JSON.stringify(q),dataType:"json",contentType:"application/json; charset=utf-8"}).done(n).fail(function(u){p(JSON.parse(u.responseText).message)})};function f(n){d.apply(this,arguments)}f.prototype=Object.create(d.prototype);f.prototype.getUploadUrl=function(){return c+"/pages/attachfile.action"};f.prototype.buildUploadParams=function(n){var o={};o.atl_token=l;o.contentId=k.Data.get("content-id");o.responseFormat="html";o.fileName_0=this.previewingAttachment.get("title");return o};return i&&i.hasXhrSupport?d:f});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-previews:upload-plugin', location = 'js/component/upload/upload-button-view.js' */
define("cp/component/upload/upload-button-view",["jquery","backbone","FileViewer","ajs","dragndrop-support","cp/component/upload/upload-utils"],function(g,h,f,c,a,b){var e=f.require("template-store-singleton");var d=h.View.extend({tagName:"span",events:{click:"_onClick"},initialize:function(j){this._fileViewer=j.fileViewer;this._supportHtml5Upload=a&&a.hasXhrSupport;var i=this._fileViewer.getView().fileControlsView;this.listenTo(i,"renderLayers",this._initUploader)},render:function(){var i=this._fileViewer.getCurrentFile();if(!i){return this}if(i.get("hasUploadAttachmentVersionPermission")){this.$el.html(e.get("controlUploadButton")({isSupportHtml5Upload:this._supportHtml5Upload}));if(g.fn.tooltip){this.$("a").tooltip({gravity:"n"})}}else{this.stopListening().listenTo(i,"change:hasUploadAttachmentVersionPermission",this._onUploadNewVersionPermissionChanged)}return this},teardown:function(){this.stopListening();this._killExistingUploader()},_onClick:function(){c.trigger("analyticsEvent",{name:"confluence-spaces.previews.upload.click"})},_onUploadNewVersionPermissionChanged:function(i){if(i.get("hasUploadAttachmentVersionPermission")){this.render();this._initUploader()}},_initUploader:function(){var i=this._fileViewer.getCurrentFile();if(i&&i.get("hasUploadAttachmentVersionPermission")){this._killExistingUploader();this.uploader=b.createUploader(this._fileViewer,this.$("#cp-control-panel-upload")[0])}},_killExistingUploader:function(){if(this.uploader){this.uploader.off().destroy();this.uploader=null}}});return d});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-previews:upload-plugin', location = 'js/component/upload/attachment-uploader.js' */
define("cp/component/upload/attachment-uploader",["jquery","plupload","ajs","dragndrop-support"],function(f,d,c,b){var a=function(){this._workIdToBytesUploaded={};this._totalBytes=0};a.prototype={update:function(i,h,g){if(!(i in this._workIdToBytesUploaded)){this._totalBytes+=g}this._workIdToBytesUploaded[i]=h},percentComplete:function(){var g=0;f.each(this._workIdToBytesUploaded,function(h,i){g+=i});return Math.round(g*100/this._totalBytes)}};var e=function(j,v,o,r){var k=Backbone.Model.extend({initialize:function(){f(window).on("resize.attachmentUploader",function(){if(u){u.refresh()}})},cancelUpload:function(){i&&u&&u.removeFile(i);i=null},destroy:function(){f(window).off("resize.attachmentUploader");if(u){u.destroy()}}});var i=null,m=null,p=new k();var q=b&&b.hasXhrSupport,l=q?"html5":"html4",t=q?j:null,g=q?null:v;function n(){var x=new d.Uploader({runtimes:l,dragdrop:false,browse_button:t&&t.id,multipart:false,stop_propagation:true,max_file_size:parseInt(r.getMetaMaxSize(),10),inputFileClazz:"file-preview-input-file",filters:o?h(o.get("title")):null,multi_selection:false,container:g});var w=new s();x.init();x.bind("Started",w.handleStarted);x.bind("FilesAdded",w.handleFilesAdded);x.bind("BeforeUpload",w.handleBeforeUpload);x.bind("UploadProgress",w.handleUploadProgress);x.bind("FileUploaded",w.handleFileUploaded);x.bind("Error",w.handleError);x.bind("UploadComplete",w.handleUploadComplete);return x}function h(w){var z=[];var y=(w.indexOf(".")!==-1)?w.split(".").pop():null;if(y){var A=d.mimeTypes[y.toLowerCase()];var x=(A)?d.mineTypeToExtensionsMap[A]:[y];z.push({title:"filter",extensions:x.join(",")})}return z}function s(){}s.prototype.handleStarted=function(){p.trigger("cp.uploader.uploadStarted")};s.prototype.handleFilesAdded=function(w,x){p.trigger("cp.uploader.filesAdded",x[0]);w.start()};s.prototype.handleBeforeUpload=function(w,y){m=new a();i=y;var x=r.getUploadUrl(),z=r.buildUploadParams(y);w.settings.url=d.buildUrl(x,z)};s.prototype.handleUploadProgress=function(w,x){m.update(x.id,x.loaded,x.size);var y=m.percentComplete()/100;p.trigger("cp.uploader.uploadProgress",y)};s.prototype.handleFileUploaded=function(x,y,w){if(x.getFile(y.id)){p.trigger("cp.uploader.fileUploaded",y,w)}};s.prototype.handleError=function(w,x){p.trigger("cp.uploader.error",r.handleError(x));i=null};s.prototype.handleUploadComplete=function(w,x){m=null;i=null};var u=n();return p};return e});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-previews:upload-plugin', location = '/js/component/upload/upload-new-version-dialog-view.js' */
define("cp/component/upload/upload-new-version-dialog-view",["jquery","backbone","underscore","ajs","confluence","FileViewer"],function(c,g,i,f,h,b){var j=b.require("template-store-singleton");var d=b.require("file");var a=1;var e=g.View.extend({id:"upload-new-version-dialog",tagName:"section",className:"aui-layer aui-dialog2 aui-dialog2-small",events:{"click .close-button":"_closeDialog","click .cancel-button":"_cancelDialog"},initialize:function(k){this._fileViewer=k.fileViewer;this.uploader=k.uploader;if(this.uploader){this.listenTo(this.uploader,"cp.uploader.filesAdded",this._handleFileAdded);this.listenTo(this.uploader,"cp.uploader.uploadProgress",this._handleUploadProgress);this.listenTo(this.uploader,"cp.uploader.fileUploaded",this._handleFileUploaded);this.listenTo(this.uploader,"cp.uploader.error",this._handleError)}this.uploadService=k.uploadService;this.$el.attr({role:"dialog","aria-hidden":"true","data-aui-remove-on-hide":"true","data-aui-modal":"true"})},render:function(){this.$el.html(j.get("dialogUploadNewVersion")());this._updateElements();this.bodyInlineCSSOverflowValue=c("body")[0].style.overflow;this.dialog=f.dialog2(this.$el).show();this._fileViewer.getView().lockNavigationKeys();return this},isVisible:function(){return this.$el.is(":visible")},_updateElements:function(){this.$header=this.$(".aui-dialog2-header-main");this.$progressBar=this.$(".aui-progress-indicator");this.$cancelButton=this.$(".cancel-button");this.$closeButton=this.$(".close-button");this.$fileNameDiv=this.$(".file-name");this.$fileNameText=this.$(".file-name-text");this.$icon=this.$(".aui-icon");this.$msg=this.$("#upload-new-version-error-msg");this.$comment=this.$("#version-comment");this.$spinner=this.$(".spinner")},_toggleCancelButton:function(k){this.$cancelButton.toggleClass("hidden",!k);this.$closeButton.toggleClass("hidden",k)},_toggleEnableButton:function(l,k){l.attr("aria-disabled",!k);l.prop("disabled",!k)},_closeDialog:function(){var k=this.$comment.val();if(k){if(k.length<=255){this._toggleEnableButton(this.$closeButton,false);this.$spinner.spin();this.uploadService.addVersionChangeComment(this.$comment.val(),this._fileViewer.getCurrentFile(),i.bind(this._kill,this),i.bind(this._handleError,this));f.trigger("analyticsEvent",{name:"confluence-spaces.previews.upload.submit-comment"})}else{var l="The comment is longer than 255 characters.";this._handleLongCommentError(l)}}else{this._kill()}},_cancelDialog:function(){this.uploader.cancelUpload();this._kill();f.trigger("analyticsEvent",{name:"confluence-spaces.previews.upload.cancel"})},_kill:function(){if(this.uploader){this.stopListening(this.uploader)}this.dialog.hide();c("body")[0].style.overflow=this.bodyInlineCSSOverflowValue;this._fileViewer.getView().unlockNavigationKeys()},_handleFileAdded:function(l){this.$fileNameText.text(l.name);this._showIcon(l);f.progressBars&&f.progressBars.setIndeterminate(this.$progressBar);var k=this._fileViewer.getCurrentFile();var m=k?k.get("title"):"";f.trigger("analyticsEvent",{name:"confluence-spaces.previews.upload.start",data:{uploadSameName:m===l.name}})},_handleUploadProgress:function(k){if(!k){return}if(k===a){this._toggleEnableButton(this.$cancelButton,false)}f.progressBars&&f.progressBars.update(this.$progressBar,k)},_handleFileUploaded:function(l,k){this.uploadService.promiseFileModel(k).done(i.bind(function(m){this._toggleCancelButton(false);this.$header.text("Your upload is complete");this._fileViewer._fileState.replaceCurrent(new d(m));this._fileViewer.showFile(this._fileViewer._fileState.getCurrent());this._fileViewer._fileState.set("isNewFileUploaded",true)},this))},_handleError:function(k){this.$msg.empty();f.messages.warning("#upload-new-version-error-msg",{body:j.get("uploadErrorMessage")({message:k}),closeable:false});this.$msg.removeClass("hidden");this.$fileNameDiv.hide();this.$progressBar.hide();this.$comment.val("");this.$comment.hide();this._toggleCancelButton(false);this._toggleEnableButton(this.$closeButton,true);this.$spinner.spinStop();this.$header.text("Your upload has failed");f.trigger("analyticsEvent",{name:"confluence-spaces.previews.upload.failed"})},_handleLongCommentError:function(k){this.$msg.empty();f.messages.warning("#upload-new-version-error-msg",{body:j.get("uploadErrorMessage")({message:k}),closeable:true});this.$msg.removeClass("hidden")},_showIcon:function(l){var m=l.nativeFile&&l.nativeFile.type;var k=f.Confluence.FileTypesUtils.getAUIIconFromMime(m);this.$icon.addClass(k)}});return e});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-previews:upload-plugin', location = 'js/component/upload/upload-utils.js' */
define("cp/component/upload/upload-utils",["underscore","backbone","cp/component/upload/upload-new-version-dialog-view","cp/component/upload/attachment-uploader","cp/service/upload-service"],function(b,f,d,c,a){var e=function(j,g){var i=new a(j.getCurrentFile());var h=new c(g,g,j.getCurrentFile(),i);h.on("cp.uploader.uploadStarted",function(){this.uploadNewVersionDialog=new d({uploader:h,uploadService:i,fileViewer:j});this.uploadNewVersionDialog.render()});return h};return{createUploader:e}});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-previews:upload-plugin', location = '/templates/upload.soy' */
// This file was automatically generated from upload.soy.
// Please don't edit this file by hand.

if (typeof FileViewer == 'undefined') { var FileViewer = {}; }
if (typeof FileViewer.Templates == 'undefined') { FileViewer.Templates = {}; }


FileViewer.Templates.controlUploadButton = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append((opt_data.isSupportHtml5Upload) ? '<a id="cp-control-panel-upload" href="#" title="' + soy.$$escapeHtml("Upload a new version") + '" class="cp-icon"></a>' : '<label id="cp-control-panel-upload" title="' + soy.$$escapeHtml("Upload a new version") + '" class="cp-icon"></label>');
  return opt_sb ? '' : output.toString();
};


FileViewer.Templates.dialogUploadNewVersion = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<header class="aui-dialog2-header upload-new-version-dialog-header"><h1 class="aui-dialog2-header-main">', soy.$$escapeHtml("Uploading a new version"), '</h1></header><!-- Main dialog content --><div class="aui-dialog2-content"><div class="file-name"><span class="aui-icon aui-icon-small">File</span><p class="file-name-text"></p></div><div class="aui-progress-indicator"><span class="aui-progress-indicator-value"></span></div><div id="upload-new-version-error-msg" class="hidden"></div><form action="#" class="aui"><textarea class="textarea" name="comment" id="version-comment" placeholder="', soy.$$escapeHtml("What did you change?"), '"></textarea></form><div class="dialog-actions"><span class="spinner"></span><button class="aui-button close-button hidden">', soy.$$escapeHtml("Done"), '</button><button class="aui-button cancel-button">', soy.$$escapeHtml("Cancel"), '</button></div></div>');
  return opt_sb ? '' : output.toString();
};


FileViewer.Templates.uploadErrorMessage = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<!-- upload error message --><p class="error-msg">', soy.$$escapeHtml(opt_data.message), '</p>');
  return opt_sb ? '' : output.toString();
};

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-previews:upload-plugin', location = 'js/component/upload/upload-plugin.js' */
define("cp/component/upload/upload-plugin",["underscore","FileViewer","cp/component/upload/upload-button-view"],function(b,c,a){var d=function(h){var e=h.getView().fileControlsView;var g=function(){h._fileState.get("isNewFileUploaded")&&document.location.reload(true)};var f=function(){var i=h.getCurrentFile();return !$("#insert-image-dialog").is(":visible")&&!i.get("isRemoteLink")};h.close=b.wrap(h.close,function(i){i.apply(h,Array.prototype.slice.call(arguments,1));g()});e.addLayerView("uploadButton",a,{predicate:f,weight:40})};return d});(function(){var a=require("FileViewer");var b=require("cp/component/upload/upload-plugin");a.registerPlugin("upload",b)}());
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-previews:version-navigation-plugin', location = 'templates/versions.soy' */
// This file was automatically generated from versions.soy.
// Please don't edit this file by hand.

if (typeof FileViewer == 'undefined') { var FileViewer = {}; }
if (typeof FileViewer.Templates == 'undefined') { FileViewer.Templates = {}; }
if (typeof FileViewer.Templates.Versions == 'undefined') { FileViewer.Templates.Versions = {}; }


FileViewer.Templates.Versions.versionTitle = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<span class="cp-title"><span class="', soy.$$escapeHtml(opt_data.iconClass), ' size-24 cp-file-icon"></span><span class="cp-file-title">', soy.$$escapeHtml(opt_data.title), '</span><span class="cp-version">v.', soy.$$escapeHtml(opt_data.version), ' ', (opt_data.isCurrent) ? '[' + soy.$$escapeHtml("Current") + ']' : '', '</span></span>');
  return opt_sb ? '' : output.toString();
};


FileViewer.Templates.Versions.versionHistory = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<ul class="versionFiles">');
  var versionList18 = opt_data.versions;
  var versionListLen18 = versionList18.length;
  for (var versionIndex18 = 0; versionIndex18 < versionListLen18; versionIndex18++) {
    var versionData18 = versionList18[versionIndex18];
    output.append('<li class="', (versionData18.version == opt_data.selectedVersion) ? 'current' : '', '" data-cid="', soy.$$escapeHtml(versionData18.id), '">', (versionData18.version == opt_data.selectedVersion) ? '<span class="title">' + soy.$$escapeHtml("Version") + ' ' + soy.$$escapeHtml(versionData18.version) + '</span>' : '<a class="title" href="#">' + soy.$$escapeHtml("Version") + ' ' + soy.$$escapeHtml(versionData18.version) + '</a>', (versionData18.message) ? '<p class="description">' + soy.$$escapeHtml(versionData18.message) + '</p>' : '', (versionData18.countComments > 0) ? '<span class="comment-count" title="' + soy.$$escapeHtml("comments") + '"><span class="counter">' + ((versionData18.countComments > 9) ? '9+' : soy.$$escapeHtml(versionData18.countComments)) + '</span></span>' : '', '</li>');
  }
  output.append('</ul>');
  return opt_sb ? '' : output.toString();
};


FileViewer.Templates.Versions.versionNavigationDialog = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<section class="versions-container"><div class="spinner-wrap" /></section>');
  return opt_sb ? '' : output.toString();
};


FileViewer.Templates.Versions.viewCurrentVersion = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<a class=\'view-latest-version\' href=\'#\'>', soy.$$escapeHtml("See the latest one"), '</a>');
  return opt_sb ? '' : output.toString();
};


FileViewer.Templates.Versions.reloadLatestVersion = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<a class=\'reload-latest-version\' href=\'#\'>', soy.$$escapeHtml("Reload"), '</a>');
  return opt_sb ? '' : output.toString();
};

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-previews:version-navigation-plugin', location = 'js/component/versions/version-file-enricher.js' */
define("cp/component/versions/version-file-enricher",["underscore","cp/component/versions/versions","cp/service/versions-service"],function(d,b,e){function c(g,f){if(g.getLatestVersion){return g}var h={getLatestVersion:function(){return this},isLatestVersion:function(){return true}};var i={getLatestVersion:function(){return f.getLatestVersion()},isLatestVersion:function(){return f.getLatestVersion()===this}};d.extend(g,f?i:h);g.set("versions",new b([],{versionsService:new e(),fileModel:g.getLatestVersion()}));return g}var a={enrich:c};return a});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-previews:version-navigation-plugin', location = 'js/component/versions/file-version.js' */
define("cp/component/versions/file-version",["backbone","cp/component/versions/version-file-enricher"],function(c,a){var b=c.Model.extend({initialize:function(d,e){this.versionsService=e.versionsService;this.fileModel=e.fileModel},toJSON:function(){var d=c.Model.prototype.toJSON.apply(this,arguments);d.cid=this.cid;return d},getFileVersion:function(){if(+this.get("version")===+this.fileModel.get("version")){return $.Deferred().resolve(this.fileModel)}return this.versionsService.getFileVersion(this.fileModel.get("ownerId"),this.fileModel.get("id"),this.get("version")).pipe(function(d){var e=this.fileModel.clone();e.set(_.omit(d,"id"));return a.enrich(e,this)}.bind(this))},getLatestVersion:function(){return this.fileModel}});return b});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-previews:version-navigation-plugin', location = 'js/component/versions/version-message-view.js' */
define("cp/component/versions/version-message-view",["backbone","ajs","FileViewer"],function(f,b,e){var d=e.require("template-store-singleton");var a=e.require("file");var c=f.View.extend({events:{"click a.view-latest-version":"_onViewLatest","click a.reload-latest-version":"_onReloadLatest","click span.icon-close":"_onCloseWarning"},initialize:function(g){this._fileViewer=g.fileViewer;this._filesService=this._fileViewer.getConfig().filesService;this.$el.attr("id","cp-version-message")},render:function(){var g=this._fileViewer.getCurrentFile();if(g.getLatestVersion().get("stale")){this.$el.html(b.messages.generic({title:"New file version uploaded.",body:d.get("Versions.reloadLatestVersion")(),closeable:false})).show()}else{if(!g.isLatestVersion()){this.$el.html(b.messages.generic({title:"This is an older version of this file.",body:d.get("Versions.viewCurrentVersion")(),closeable:true})).show()}}return this},teardown:function(){this.$el.hide()},_onViewLatest:function(){var g=this._fileViewer.getCurrentFile();this._fileViewer.showFile(g.getLatestVersion());b.trigger("analyticsEvent",{name:" confluence-spaces.previews.versions.warning-view-latest"})},_onReloadLatest:function(){var h=this._fileViewer.getCurrentFile();var g=new this._filesService(h.get("ownerId"));g.getFileWithId(h.getLatestVersion().get("id")).done(function(i){i=new a(i);this._fileViewer._fileState.replaceCurrent(i);this._fileViewer._fileState.set("isNewFileUploaded",true);this._fileViewer.showFile(i)}.bind(this));b.trigger("analyticsEvent",{name:" confluence-spaces.previews.versions.warning-reload-latest"})},_onCloseWarning:function(){b.trigger("analyticsEvent",{name:"confluence-spaces.previews.versions.close-warning"})}});return c});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-previews:version-navigation-plugin', location = 'js/component/versions/version-navigation-dialog-view.js' */
define("cp/component/versions/version-navigation-dialog-view",["ajs","backbone","jquery","underscore","FileViewer","cp/component/versions/file-version","cp/component/versions/versions"],function(e,f,c,g,b,a,h){var i=b.require("template-store-singleton");var d=f.View.extend({dialogId:"cp-dialog-version",events:{"click .versionFiles li:not(.current)":"_onClickFileVersion"},initialize:function(j){if(j){this._fileViewer=j.fileViewer;this.$btnTrigger=j.$btnTrigger;this._file=j.fileViewer.getCurrentFile()}this.dialog=e.InlineDialog(this.$btnTrigger.find("span.cp-file-icon"),this.dialogId,function(l,k,m){l.append(this.$el.detach());this.render();m()}.bind(this),{hideDelay:null,offsetY:0,noBind:true,hideCallback:function(){this.$btnTrigger.removeClass("active")}.bind(this)});this._fileViewer.once("fv.close",this.teardown.bind(this));this.$btnTrigger.on("click.versionnav",function(){if(this.$el.is(":visible")){this.dialog.hide();e.trigger("analyticsEvent",{name:"confluence-spaces.previews.versions.click-title-to-close"})}else{this.dialog.show();this.$btnTrigger.addClass("active")}}.bind(this))},teardown:function(){this.$btnTrigger.off("click.versionnav");this.dialog.hide();c("#inline-dialog-cp-dialog-version").remove()},render:function(){this.$el.html(i.get("Versions.versionNavigationDialog")());this.$(".spinner-wrap").spin("medium",{top:0,left:0});var j=this._file.getLatestVersion();this._file.get("versions").fetchVersions(true).done(function(k){if(+k[0].version>+j.get("version")){this._file.getLatestVersion().set("stale",true);this._fileViewer.getView().fileContentView.getLayerForName("version-message").render();k=g.filter(k,function(l){return l.version<=j.get("version")})}this.$(".versions-container").html(i.get("Versions.versionHistory")({versions:new f.Collection(k).toJSON(),selectedVersion:this._fileViewer.getCurrentFile().get("version")}))}.bind(this)).fail(function(){this.$(".versions-container").html(e.messages.warning({title:"Can\'t show history",body:"We can\'t show the history right now. Give it another try later.",closeable:false}))}.bind(this));e.trigger("analyticsEvent",{name:"confluence-spaces.previews.versions.open",data:{fileType:this._file.get("type")}});return this},_onClickFileVersion:function(m){m.preventDefault();var j=this._file.get("versions").get(c(m.currentTarget).attr("data-cid"));j.getFileVersion().done(function(n){this._fileViewer.showFile(n)}.bind(this));var k=j.get("version");var l=this._file.getLatestVersion().get("version");this._triggerClickFileVersionAnalyticsEvent(k,l)},_triggerClickFileVersionAnalyticsEvent:function(k,m){var j="confluence-spaces.previews.versions.view-previous";var l=m-k;if(l>=4){j+="4-and-older"}else{if(l>0){j+=l}}if(l>0){e.trigger("analyticsEvent",{name:j})}}});return d});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-previews:version-navigation-plugin', location = 'js/component/versions/version-title-view.js' */
define("cp/component/versions/version-title-view",["backbone","FileViewer","cp/component/versions/version-navigation-dialog-view"],function(f,e,b){var d=e.require("template-store-singleton");var c=e.require("icon-utils");var a=f.View.extend({initialize:function(g){this._fileViewer=g.fileViewer;this.options=g},render:function(){var g=this._fileViewer.getCurrentFile();if(!g){return this}if(g.get("version")&&g.get("id")){this.$el.html(d.get("Versions.versionTitle")({title:g.get("title"),version:g.get("version"),iconClass:c.getCssClass(g.get("type")),isCurrent:g.isLatestVersion()}));this.versionsNavigationDialog=new b({$btnTrigger:this.$(".cp-title"),fileViewer:this._fileViewer})}else{this.$el.html(d.get("titleContainer")({title:g.get("title"),iconClass:c.getCssClass(g.get("type"))}))}return this},teardown:function(){if(this.versionsNavigationDialog){this.versionsNavigationDialog.teardown();this.versionsNavigationDialog=undefined}}});return a});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-previews:version-navigation-plugin', location = 'js/component/versions/versions.js' */
define("cp/component/versions/versions",["backbone"],function(b){var a=b.Collection.extend({model:function(d,c){var e=require("cp/component/versions/file-version");return new e(d,{versionsService:c.collection.service,fileModel:c.collection.latestVersion})},initialize:function(c,d){this.service=d.versionsService;this.latestVersion=d.fileModel},sync:function(e,d){if(!this.service){return}if(e==="read"){var c=this.service.getAllFileVersions(this.latestVersion.get("id"),this.latestVersion.get("ownerId"));c&&c.done(function(f){d.reset(f,{silent:true});d.trigger("sync",d)});return c}},fetchVersions:function(c){if(this.size()===0||c){return this.fetch()}else{return $.when()}}});return a});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-previews:version-navigation-plugin', location = 'js/component/versions/versions-navigation-plugin.js' */
define("cp/component/versions/versions-navigation-plugin",["underscore","FileViewer","cp/component/versions/version-title-view","cp/component/versions/version-file-enricher","cp/component/versions/version-message-view","cp/component/versions/versions"],function(e,g,d,a,f,b){var c=function(i){if(!i.getConfig().enableVersionNavigation){return}var h=i.getView().fileTitleView;h.addPanelView("version-title",d);i.getView().on("fv.fileChange",a.enrich);i.getView().fileContentView.addLayerView("version-message",f)};c.showFileForPreviousVersion=function(k,i,h){var j=a.enrich(i);return j.get("versions").fetchVersions().pipe(function(){var l=i.get("versions").findWhere({version:+h});if(!l){return $.when(i)}return l.getFileVersion()}).pipe(function(l){return k.showFile(l)})};return c});(function(){if(AJS.DarkFeatures.isEnabled("previews.versions")){var b=require("FileViewer");var a=require("cp/component/versions/versions-navigation-plugin");b.registerPlugin("versionNavigation",a)}}());
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-previews:permalink-plugin', location = '/js/component/permalink/file-router.js' */
define("cp/component/permalink/file-router",["jquery","backbone","confluence/jsUri","cp/component/versions/versions-navigation-plugin"],function(d,j,c,k){var f=window.encodeURIComponent;var a=window.decodeURIComponent;var i=AJS.DarkFeatures.isEnabled("previews.sharing.pushstate")&&history.pushState;var e=function(l){return l.path()+l.query()+(l.anchor()?"#"+l.anchor():"")};var h=function(q,r){if(!q){return b()}var v=q.get("ownerId");var p;if(q.isLatestVersion&&!q.isLatestVersion()){p=q.getLatestVersion().get("id")}else{p=q.get("id")}var u=q.get("version");var t=r&&r.get("id");var m=q.get("src");var n=q.get("name");var l;if(!r){l=v?(v+"/"+p):f(m)}else{l=v+"/"+p+"/"+u+"/"+t}var w=n?("/"+f(n)):"";if(i){var s="/"+l+w;var o=new c(window.location.href);o=o.replaceQueryParam("preview",s);return e(o)}else{return"#!/preview/"+l+w}};var b=function(){if(i){var l=new c(window.location.href).deleteQueryParam("preview");return e(l)}else{return""}};var g=j.Router.extend({routes:{"!/preview/:ownerId/:id(/:name)":"handleViewer","!/preview/:ownerId/:id/:version/:commentId(/:replyId)(/:name)":"handleLinkForPin","!/preview/*src":"handleWebLink","":"handleCloseViewer","*path":"handleUrl"},initialize:function(l){if(j.History.started){return}this._enabled=true;this._fileViewer=l.fileViewer;this.on("route:handleViewer",function(n,o){this.selectFileById(n,o)});this.on("route:handleLinkForPin",function(o,u,p,r,n){var t=this;var q=this._fileViewer.getCurrentFile();var s=function(v,w){var x=v.get("annotations");if(x){t._fileViewer._fileState.trigger("cp.showAnnotations");if(w){t.listenToOnce(x,w,function(){x.selectCommentWithId(r,n)})}else{x.selectCommentWithId(r,n)}}};if(this._fileViewer.isOpen()&&q&&q.get("ownerId")===o&&q.get("id")===u&&q.get("version")==p){s(q)}else{this.selectFileById(o,u,p).done(function(v){s(v,"sync")})}});this.on("route:handleWebLink",function(n){this.disableListeners();if(!this._fileViewer.isOpen()){this._fileViewer.open()}this._fileViewer.showFileWithSrc(n);this.enableListeners()});var m=function(){if(!i){return}var n=new c(window.location.href);if(n.getQueryParamValue("preview")){d(window).off("popstate",m);if(!this._fileViewer||!this._fileViewer.getCurrentFile()){j.history.loadUrl("!/preview"+a(n.getQueryParamValue("preview")))}}else{l.fileViewer.close();d(window).off("popstate",m);d(window).on("popstate",m)}}.bind(this);this.on("route:handleUrl",m);this.on("route:handleCloseViewer",function(){this._fileViewer.close()});this.enableListeners()},start:function(){if(!j.History.started){j.history.start({pushState:i})}},setEnabled:function(l){this._enabled=l},selectFileById:function(l,p,n){this.disableListeners();if(!this._fileViewer.isOpen()){this._fileViewer.open()}var o=this._fileViewer._fileState.collection.findWhere({id:p,ownerId:l});if(o){this._fileViewer._fileState.setCurrentWithCID(o.cid)}else{this._fileViewer._fileState.setNoCurrent()}var m;if(!n||!o||n==o.get("version")){m=this._fileViewer.showFile(o)}else{m=k.showFileForPreviousVersion(this._fileViewer,o,n)}this.enableListeners();return m},enableListeners:function(){this.listenTo(this._fileViewer,"fv.changeFile fv.close",this._setRoute);this.listenTo(this._fileViewer.getView().fileSidebarView,"initializePanel",this._setRouteOnSidebarOpen);this.listenTo(this._fileViewer.getView().fileSidebarView,"teardownPanel",this._setRouteOnSidebarClose)},disableListeners:function(){this.stopListening(this._fileViewer,"fv.changeFile fv.close",this._setRoute);this.stopListening(this._fileViewer.getView().fileSidebarView,"initializePanel",this._setRouteOnSidebarOpen);this.stopListening(this._fileViewer.getView().fileSidebarView,"teardownPanel",this._setRouteOnSidebarClose)},_setRoute:function(o,l,n){if(this._enabled){var m=h(o,l);this.navigate(m,{trigger:!m||(i&&!new c(m).getQueryParamValue("preview")),replace:!!l||n||(o&&o.isLatestVersion&&!o.isLatestVersion())})}},_setRouteOnSidebarOpen:function(n){if("annotations"===n){var m=this._fileViewer.getCurrentFile();var l=m.get("annotations").getCurrent();l&&this._setRoute(m,l)}},_setRouteOnSidebarClose:function(l){if("annotations"===l){this._setRoute(this._fileViewer.getCurrentFile(),null,true)}}});return g});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-previews:permalink-plugin', location = '/js/component/permalink/permalink-plugin.js' */
define("cp/component/permalink/permalink-plugin",["FileViewer","cp/component/permalink/file-router"],function(b,d){var a;var c=function(e){if(!e.getConfig().enablePermalinks){return}a=new d({fileViewer:e})};c.setRoutingEnabled=function(e){if(a){a.setEnabled(e)}};c.startRouting=function(){a.start()};c.setRouteForPin=function(f,e){if(a){a._setRoute(f,e)}};return c});(function(){var a=require("FileViewer");var b=require("cp/component/permalink/permalink-plugin");a.registerPlugin("permalink",b)}());
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-previews:share-plugin', location = '/templates/share-button.soy' */
// This file was automatically generated from share-button.soy.
// Please don't edit this file by hand.

if (typeof FileViewer == 'undefined') { var FileViewer = {}; }
if (typeof FileViewer.Templates == 'undefined') { FileViewer.Templates = {}; }


FileViewer.Templates.controlShareButton = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<a id="cp-control-panel-share" href="#" title="', soy.$$escapeHtml("Share"), '" class="cp-icon"></a>');
  return opt_sb ? '' : output.toString();
};


FileViewer.Templates.sharePreviewPopup = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<form action="#" method="post" class="aui share-content-popup"><div class="field-group"><div class="autocomplete-user-target"><input class="text autocomplete-sharepage" id="users" data-max="10" data-dropdown-target=".autocomplete-user-target" data-none-message="', soy.$$escapeHtml("No matches"), '" placeholder="', soy.$$escapeHtml("User name, group or email"), '"/></div><ol class="recipients"></ol></div><div class="field-group"><textarea class="textarea" id="note" placeholder="', soy.$$escapeHtml("Add an optional note"), '"/></div><div class="field-group button-panel"><div class="progress-messages-icon"></div><div class="progress-messages"></div><input class="button submit" type="submit" value="', soy.$$escapeHtml("Share"), '" disabled/><a class="close-dialog" href="#">', soy.$$escapeHtml("Cancel"), '</a></div></form>');
  return opt_sb ? '' : output.toString();
};


FileViewer.Templates.recipientUser = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<li data-userkey="', soy.$$escapeHtml(opt_data.userKey), '" style="display: none" class="recipient-user"><img src="', soy.$$escapeHtml(opt_data.thumbnailLink.href), '" title="', soy.$$escapeHtml(opt_data.title), '"/><span class="title" title="', soy.$$escapeHtml(opt_data.title), '">', soy.$$escapeHtml(opt_data.title), '</span><span class="remove-recipient"/></li>');
  return opt_sb ? '' : output.toString();
};


FileViewer.Templates.recipientEmail = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<li data-email="', soy.$$escapeHtml(opt_data.email), '" style="display: none" class="recipient-email"><img src="', soy.$$escapeHtml(opt_data.icon), '" title="', soy.$$escapeHtml(opt_data.email), '"/><span class="title" title="', soy.$$escapeHtml(opt_data.email), '">', soy.$$escapeHtml(opt_data.email), '</span><span class="remove-recipient"/></li>');
  return opt_sb ? '' : output.toString();
};


FileViewer.Templates.recipientGroup = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<li data-group="', soy.$$escapeHtml(opt_data.title), '" style="display: none" class="recipient-group"><span><img src="', soy.$$escapeHtml(opt_data.thumbnailLink.href), '" title="', soy.$$escapeHtml(opt_data.title), '"/><span>', soy.$$escapeHtml(opt_data.title), '</span><span class="remove-recipient"/></span></li>');
  return opt_sb ? '' : output.toString();
};

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-previews:share-plugin', location = '/js/component/share-button/share-button-plugin.js' */
define("cp/component/share-button/share-button-plugin",["jquery","ajs","backbone","FileViewer"],function(f,h,i,b){var j=b.require("template-store-singleton");var a={};a.autocompleteUser=function(n){n=n||document.body;var o=h.$,k=/^([a-zA-Z0-9_\.\-\+\!#\$%&'\*/=\?\^_`{|}~])+\@.*/;var m=function(s){if(!s||!s.result){throw new Error("Invalid JSON format")}var p=[];for(var q=0;q<s.result.length;q++){var r=s.result[q];if(r.type=="group"){r=l(r)}}p.push(s.result);return p};function l(p){if(p.name=="confluence-users"||p.name=="confluence-administrators"){return p}p.title=p.name;p.group=p.name;p.thumbnailLink={href:Confluence.getContextPath()+"/download/resources/com.atlassian.confluence.plugins.share-page:mail-page-resources/images/group.png",type:"image/png",rel:"thumbnail"};p.link=[{href:Confluence.getContextPath(),rel:"self"}];return p}o("input.autocomplete-sharepage[data-autocomplete-user-bound!=true]",n).each(function(){var r=o(this).attr("data-autocomplete-sharepage-bound","true").attr("autocomplete","off");var q=r.attr("data-max")||10,t=r.attr("data-alignment")||"left",s=r.attr("data-dropdown-target"),p=null;if(s){p=o(s)}else{p=o("<div></div>");r.after(p)}p.addClass("aui-dd-parent autocomplete");r.quicksearch(h.REST.getBaseUrl()+"search/user-or-group.json",function(){r.trigger("open.autocomplete-sharepage")},{makeParams:function(u){return{"max-results":q,query:u.replace("{|}","")}},dropdownPlacement:function(u){p.append(u)},makeRestMatrixFromData:m,addDropdownData:function(v){var u=o.trim(r.val());if(k.test(u)){v.push([{name:u,email:u,href:"#",icon:Confluence.getContextPath()+"/download/resources/com.atlassian.confluence.plugins.share-page:mail-page-resources/images/envelope.png"}])}if(!v.length){var w=r.attr("data-none-message");if(w){v.push([{name:w,className:"no-results",href:"#"}])}}return v},ajsDropDownOptions:{alignment:t,displayHandler:function(u){if(u.restObj&&u.restObj.username){return u.name+" ("+u.restObj.username+")"}return u.name},selectionHandler:function(w,v){if(v.find(".search-for").length){r.trigger("selected.autocomplete-sharepage",{searchFor:r.val()});return}if(v.find(".no-results").length){this.hide();w.preventDefault();return}var u=o("span:eq(0)",v).data("properties");if(!u.email){u=u.restObj}r.trigger("selected.autocomplete-sharepage",{content:u});this.hide();w.preventDefault()}}})})};var c={width:250,hideDelay:3600000,calculatePositions:function(l,s,A,w){var t;var C;var y;var p=-7;var q;var u;var B=s.target.offset();var k=s.target.outerWidth();var n=B.left+k/2;var x=(window.pageYOffset||document.documentElement.scrollTop)+f(window).height();var o=10;y=B.top+s.target.outerHeight()+w.offsetY;t=B.left+w.offsetX;var r=B.top>l.height();var m=(y+l.height())<x;u=(!m&&r)||(w.onTop&&r);var v=f(window).width()-(t+w.width+o);if(u){y=B.top-l.height()-8;var z=w.displayShadow?(h.$.browser.msie?10:9):0;p=l.height()-z}q=n-t+w.arrowOffsetX;if(w.isRelativeToMouse){if(v<0){C=o;t="auto";q=A.x-(f(window).width()-w.width)}else{t=A.x-20;C="auto";q=A.x-t}}else{if(v<0){C=o;t="auto";q=n-(f(window).width()-l.outerWidth())+o}else{if(w.width<=k/2){q=w.width/2;t=n-w.width/2}}}return{displayAbove:u,popupCss:{left:t,right:C,top:y},arrowCss:{position:"absolute",left:q,right:"auto",top:p}}}};var d=function(p,l,o){var n=function(){var s=a.identifier;var t=s+".inline-dialog-check";f("body").unbind("mousedown."+t)};var q=function(s){this._fileViewer.getView().unlockNavigationKeys();a.current.hide();n();if(s){setTimeout(function(){p.empty()},300)}return false}.bind(this);var m=function(){var s=a.identifier;var t=s+".inline-dialog-check";f("body").bind("mousedown."+t,function(v){var u=f(v.target);if(u.closest("#inline-dialog-"+s+" .contents").length===0){q()}})};if(p.find("input").length){o();m();return}p.append(j.get("sharePreviewPopup")());a.autocompleteUser();f(document).on("keydown.shareDialogEscape",function(s){if(s.keyCode==27){s.preventDefault();s.stopPropagation();f(document).off("keydown.shareDialogEscape");return false}return true});p.find(".close-dialog").click(function(s){s.preventDefault();q(true)});p.find("form").submit(function(x){x.preventDefault();var v=f(this).closest(".aui-inline-dialog");var z=[],y=[],s=[];v.find(".recipients li").each(function(C,D){var A=f(D).attr("data-userKey");var B=f(D).attr("data-email");var E=f(D).attr("data-group");if(A){z.push(A)}if(B){y.push(B)}if(E){s.push(E)}});if(z.length<=0&&y.length<=0&&s.length<=0){return false}f("button, input, textarea",this).attr("disabled","disabled");v.find(".progress-messages-icon").removeClass("error");v.find(".progress-messages").text("Sending");v.find(".progress-messages").attr("title","Sending");var u=new Spinner({length:3,width:1,radius:3,color:"#666",className:"cp-share-dialog-spinner"}).spin();v.find(".progress-messages-icon").append(u.el);v.find(".progress-messages-icon").css("position","absolute").css("left","0").css("margin-top","3px");v.find(".progress-messages").css("padding-left",20);var t=v.find("#note");var w={users:z,emails:y,groups:s,note:t.hasClass("placeholded")?"":t.val(),entityId:a.attachmentId,contextualPageId:h.Data.get("content-id"),entityType:"attachment"};f.ajax({type:"POST",contentType:"application/json; charset=utf-8",url:Confluence.getContextPath()+"/rest/share-page/latest/share",data:JSON.stringify(w),dataType:"text",success:function(){setTimeout(function(){u.stop();v.find(".progress-messages-icon").addClass("done");v.find(".progress-messages").text("Sent");v.find(".progress-messages").attr("title","Sent");setTimeout(function(){v.find(".progress-messages").text("");v.find(".progress-messages-icon").removeClass("done");v.find("#note").val("");v.find("#users").val("");v.find(".recipient-user").remove();v.find(".recipient-email").remove();v.find(".recipient-group").remove();f("button,input,textarea",v).removeAttr("disabled");q()},1000)},500)},error:function(B,A){u.stop();v.find(".progress-messages-icon").addClass("error");v.find(".progress-messages").text("Error sending");v.find(".progress-messages").attr("title","Error sending"+": "+A);f("button,input,textarea",v).removeAttr("disabled")}});return false});var r=p.find("#users");var k=p.find("input.submit");r.bind("selected.autocomplete-sharepage",function(v,u){var w=function(z,y,A){var C=p.find(".recipients"),B,x;B="li[data-"+z+'="'+A[z]+'"]';if(C.find(B).length>0){C.find(B).hide()}else{C.append(y)}x=C.find(B);x.find(".remove-recipient").click(function(){x.remove();if(C.find("li").length==0){k.attr("disabled","true")}a.current.refresh();r.focus();return false});x.fadeIn(200)};var t,s;if(u.content.email){t="email";s=j.get("recipientEmail")(u.content)}else{if(u.content.type=="group"){t="group";s=j.get("recipientGroup")(u.content)}else{t="userKey";s=j.get("recipientUser")(u.content)}}w(t,s,u.content);a.current.refresh();k.removeAttr("disabled");r.val("");return false});r.bind("open.autocomplete-sharepage",function(t,s){if(f("a:not(.no-results)",h.dropDown.current.links).length>0){h.dropDown.current.moveDown()}});r.keypress(function(s){return s.keyCode!=13});f(document).bind("showLayer",function(u,t,s){if(t==="inlineDialog"&&s.popup===a.current){s.popup.find("#users").focus()}});f(l).parents().filter(function(){return this.scrollTop>0}).scrollTop(0);o();m()};var e=i.View.extend({events:{click:"displayShareDialog"},tagName:"span",initialize:function(k){this._fileViewer=k.fileViewer},teardown:function(){if(a.current){a.current.remove();a.current=null}},render:function(){this.$el.html(j.get("controlShareButton")());if(f.fn.tooltip){this.$("a").tooltip({gravity:"n"})}return this},displayShareDialog:function(){var l=c||{};l.hideCallback=function(){this._fileViewer.getView().unlockNavigationKeys()}.bind(this);var k="#cp-control-panel-share";this._fileViewer.getView().lockNavigationKeys();a.identifier="sharePreviewPopup";a.attachmentId=this._fileViewer.getCurrentFile().get("id");a.current=h.InlineDialog(k,a.identifier,d.bind(this),l);a.current.show();return}});var g=function(k){if(!k.getConfig().enableShareButton){return}k.getView().fileControlsView.addLayerView("shareButton",e,{weight:2,predicate:function(l){return !l.getCurrentFile().get("isRemoteLink")}})};return g});(function(){var b=require("FileViewer");var a=require("cp/component/share-button/share-button-plugin");b.registerPlugin("sharebutton",a)}());
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-previews:minimode-plugin', location = '/bower_components/atlassian-fileviewer/dist/fileviewer-minimode-templates.js' */
// This file was automatically generated from minimode.i18n.soy.
// Please don't edit this file by hand.

/**
 * @fileoverview Templates in namespace FileViewer.Templates.
 */

if (typeof FileViewer == 'undefined') { var FileViewer = {}; }
if (typeof FileViewer.Templates == 'undefined') { FileViewer.Templates = {}; }


FileViewer.Templates.minimodeBanner = function(opt_data, opt_ignored) {
  return '<div id="cp-info"><a href="#" id="cp-files-label" aria-label="' + soy.$$escapeHtml("Show all files") + '"><span class="cp-files-collapser up">' + soy.$$escapeHtml("Show all files") + '</span><span class="cp-files-collapser down hidden">' + soy.$$escapeHtml("Hide all files") + '</span>' + aui.icons.icon({useIconFont: true, size: 'small', icon: 'arrows-up', accessibilityText: "Show all files", extraClasses: 'cp-files-collapser up'}) + aui.icons.icon({useIconFont: true, size: 'small', icon: 'arrows-down', accessibilityText: "Hide all files", extraClasses: 'cp-files-collapser down hidden'}) + '</a></div>';
};
if (goog.DEBUG) {
  FileViewer.Templates.minimodeBanner.soyTemplateName = 'FileViewer.Templates.minimodeBanner';
}


FileViewer.Templates.minimode = function(opt_data, opt_ignored) {
  return '<ol id="cp-thumbnails"/>';
};
if (goog.DEBUG) {
  FileViewer.Templates.minimode.soyTemplateName = 'FileViewer.Templates.minimode';
}


FileViewer.Templates.thumbnail = function(opt_data, opt_ignored) {
  return '<figure role="group" class="cp-thumbnail-group"><div class="cp-thumbnail-img"><a href="#" class="cp-thumbnail-img-container size-48 ' + soy.$$escapeHtml(opt_data.iconClass) + ' has-thumbnail"><img src="' + soy.$$escapeHtml(opt_data.thumbnailSrc) + '" alt="' + soy.$$escapeHtml(AJS.format("View a larger version of {0}",opt_data.title)) + '" /></a></div><figcaption class="cp-thumbnail-title" aria-label="' + soy.$$escapeHtml(opt_data.title) + '">' + soy.$$escapeHtml(opt_data.title) + '</figcaption></figure>';
};
if (goog.DEBUG) {
  FileViewer.Templates.thumbnail.soyTemplateName = 'FileViewer.Templates.thumbnail';
}


FileViewer.Templates.placeholderThumbnail = function(opt_data, opt_ignored) {
  return '<figure role="group" class="cp-thumbnail-group"><div class="cp-thumbnail-img"><a href="#" class="cp-thumbnail-img-container size-48 ' + soy.$$escapeHtml(opt_data.iconClass) + '"></a></div><figcaption class="cp-thumbnail-title" aria-label="' + soy.$$escapeHtml(opt_data.title) + '">' + soy.$$escapeHtml(opt_data.title) + '</figcaption></figure>';
};
if (goog.DEBUG) {
  FileViewer.Templates.placeholderThumbnail.soyTemplateName = 'FileViewer.Templates.placeholderThumbnail';
}

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-previews:minimode-plugin', location = '/bower_components/atlassian-fileviewer/dist/fileviewer-minimode.js' */
(function (FileViewer) {
    'use strict';

    // use FileViewer's internal module system
    var define  = FileViewer.define;
    var require = FileViewer.require;

define("minimode/MinimodePanel",
    [
        "jquery",
        "ajs",
        "backbone",
        "minimode/ThumbnailView",
        "template-store-singleton"
    ],
    function(
        $,
        AJS,
        Backbone,
        FileThumbnailView,
        templateStore
    ) {
        "use strict";

        var FileMinimodeView = Backbone.View.extend({

            id: "cp-footer-minimode",

            initialize: function(options) {
                this.subviews = [];
                this._fileViewer = options.fileViewer;
                this._panelView = options.panelView;
                this.listenTo(this.collection, 'add reset', this.render);
                this.listenTo(this._panelView, 'renderPanel', this._forceChromeRepaint);
                this.listenTo(this._panelView, 'renderPanel', this.scrollToSelected);
                this.$minimode = $(templateStore.get('minimode')());
                this.$minimode.appendTo(this.$el);
            },

            closeOldSubviews: function() {
                while (this.subviews.length > 0) {
                    var view = this.subviews.pop();
                    view.remove();
                    view.unbind();
                }
            },

            render: function() {
                this.closeOldSubviews();

                this.collection.each(function(model) {
                    var view = new FileThumbnailView({
                        model: model,
                        fileViewer: this._fileViewer,
                        panelView: this._panelView
                    });
                    this.subviews.push(view);
                    $(view.render().el).appendTo(this.$minimode);
                }, this);

                return this;
            },

            scrollToSelected: function() {
                var file = this._fileViewer.getCurrentFile();
                this.subviews.forEach(function (view) {
                    if(view.model === file) {
                        var topPos = view.$el.get(0).offsetTop - 59;
                        if ((topPos) && this.$el.scrollTop !== topPos) {
                            this.$el.find("#cp-thumbnails").scrollTop(topPos);
                        }
                    }
                }.bind(this));
            },

            _forceChromeRepaint: function() {
                // Chrome doesn't respect the 100% height on images once the container is resized.
                var $img = $("#cp-img");
                if ($img.length) {
                    var $preview = $img.closest("#cp-image-preview"),
                        left = $preview.scrollLeft(),
                        top = $preview.scrollTop();
                    $img.css('display', 'none').height();
                    $img.css('display', 'inline-block');
                    $preview.scrollLeft(left);
                    $preview.scrollTop(top);
                }
            }

        });

        return FileMinimodeView;
    }
);
define('minimode/minimodePlugin', [
    'minimode/MinimodeToggle',
    'minimode/MinimodePanel'
], function (
    MinimodeToggle,
    MinimodePanel
) {
    'use strict';

    var minimodePlugin = function (fileViewer) {
        var fileView = fileViewer.getView();
        var sinkView = fileView.fileSinkView;
        var metaView = fileView.fileMetaView;

        if (!fileViewer.getConfig().enableMiniMode) {
            return;
        }

        metaView.addLayerView('minimodeToggle', MinimodeToggle, {
            predicate: MinimodeToggle.predicate
        });
        sinkView.addPanelView('minimode', MinimodePanel);
    };

    return minimodePlugin;
});
define('minimode/MinimodeToggle', [
    'backbone', 'template-store-singleton'
], function (Backbone, templateStore) {
    'use strict';

    var MinimodeToggle = Backbone.View.extend({

        events: {
            'click #cp-files-label': '_toggleMinimode'
        },

        initialize: function (options) {
            this._fileViewer = options.fileViewer;
            this._sinkView = this._fileViewer.getView().fileSinkView;
        },

        render: function () {
            this.$el.html(templateStore.get('minimodeBanner')());
            this._setShowAllFilesVisible();
            return this;
        },

        _toggleMinimode: function () {

            var analytics = this._fileViewer.analytics;

            if (this._sinkView.isPanelInitialized('minimode')) {
                this._sinkView.teardownPanel('minimode');
                analytics.send('files.fileviewer-web.minimode.closed');
            } else {
                this._sinkView.initializePanel('minimode');
                analytics.send('files.fileviewer-web.minimode.opened');
            }

            this._setShowAllFilesVisible();
        },

        _setShowAllFilesVisible: function () {
            var visible = this._sinkView.isPanelInitialized('minimode');
            this.$('.cp-files-collapser.up').toggleClass('hidden', visible);
            this.$('.cp-files-collapser.down').toggleClass('hidden', !visible);
        }

    }, {

        predicate: function (fileViewer) {
            return fileViewer._fileState.collection.length > 1;
        }

    });

    return MinimodeToggle;
});

define("minimode/ThumbnailView",
    [
        "ajs",
        "backbone",
        "jquery",
        "underscore",
        "file-types",
        "icon-utils",
        "template-store-singleton"
    ],
    function(
        AJS,
        Backbone,
        $,
        _,
        fileTypes,
        iconUtils,
        templateStore
    ) {
        "use strict";

        var ThumbnailView = Backbone.View.extend({

            className: "cp-thumbnail",

            tagName: "li",

            events: {
                "click" : "jumpToFile"
            },

            initialize: function(options) {
                this._fileViewer = options.fileViewer;
                this.listenTo(this.model, 'change', this.render);
                this.listenTo(options.panelView, 'renderPanel', this.setSelected);
            },

            jumpToFile: function() {
                this._fileViewer.showFileWithCID(this.model.cid).always(
                    this._fileViewer.analytics.fn('files.fileviewer-web.minimode.thumbnail.clicked')
                );
            },

            setSelected: function() {
                // this may not be the same as file being shown, e.g., a different version of file is shown
                var file = this._fileViewer._fileState.getCurrent();
                if (file === this.model) {
                    this.$el.addClass("selected");
                } else if (this.$el.hasClass("selected")) {
                    this.$el.removeClass("selected");
                }
            },

            onThumbLoadError: function (ev) {
                var el = $(ev.target);
                el.parent().removeClass('has-thumbnail');
                el.remove();
            },

            render: function() {
                var type = this.model.get("type"),
                    thumbnailSrc = this.model.get("thumbnail"),
                    isImage = fileTypes.isImage(type);

                var generateThumbnail = this._fileViewer.getConfig().generateThumbnail;

                var $thumbnail = $(templateStore.get('placeholderThumbnail')({
                    iconClass: iconUtils.getCssClass(type),
                    title: this.model.get("title")
                }));

                this.$el.empty().append($thumbnail);

                if (thumbnailSrc && generateThumbnail) {
                    generateThumbnail(this.model).done(function (thumbSrc) {
                        $thumbnail.replaceWith(templateStore.get('thumbnail')({
                            iconClass: iconUtils.getCssClass(type),
                            thumbnailSrc: thumbSrc,
                            title: this.model.get("title")
                        }));
                        this.$el.find('img').error(this.onThumbLoadError);
                    }.bind(this));
                } else if (isImage || thumbnailSrc) {
                    $thumbnail.replaceWith(templateStore.get('thumbnail')({
                        iconClass: iconUtils.getCssClass(type),
                        thumbnailSrc: thumbnailSrc || this.model.get("src"),
                        title: this.model.get("title")
                    }));
                    this.$el.find('img').error(this.onThumbLoadError);
                }

                return this;
            }

        });

        return ThumbnailView;
    });

(function() {
    'use strict';
    var FileViewer = require("file-viewer");
    var minimodePlugin = require("minimode/minimodePlugin");
    FileViewer.registerPlugin('minimode', minimodePlugin);
}());
}(function () {
  var FileViewer;

    if (typeof module !== "undefined" && ('exports' in module)) {
      FileViewer = require('./fileviewer.js');
    } else if (window.require) {
      FileViewer = window.FileViewer;
    } else {
      FileViewer = window.FileViewer;
    }

    return FileViewer;
}()));

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-previews:feature-discovery-plugin', location = 'js/component/feature-discovery/discovery-dialog.js' */
define("cp/component/feature-discovery/discovery-dialog",["jquery","underscore","FileViewer","aui/inline-dialog2"],function(f,b,d){var c=d.require("template-store-singleton");var e=function(h,g){return function(){h.trigger(g,arguments)}};var a=function(g){this.$anchor=f(g.anchor);this.$appendTo=f(g.appendTo);this.key=g.key;this.text=g.text;this.dialog=null;this.$anchor.attr({"aria-controls":"cp-feature-discovery","data-aui-trigger":true});var i=f(c.get("FeatureDiscovery.featureDiscovery")({text:this.text}));i.find(".cp-feature-discovery-confirm").click(function(j){this.dismiss(true);j.preventDefault()}.bind(this));var h=i[0];this.$appendTo.append(h);skate.init(h);h.show();this.dialog=h;b.extend(this,Backbone.Events);this.dialog.addEventListener("aui-layer-hide",e(this,"hide"));this.dialog.addEventListener("aui-layer-show",e(this,"show"));return this};a.prototype.is=function(g){return this.key===g};a.prototype.on=function(h,i){var g=h;if(h==="hide"){g="aui-layer-hide"}else{if(h==="show"){g="aui-layer-show"}}this.dialog.addEventListener(g,i)};a.prototype.dismiss=function(g){this.dialog.hide();this.dialog.remove();g&&this.trigger("user-dismissed-dialog",this.key)};return a});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-previews:feature-discovery-plugin', location = '/templates/feature-discovery.soy' */
// This file was automatically generated from feature-discovery.soy.
// Please don't edit this file by hand.

if (typeof FileViewer == 'undefined') { var FileViewer = {}; }
if (typeof FileViewer.Templates == 'undefined') { FileViewer.Templates = {}; }
if (typeof FileViewer.Templates.FeatureDiscovery == 'undefined') { FileViewer.Templates.FeatureDiscovery = {}; }


FileViewer.Templates.FeatureDiscovery.featureDiscovery = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<aui-inline-dialog2 id="cp-feature-discovery" class="aui-layer aui-inline-dialog" data-aui-alignment="bottom center" data-aui-responds-to="toggle" data-aui-persistent="true" data-aui-focus="false"><div class="aui-inline-dialog-contents"><p>', soy.$$escapeHtml(opt_data.text), '</p><button class="aui-button aui-button-link cp-feature-discovery-confirm">', soy.$$escapeHtml("Dismiss"), '</button></div></aui-inline-dialog2>');
  return opt_sb ? '' : output.toString();
};

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-previews:feature-discovery-plugin', location = 'js/component/feature-discovery/feature-discovery-plugin.js' */
define("cp/component/feature-discovery/feature-discovery-plugin",["cp/component/feature-discovery/discovery-dialog","underscore","ajs","confluence"],function(e,h,f,g){var d=null;var c=g.FeatureDiscovery.forPlugin("com.atlassian.confluence.plugins.confluence-previews");var a=function(j){if(d===null){return}if(!j.key||j.key&&d.is(j.key)){d.dismiss(j.persist)}};var b=function(k){var j=k.key;var l=$(k.anchor);if(l.length===0||!l.is(":visible")||l.closest("body").length===0||!c.shouldShow(j)){return}c.addDiscoveryView(k.key);a({persist:false});d=new e(k);d.on("user-dismissed-dialog",function(m){c.markDiscovered(m)});return d};var i=function(o){var m=f.Meta.get("remote-user");var k="view-annotations";var n="add-annotations";var l=[k,n];var j=m&&h(l).without(c.listDiscovered()).length!==0;if(!j){return}o.on("fv.showFile",function(t){a({persist:false});var v=t.get("annotations");var s=o.supports(t.get("type"));var u=t.get("isRemoteLink");if(!v||!s||u){return}var r=o.getView().fileSidebarView;var q=o.getView().fileControlsView;var p=q.getLayerForName("annotationButton");var w=o.getView().fileContentView.getLayerForName("content")._viewer;v.on("sync",function(){var x=v.getCount();var y=r.isPanelInitialized("annotations");if(x&&!y){b({key:k,anchor:p.$("a"),text:"Ooh, comments!  See what people are saying about this file.",appendTo:o.getView().$el})}else{var A=w.$("#cp-file-control-annotate");w.showControls();var z=b({key:n,anchor:A,text:"This little pin wants to help you collaborate. Drag it anywhere to add a comment.",appendTo:o.getView().$el});if(z){w.autoToggleControls(false);w.showControls();A.mousedown(function(){a({key:n,persist:true})});z.on("hide",function(){w.autoToggleControls(true)})}}})});o.on("fv.changeFile fv.close",function(){a({persist:false})});o.getView().fileSidebarView.on("togglePanel",function(q,p){if(q!=="annotations"||p===false){return}a({key:"view-annotations",persist:true});a({persist:false})});o.getView().fileSinkView.on("togglePanel",function(){a({persist:false})})};return i});(function(){var b=require("FileViewer");var a=require("cp/component/feature-discovery/feature-discovery-plugin");b.registerPlugin("featureDiscovery",a)}());
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
